//---------------------------------------------------------------------------
#include <time.h>
#include <io.h>
#include <stdio.h>
#include <alloc.h>
#include <fcntl.h>
#include <stdlib.h>
#include <math.h>
#include <float.h>
#include <conio.h>
#include <string.h>
#include <except.h>

#include <iostream.h>
#include <fstream.h>
#include <condefs.h>


//---------------------------------------------------------------------------
#include <vcl\vcl.h>
#pragma hdrstop

#include "vektmdssom_soc5.h"
//---------------------------------------------------------------------------
#pragma resource "*.dfm"


#define SOR 10
#define NDIM 100  /* 32,64,128*/
#define ND 4
#define ZHS 1
#define alap 7
#define TAVMIN 0.4
#define NPONT 1000
#define NVEKT 12500
#define NCSOM_MIN NPONT
#define NVEKT_MIN NPONT


void sulypont(int pontsz, int dim);
void forgat(float dc1);
void vekttavmatrkerg(int vektszam);
float keresfh(int dsorsz);
float tiptavmerfh(int dsorsz, int wsorsz, int transzp);
float tavmeres(int sorsz1, int sorsz2, int vektdim, float tk);

void intki(int *kiptr, int elemszam, char *nev);
void floatki(float *kiptr, int elemszam, char *nev);

int bej[80];
char vnf[1000000], *vnfnev0=new char[50];
int hang[50][400],ritm[50][400];
int szotag[NVEKT+1],sorido[NVEKT+1];
int hosszusorhsz=12, hosszusorido=64;
float vegtransz=0;


int *fogpt, dimenz,dimenz2,dimvet,motdimenz,normal=1,ho,hanysor;
float s1[500],vektorok[NVEKT+1][NDIM+1], hanghiszt[NVEKT+1][50],hangsuly[50],hahisuly,hahinorm,puf,talalat[NPONT+1];
int kr[80],nreg,nsor=SOR, notael[NVEKT+1];
int *spt, *kpt, *uspt, nn1, nn2, eloj;
int i,j,k,vupx,vupy,ns1,ns2,zarh,zh[3],sorszam;

char *np, *npp, *fogptr,fogado[5000000],nevs[50],*nevptr;
float nysor[10][100];
int kapcs[21],minroksz;


float w[NPONT+1][3][NDIM+1],eta,oszl, fel,rn;
int  mx,my,minx,miny;

float tipelterj[NPONT+1][100];

int ahang[NVEKT+1][200], aritm[NVEKT+1][200],kezdohang[NVEKT+1];
int minh[6][6],sorssz[6];

int rokon[NVEKT+1],csop[NVEKT+1];
int kozp[NCSOM_MIN+1],rokind;

int elso=1,utso=2403*1,pontsz=utso-elso+1, term[10], terx=100,tery=100,terz=100,terw=100, ciklusszam=1000,dallamrajz=0;
int savsz=10,utofeldolg=0,zhtransz=0,minxx[20],minyy[20],csalad[300], xracs=1,yracs=1,nullsav=0;
float tavkusz=terx/2,krittav=10.25;
float alfa=2.0*3.1415926535/6.0, nyujt=.7;
//float alfa=2.0*3.1415926535/4.0, nyujt=1;

//char utofeld=0;

int ervtelen, elrajz,elrajz2, valvekt;


float vekttav[NVEKT_MIN+1][NVEKT_MIN+1],vektkoord0[NVEKT+1][5],nyujtas,nyujt2,kezdgrad,kozelarany,haskusz, lept=1;
int vektkoord[NVEKT+1][5],cim[NVEKT+1], tipelt[NPONT+1][51], hanys[NVEKT+1];
float vpuf[NPONT+1][NPONT+1];
int kottanota,hatar1,hatar2,szinhat,nevadas,tanvege;
int elszam[NPONT+1];

double forg1[5][5],forg2[5][5],forg3[5][5],forg4[5][5];
double z[NVEKT][3],cc[5][5],baz[ND+1][ND+1],bz[ND+1][5],sv[NDIM+1],sulyp[ND+1],ny,ptav;

int tipusszam, vektorszam, minsorszam, nhely=30, valvektor;
float fohang[NDIM+10];

double nagyitas=1.0;

int talk[100],hatar[100];
char katk[NVEKT+1][2], *abrszov = new char[200];
int elof[NVEKT+1], button3=0, dallamresz, ossztipus, osszkult=59;
int feltetel[500+1][500+1], szinhatar[20],kozpontszam,szinrendszer, tipabr, dallamv;

int utes0[15][130];

TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
	: TForm(Owner)
{
}


//----------------------------------------------------------------------------


//--------------- Vector input / output functions -------------------------------------

void wki_mds_som(void)
{
FILE *out;
char *npp=new char[200], s[200];
int i,m;

npp = "c:/eurkat/mds-som.dat";
out=fopen(npp, "w");   if (out==0) {Form1->Memo1->Lines->Add("file haszn�latban"); return;}
fclose(out);
out = fopen( npp, "a");

int maxt=0;
int mintalalat=0;
for (i=1;i<=utso;i++) {

    if (talalat[i]>maxt ) {maxt=talalat[i];}
    if (talalat[i]>=mintalalat) {
      sprintf(s, "%4d %7.3f %7.3f %7.3f %3d  ",i,z[i][1],z[i][2],0.0, (int)talalat[i]); fwrite(s,strlen(s),1,out);
      for (m=1;m<=dimenz;m++) {
        sprintf(s, "%8.3f  ", w[i][1][m]); fwrite(s,10,1,out);
      }
      sprintf(s, "%5.1f 1000 \n",0.0); fwrite(s,12,1,out);
    }
    //sorsz++;

}
fclose(out);

npp = "c:/eurkat/mds-som-suly.dat";
out=fopen(npp, "w");
fclose(out);
out = fopen( npp, "w");

maxt=0;
for (i=1;i<=utso;i++) {

    if (talalat[i]>maxt ) {maxt=talalat[i];}
    if (talalat[i]>=mintalalat) {
      sprintf(s, "%4d %7.3f %7.3f %7.3f %3d  ",i,z[i][1],z[i][2],0.0, (int)talalat[i]); fwrite(s,strlen(s),1,out);
      for (m=1;m<=dimenz;m++) {
        sprintf(s, "%8.3f  ", w[i][0][m]); fwrite(s,10,1,out);
      }
      sprintf(s, "%5.1f 1000 \n",0.0); fwrite(s,12,1,out);

    }
    //sorsz++;
}
fclose(out);


npp = "c:/eurkat/mds-som2.dat";
out=fopen(npp, "w");
fclose(out);
out = fopen( npp, "w");
maxt=0;
for (i=1;i<=utso;i++) {

    if (talalat[i]>maxt ) {maxt=talalat[i];}
    if (talalat[i]>=mintalalat) {
      sprintf(s, "%4d %7.3f %7.3f %7.3f %3d  ",i,z[i][1],z[i][2],0.0, (int)talalat[i]); fwrite(s,strlen(s),1,out);
      for (m=1;m<=dimenz2;m++) {
        sprintf(s, "%8.3f  ", w[i][2][m]); fwrite(s,10,1,out);
      }
      sprintf(s, "%5.1f 1000 \n",0.0); fwrite(s,12,1,out);

    }
    //sorsz++;
}
fclose(out);


}



int wbe_mds_som(char *nevp, char *fogp, int dimenz, int elofhat, int hely)
{
int i,j,szaml, poz, dim,lep,motszam;
FILE *in;
char str[20], *ptr, *sptr, ch;
long int indx,hossz;
float fl;

in=fopen(nevp, "r");  if (in==0) {return(0);}
indx=_fileno(in); hossz=filelength(indx);
fread(fogp, 1, hossz, in);
fclose(in);

ptr=fogp;  sptr=&str[0]; indx=0; dim=dimenz-1;
motszam=term[1]*term[2]*term[3]*term[4];  if (motszam<=1) {motszam=100;}

int elof;
int sorsz,szamlalo;
float x,y,z;


szamlalo=0;
for (szaml=1;szaml<=motszam;szaml++) {

while (indx<1) { ch=0;
    while (*ptr==32) {ptr++;}
	for (i=0; i<20; i++) { str[i]=0;}
	i=0; while (ch!=32) {ch=*ptr++;str[i++]=ch;}indx++;
    while (*ptr==32) {ptr++;}
	lep=atoi(sptr);
    if (lep!=1000000) {sorsz=lep;}
}

while (indx<2) { ch=0;
    while (*ptr==32) {ptr++;}
	for (i=0; i<20; i++) { str[i]=0;}
	i=0; while (ch!=32) {ch=*ptr++;str[i++]=ch;}indx++;
    while (*ptr==32) {ptr++;}
	fl=atof(sptr);
    if (lep!=1000000) {x=fl;}
}


while (indx<3) { ch=0;
    while (*ptr==32) {ptr++;}
	for (i=0; i<20; i++) { str[i]=0;}
	i=0; while (ch!=32) {ch=*ptr++;str[i++]=ch;}indx++;
    while (*ptr==32) {ptr++;}
	fl=atof(sptr);
    if (lep!=1000000) {y=fl;}
}

while (indx<4) { ch=0;
    while (*ptr==32) {ptr++;}
	for (i=0; i<20; i++) { str[i]=0;}
	i=0; while (ch!=32) {ch=*ptr++;str[i++]=ch;}indx++;
    while (*ptr==32) {ptr++;}
	fl=atof(sptr);
    if (lep!=1000000) {z=fl;}
}

while (indx<5) { ch=0;
    while (*ptr==32) {ptr++;}
	for (i=0; i<20; i++) { str[i]=0;}
	i=0; while (ch!=32) {ch=*ptr++;str[i++]=ch;}indx++;
    while (*ptr==32) {ptr++;}
	lep=atoi(sptr);
    if (lep!=1000000) {elof=lep;}
}

if (elof>=elofhat) {szamlalo++;}
//if (elof>=0) {vektkoord0[sorsz][1]=x; vektkoord0[sorsz][2]=y; vektkoord0[sorsz][3]=z;  talalat[sorsz]=elof;}
if (elof>=elofhat) {vektkoord0[szamlalo][1]=x; vektkoord0[szamlalo][2]=y; vektkoord0[szamlalo][3]=z;  talalat[szamlalo]=elof;}
/*return(elof);*/

poz=1;
while (indx<dim+6) { ch=0;
    while (*ptr==32) {ptr++;}
	for (i=0; i<20; i++) { str[i]=0;}
	i=0; while (ch!=32) {ch=*ptr++;str[i++]=ch;}indx++;
    while (*ptr==32) {ptr++;}
	fl=atof(sptr);
    if (fl!=1000000 && hely==0 && elof>=elofhat) {w[szamlalo][hely][poz++]=fl;}
    if (fl!=1000000 && hely==1 && elofhat<=elof) {w[szamlalo][hely][poz++]=fl;}
    if (fl!=1000000 && hely==2 && elofhat<=elof) {w[szamlalo][hely][poz++]=fl;}
}
/*return(indx);*/

while (indx<dim+7) { ch=0;
    while (*ptr==32) {ptr++;}
	for (i=0; i<20; i++) { str[i]=0;}
	i=0; while (ch!=32) {ch=*ptr++;str[i++]=ch;}indx++;
    while (*ptr==32) {ptr++;}
	fl=atof(sptr);
}
/*return(fl);*/

while (indx<dim+8) { ch=0;
    while (*ptr==32) {ptr++;}
	for (i=0; i<20; i++) { str[i]=0;}
	i=0; while (ch!=32) {ch=*ptr++;str[i++]=ch;}indx++;
    while (*ptr==32) {ptr++;}
	fl=atof(sptr);
}
/*return(fl);*/


while (indx<dim+8) { ch=0;
    while (*ptr==32) {ptr++;}
	for (i=0; i<20; i++) { str[i]=0;}
	i=0; while (ch!=32) {ch=*ptr++;str[i++]=ch;}indx++;
    while (*ptr==32) {ptr++;}
	fl=atof(sptr);
}
/*return(fl);*/


if ((ptr-fogp)>=hossz) {return(motszam);}
else {poz=1;indx=0;while(*ptr!=10) {ptr++;}ptr++;}
if (szaml==1) {j=(int)(ptr-fogp+1); motszam=hossz/j;}

}

return(szamlalo);

}


int wbe(char *nevp, char *fogp, int dimenz, int elofhat, int hely)
{
int i,j,szaml, poz, dim,lep,motszam;
FILE *in;
char str[20], *ptr, *sptr, ch;
long int indx,hossz;
float fl;

in=fopen(nevp, "r");  if (in==0) {return(0);}
indx=_fileno(in); hossz=filelength(indx);
fread(fogp, 1, hossz, in);
fclose(in);

ptr=fogp;  sptr=&str[0]; indx=0; dim=dimenz-1;
motszam=terx*tery;

//int x,y;
int elof;


for (szaml=1;szaml<=motszam;szaml++) {

while (indx<1) { ch=0;
    while (*ptr==32) {ptr++;}
	for (i=0; i<20; i++) { str[i]=0;}
	i=0; while (ch!=32) {ch=*ptr++;str[i++]=ch;}indx++;
    while (*ptr==32) {ptr++;}
	lep=atoi(sptr);
    //if (lep!=1000000) {x=lep;}
}

while (indx<2) { ch=0;
    while (*ptr==32) {ptr++;}
	for (i=0; i<20; i++) { str[i]=0;}
	i=0; while (ch!=32) {ch=*ptr++;str[i++]=ch;}indx++;
    while (*ptr==32) {ptr++;}
	lep=atoi(sptr);
    //if (lep!=1000000) {y=lep;}
}


while (indx<3) { ch=0;
    while (*ptr==32) {ptr++;}
	for (i=0; i<20; i++) { str[i]=0;}
	i=0; while (ch!=32) {ch=*ptr++;str[i++]=ch;}indx++;
    while (*ptr==32) {ptr++;}
	lep=atoi(sptr);
    if (lep!=1000000) {elof=lep;}
}

//return(elof);

poz=1;
while (indx<dim+4) { ch=0;
    while (*ptr==32) {ptr++;}
	for (i=0; i<20; i++) { str[i]=0;}
	i=0; while (ch!=32) {ch=*ptr++;str[i++]=ch;}indx++;
    while (*ptr==32) {ptr++;}
	fl=atof(sptr);
    //if (fl!=1000000 && hely==2) {w[x][y][hely][poz++]=fl;}
    if (fl!=1000000 && hely==1 && elofhat<=elof) {vektorok[szaml][poz++]=fl;}
}
//return(indx);

while (indx<dim+5) { ch=0;
    while (*ptr==32) {ptr++;}
	for (i=0; i<20; i++) { str[i]=0;}
	i=0; while (ch!=32) {ch=*ptr++;str[i++]=ch;}indx++;
    while (*ptr==32) {ptr++;}
	fl=atof(sptr);
}
//return(fl);

while (indx<dim+6) { ch=0;
    while (*ptr==32) {ptr++;}
	for (i=0; i<20; i++) { str[i]=0;}
	i=0; while (ch!=32) {ch=*ptr++;str[i++]=ch;}indx++;
    while (*ptr==32) {ptr++;}
	fl=atof(sptr);
}
//return(fl);


while (indx<dim+6) { ch=0;
    while (*ptr==32) {ptr++;}
	for (i=0; i<20; i++) { str[i]=0;}
	i=0; while (ch!=32) {ch=*ptr++;str[i++]=ch;}indx++;
    while (*ptr==32) {ptr++;}
	fl=atof(sptr);
}
//return(fl);

if ((ptr-fogp)>=hossz) {return(motszam);}
else {poz=1;indx=0;while(*ptr!=10) {ptr++;}ptr++;}
if (szaml==1) {j=(int)(ptr-fogp+1); motszam=hossz/j;}

}

return(motszam);

}

int wki(char *npp, int wszam, int mintalalat)
{
FILE *out;
char s[1000];
int i,m,hat;

//out=fopen(npp, "w"); fclose(out);

out = fopen( npp, "w");
hat=0;
for (i=1;i<=wszam;i++) {
    if (talalat[i]>=mintalalat) { hat+=talalat[i]; hatar[i]=hat;
      for (m=0;m<1000;m++) {s[m]=0;}
      sprintf(s, "%4d %7.3f %7.3f %7.3f %3d  ",sorszam,vektkoord0[i][1],vektkoord0[i][2],vektkoord0[i][3], (int)talalat[i]); fwrite(s,strlen(s),1,out);
      for (m=1;m<=dimenz;m++) {
        sprintf(s, "%8.3f  ", w[i][1][m]); fwrite(s,10,1,out);
      }
      sprintf(s, "%5.1f 1000 \n",0.0); fwrite(s,12,1,out);
    }

}
fclose(out);

/*
npp = "c:/eurkat/mds-som-suly.dat";
out=fopen(npp, "w");
fclose(out);
out = fopen( npp, "w");
hat=0;
for (i=1;i<=wszam;i++) {
    if (talalat[i]>=mintalalat) {  hat+=talalat[i]; hatar[i]=hat;
      for (m=0;m<1000;m++) {s[m]=0;}
      sprintf(s, "%4d %7.3f %7.3f %7.3f %3d  ",i,vektkoord0[i][1],vektkoord0[i][2],vektkoord0[i][3], (int)talalat[i]); fwrite(s,strlen(s),1,out);
      for (m=1;m<=dimenz;m++) {
        sprintf(s, "%8.3f  ", w[i][2][m]); fwrite(s,10,1,out);
      }
      sprintf(s, "%5.1f 1000 \n",0.0); fwrite(s,12,1,out);

    }
    //sorsz++;
}
fclose(out);
*/

intki(&hatar[1], wszam, "c:/eurkat/hatar.dat");

}


int wki0(char *npp, int wszam, int mintalalat)
{
FILE *out;
char s[1000];
int i,m,hat;

//out=fopen(npp, "w"); fclose(out);

out = fopen( npp, "w");  if (out==0) {Form1->Memo1->Lines->Add("f�jl haszn�latban!!!!"); return(0);}
hat=0;
for (i=1;i<=wszam;i++) {
    if (talalat[i]>=mintalalat) { hat+=talalat[i]; //hatar[i]=hat;
      for (m=0;m<1000;m++) {s[m]=0;}
      //sprintf(s, "%4d %7.3f %7.3f %7.3f %3d  ",sorszam,vektkoord0[i][1],vektkoord0[i][2],vektkoord0[i][3], (int)talalat[i]); fwrite(s,strlen(s),1,out);
      for (m=1;m<=dimenz;m++) {
        sprintf(s, "%8.3f  ", w[i][1][m]); fwrite(s,10,1,out);
      }
      sprintf(s, " \n"); fwrite(s,strlen(s),1,out);
    }

}
fclose(out);

npp="c:/eurkat/tipvekt-2.dat";
out = fopen( npp, "w");  if (out==0) {Form1->Memo1->Lines->Add("f�jl haszn�latban!!!!"); return(0);}
hat=0;
for (i=1;i<=wszam;i++) {
    if (talalat[i]>=mintalalat) { hat+=talalat[i]; //hatar[i]=hat;
      for (m=0;m<1000;m++) {s[m]=0;}
      //sprintf(s, "%4d %7.3f %7.3f %7.3f %3d  ",sorszam,vektkoord0[i][1],vektkoord0[i][2],vektkoord0[i][3], (int)talalat[i]); fwrite(s,strlen(s),1,out);
      for (m=1;m<=dimenz2;m++) {
        sprintf(s, "%8.3f  ", w[i][2][m]); fwrite(s,10,1,out);
      }
      sprintf(s, " \n"); fwrite(s,strlen(s),1,out);
    }

}
fclose(out);


}


int vektki(char *npp, int wszam)
{
FILE *out;
char s[1000];
int i,m,hat;
int mintalalat;

mintalalat=-10;
//out=fopen(npp, "w"); fclose(out);

npp="c:/eurkat/Contour.dat";
out = fopen( npp, "w");  if (out==0) {Form1->Memo1->Lines->Add("f�jl haszn�latban!!!!"); return(0);}
hat=0;
for (i=1;i<=wszam;i++) {
    if (talalat[i]>=mintalalat) { hat+=talalat[i]; //hatar[i]=hat;
      for (m=0;m<1000;m++) {s[m]=0;}
      for (m=1;m<=dimenz;m++) {
        sprintf(s, "%8.3f  ", vektorok[i][m]); fwrite(s,10,1,out);
      }
      sprintf(s, " \n"); fwrite(s,strlen(s),1,out);
    }

}
fclose(out);

npp="c:/eurkat/DegreeDist.dat";
out = fopen( npp, "w");  if (out==0) {Form1->Memo1->Lines->Add("f�jl haszn�latban!!!!"); return(0);}
hat=0;
for (i=1;i<=wszam;i++) {
    if (talalat[i]>=mintalalat) { hat+=talalat[i]; //hatar[i]=hat;
      for (m=0;m<1000;m++) {s[m]=0;}
      for (m=1;m<=dimenz2;m++) {
        sprintf(s, "%8.3f  ", hanghiszt[i][m]); fwrite(s,10,1,out);
      }
      sprintf(s, " \n"); fwrite(s,strlen(s),1,out);
    }

}
fclose(out);

}


int dallamszam(char *nevs)
{
int indx;
long int hossz;
char *fogp=new char[1000000];

FILE *in;
in=fopen(nevs,"rt");

indx=_fileno(in); hossz=filelength(indx);
fread(fogp, 1, hossz, in);
fclose(in);

indx=int((float)hossz/32+0.5);
return(indx);

}

int vektfelhobe(char *nevp, char *fogp, int vektszam, int kezdes, char szun)
{
int i,szaml, poz, dim,indx;
FILE *in;
char str[20], *ptr, *sptr, ch;
float fl;
int hossz;

in=fopen(nevp, "r");
indx=_fileno(in); hossz=filelength(indx);
fread(fogp, 1, hossz, in);
fclose(in);

//vektszam=hossz/296;
//vektszam=34;
//ptr=fogp; i=0; while (*ptr!=10) {ptr++;i++;} vektszam=hossz/i;


ptr=fogp; int valkar=0; szaml=0;
for (i=1;i<=hossz;i++) {
  if (*ptr!=' ' && *ptr!=10) {valkar++;}
  if (*ptr==10 && 0<valkar) {szaml++;valkar=0;}
  ptr++;
}
vektszam=szaml-0;


ptr=fogp;  sptr=&str[0]; szaml=kezdes-1; poz=1;

while (szaml!=vektszam+kezdes-1) { ch=0; //Form1->Memo1->Lines->Add(szaml);
	for (i=0; i<20; i++) { str[i]=0;}
    while (*ptr==szun) {ptr++;}
	i=0; while (ch!=szun && ch!=10 && i<20) {
      ch=*ptr++;
      str[i++]=ch;
    } //ptr++;
    fl=atof(sptr);  //fl=1000;
	if (fl!=1000) {vektorok[szaml+1][poz]=1.0*fl;poz++;}
	//else {szaml++; dim=poz-1; poz=1;}
    if (ch==10) {szaml++; dim=poz-1; poz=1;}
}

return(szaml);
}

float atl[NDIM+1];
int vektrend(int vektsz)
{
int i,j,k, fszam;

k=0;
for (i=1;i<=vektsz;i++) {
  if (notael[i]==1) { k+=1; cim[k]=i;
    for (j=1;j<=dimenz;j++) {vektorok[k][j]=vektorok[i][j];}
  }
}
fszam=k;

k=0;
for (i=1;i<=vektsz;i++) {
  if (notael[i]==1) { k+=1; cim[k]=i;    //Form1->Memo1->Lines->Add(cim[k]);
    for (j=1;j<=dimenz2;j++) {hanghiszt[k][j]=hanghiszt[i][j];}
  }
}
fszam=k;

/*
for (i=1;i<=fszam;i++) {
  for (j=1;j<=dimenz;j++) {atl[j]+=vektorok[i][j];}
}
for (j=1;j<=dimenz;j++) {atl[j]/=(float)fszam;}
*/
return(fszam);

}


int tipbe(char *nevp, char *fogp, int dimenz, int elofhat, int ksorsz)
{
int szaml, poz, dim,lep,motszam, sorsz;
FILE *in;
char str[20], *ptr, *sptr, ch;
long int indx,hossz;
float fl;

in=fopen(nevp, "r");  if (in==0) {return(0);}
indx=_fileno(in); hossz=filelength(indx);
fread(fogp, 1, hossz, in);
fclose(in);

ptr=fogp;  sptr=&str[0]; indx=0; dim=dimenz-1;
//motszam=427;
motszam=hossz/345-1;


int x,y,katsorsz=1;

for (szaml=1;szaml<=motszam;szaml++) {

while (indx<1) { ch=0;
    while (*ptr==32) {ptr++;}
	for (i=0; i<20; i++) { str[i]=0;}
	i=0; while (ch!=32) {ch=*ptr++;str[i++]=ch;}indx++;
    while (*ptr==32) {ptr++;}
	lep=atoi(sptr);
    if (lep!=1000000) {sorsz=lep;}
}


while (indx<2) { ch=0;
    while (*ptr==32) {ptr++;}
	for (i=0; i<20; i++) { str[i]=0;}
	i=0; while (ch!=32) {ch=*ptr++;str[i++]=ch;}indx++;
    while (*ptr==32) {ptr++;}
	fl=atoi(sptr);
    //if (lep!=1000000) {x=lep;}
}

while (indx<3) { ch=0;
    while (*ptr==32) {ptr++;}
	for (i=0; i<20; i++) { str[i]=0;}
	i=0; while (ch!=32) {ch=*ptr++;str[i++]=ch;}indx++;
    while (*ptr==32) {ptr++;}
	fl=atoi(sptr);
    //if (lep!=1000000) {y=lep;}
}

while (indx<4) { ch=0;
    while (*ptr==32) {ptr++;}
	for (i=0; i<20; i++) { str[i]=0;}
	i=0; while (ch!=32) {ch=*ptr++;str[i++]=ch;}indx++;
    while (*ptr==32) {ptr++;}
	fl=atoi(sptr);
    //if (lep!=1000000) {z=lep;}
}

while (indx<5) { ch=0;
    while (*ptr==32) {ptr++;}
	for (i=0; i<20; i++) { str[i]=0;}
	i=0; while (ch!=32) {ch=*ptr++;str[i++]=ch;}indx++;
    while (*ptr==32) {ptr++;}
	lep=atoi(sptr);
    if (lep!=1000000) {elof[katsorsz+ksorsz]=lep;}
}

/*return(elof);*/

poz=1;
while (indx<dim+6) { ch=0;
    while (*ptr==32) {ptr++;}
	for (i=0; i<20; i++) { str[i]=0;}
	i=0; while (ch!=32) {ch=*ptr++;str[i++]=ch;}indx++;
    while (*ptr==32) {ptr++;}
	fl=atof(sptr);
    if (fl!=1000000 && elofhat<=elof[katsorsz+ksorsz]) {vektorok[katsorsz+ksorsz][poz++]=fl;}
}
if (elofhat<=elof[katsorsz+ksorsz]) {katsorsz++;}
/*return(indx);*/

while (indx<dim+7) { ch=0;
    while (*ptr==32) {ptr++;}
	for (i=0; i<20; i++) { str[i]=0;}
	i=0; while (ch!=32) {ch=*ptr++;str[i++]=ch;}indx++;
    while (*ptr==32) {ptr++;}
	fl=atof(sptr);
}
/*return(fl);*/

while (indx<dim+8) { ch=0;
    while (*ptr==32) {ptr++;}
	for (i=0; i<20; i++) { str[i]=0;}
	i=0; while (ch!=32) {ch=*ptr++;str[i++]=ch;}indx++;
    while (*ptr==32) {ptr++;}
	fl=atof(sptr);
}
/*return(fl);*/

while (indx<dim+8) { ch=0;
    while (*ptr==32) {ptr++;}
	for (i=0; i<20; i++) { str[i]=0;}
	i=0; while (ch!=32) {ch=*ptr++;str[i++]=ch;}indx++;
    while (*ptr==32) {ptr++;}
	fl=atof(sptr);
}
/*return(fl);*/

if ((ptr-fogp)>=hossz) {return(motszam);}
else {poz=1;indx=0;while(*ptr!=10) {ptr++;}ptr++;}
/*if (motszam==1) {j=26+(dim-1)*7+13-1; motszam=hossz/(j+1);}*/
if (szaml==1) {j=(int)(ptr-fogp)+1; motszam=hossz/j;}
//if (motszam>470) {motszam=471;}
}

return(ksorsz+katsorsz-1);

}


int tipelterjbe(char *nevp, char *fogp, int vektszam, int hossz)
{
int i,szaml, poz, indx, dim;
FILE *in;
char str[20], *ptr, *sptr, ch;

in=fopen(nevp, "r");
indx=_fileno(in); hossz=filelength(indx);
fread(fogp, 1, hossz, in);
fclose(in);

//vektszam=hossz/296;
//vektszam=34;

ptr=fogptr;  sptr=&str[0]; szaml=0; poz=1;

while (szaml!=vektszam) { ch=0;
	for (i=0; i<20; i++) { str[i]=0;}
    while (*ptr==32) {ptr++;}
	i=0; while (ch!=32 && ch!=10) {ch=*ptr++; str[i++]=ch;} //ptr++;
    indx=atoi(sptr);  //fl=1000;
	tipelt[szaml+1][poz]=indx;poz++;
	//else {szaml++; dim=poz-1; poz=1;}
    if (ch==10) {szaml++; dim=poz-2; poz=1;}
}


return(dim);
}


int vektkoordbe(char *nevp, char *fogp, int vektszam)
{
int i,szaml,indx;
FILE *in;
char str[20], *ptr, *sptr, ch;
float fl;
int hossz;

in=fopen(nevp, "r");
indx=_fileno(in); hossz=filelength(indx);
fread(fogp, 1, hossz, in);
fclose(in);

//vektszam=hossz/296;
//vektszam=516;
//vektszam=941;
//vektszam=24;
//vektszam=200;

ptr=fogptr;  sptr=&str[0]; szaml=0; int poz=1;

while (szaml!=vektszam) { ch=0;
	for (i=0; i<20; i++) { str[i]=0;}
    while (*ptr==32) {ptr++;}
	i=0; while (ch!=32 && ch!=10) {ch=*ptr++; str[i++]=ch;} //ptr++;
    fl=atof(sptr);  //fl=1000;
	if (fl!=1000) {vektkoord0[szaml+1][poz]=fl;poz++;}
	//else {szaml++; dim=poz-1; poz=1;}
    if (ch==10) {szaml++; /*dim=poz-1; poz=1;*/}
}
//dim-=1;

return(vektszam);
}


void vekttavki(char *nev=new char[100])
{
int i,j;
FILE *out;
char s[20];

//out=fopen("c:/genetika/vekttav.dat","w");
out=fopen(nev,"w");

for (i=1;i<=utso;i++) {
  for (j=1;j<=utso;j++) {sprintf(s,"%7.3f ", vekttav[i][j]); fwrite(s,strlen(s)+1,1,out);} fwrite(" \n",2,1,out);
}
fclose(out);

}

void floatki(float *kiptr, int elemszam, char *nev=new char[100])
{
int i,j;
FILE *out;
char s[20];

//out=fopen("c:/genetika/vekttav.dat","w");
out=fopen(nev,"w");

for (i=1;i<=elemszam;i++) {for (j=0;j<20;j++) {s[j]=0;} sprintf(s,"%7.3f ", *kiptr++); fwrite(s,strlen(s),1,out);} //fwrite(" \n",2,1,out);

fclose(out);

}


void intki(int *kiptr, int elemszam, char *nev=new char[100])
{
int i,j;
FILE *out;
char s[20];

//out=fopen("c:/genetika/vekttav.dat","w");
out=fopen(nev,"w");

for (i=1;i<=elemszam;i++) {for (j=0;j<20;j++) {s[j]=0;} sprintf(s,"%6d ", *kiptr++); fwrite(s,strlen(s),1,out);} //fwrite(" \n",2,1,out);

fclose(out);

}

void intmatrki(int xx, int yy, char *kinev=new char[50])
{
FILE *out;
char s[20];
int i,j,k;

//for (i=1;i<=xx;i++) {for (j=1;j<=yy;j++) {*kipt++=feltetel[i][j];}}

char *str=new char[20];
Form1->Edit5->GetTextBuf(str,20); kozelarany=atof(str);

float maxtav=-1000;
for (i=1;i<=utso;i++) {
  for (j=1;j<=utso;j++) { if (maxtav<vekttav[i][j]) {maxtav=vekttav[i][j];}}
}
maxtav*=kozelarany;


out=fopen(kinev,"w");

for (i=0;i<20;i++) {s[i]=0;}
for (i=1;i<=xx;i++) {
  for (j=1;j<=yy;j++) {k=feltetel[i][j]; if (k<0) {k=0;}
    if (vekttav[i][j]<maxtav && vekttav[j][i]<maxtav && k==1) {k=1;} else {k=0;}
    sprintf(s,"%4d  ",k); fwrite(s, strlen(s),1,out);
  }
  fwrite(" \n",2,1,out);
}
fclose(out);

}

int adatbe(void)
{
//------------  t�pus f�jlok beolvas�sa ----------------------------------------------------------------------
char *pt,*nevpt,nev[100];
int lishossz, all,talkuszob, i,j,k, uts;
char *listapt=new char[1000000];

//Form1->OpenDialog1->Filter="*.xls";
//Form1->OpenDialog1->FileName="c:/indulas/pr.etf";

//listapt=&x[0];
all=Form1->OpenDialog1->Execute();
listapt=Form1->OpenDialog1->Files->GetText();
//Memo1->Lines->Add(listapt);
//Memo1->Lines->Add(all);

pt=listapt; i=0; while (*pt!=0) {pt++;i++;} i--; lishossz=i;
//Memo1->Lines->Add(lishossz);

/*
talk[1]=2034;talk[2]=1567;talk[3]=1120;talk[4]=1633;talk[5]=1299;talk[6]=1027;talk[7]=324;talk[8]=2299;talk[9]=1094;talk[10]=2527;
talk[11]=1937;talk[12]=688;talk[13]=1133;talk[14]=1569;talk[15]=2252;talk[16]=1970;talk[17]=2402;talk[18]=1149;talk[19]=2048;talk[20]=2408;
talk[21]=2207;talk[22]=1401;talk[23]=842;talk[24]=405;talk[25]=447;talk[26]=551;talk[27]=615;talk[28]=1158;talk[29]=236;talk[30]=978;
talk[31]=692;talk[32]=1298;talk[33]=357;talk[34]=705;talk[35]=751;talk[36]=236;talk[37]=520;talk[38]=489;talk[39]=752;//talk[40]=2527;
*/

//for (i=1;i<=39;i++) {talk[i]=int((float)talk[i]/300.0+0.5);}
for (i=1;i<=99;i++) {talk[i]=1;}  //talk[7]=1; talk[29]=1; talk[33]=1; talk[36]=1;

pt=listapt; nevpt=&nev[0];

uts=0;
int lisszaml=0, ksz=1, szamlalo=1;
while (lisszaml<=lishossz) { talkuszob=talk[szamlalo];

  for (i=0;i<100;i++) {nev[i]=0;}

  i=0;
  while (*pt!=10 && *pt!=0) {nev[i++]=*pt++;lisszaml++;} pt++; lisszaml++; nev[i-1]=0; nevpt=&nev[0];  Form1->Memo1->Lines->Add(nev);

  //npp="c:/eurkat/tip-10/tip01.dat";
  fogptr=&fogado[0];
  if (szamlalo>0) {uts=tipbe(nevpt,fogptr,dimenz,talkuszob,uts); Form1->Memo1->Lines->Add(uts);  hatar[ksz++]=uts;}  // az els� megnyit�s az utols� f�jlt nyitja meg
  szamlalo++;
}
osszkult=ksz-1;
return(uts);


// ------- mivel a listapt-ben az utols� f�jln�v ker�l az els� helyre, az utols�t k�l�n kell megnyitni -------------------------
/*
pt=listapt; nevpt=&nev[0]; talkuszob=talk[szamlalo];
for (i=0;i<100;i++) {nev[i]=0;}
i=0;
while (*pt!=10 && *pt!=0) {nev[i++]=*pt++;lisszaml++;} pt++; lisszaml++; nev[i-1]=0; nevpt=&nev[0];  Form1->Memo1->Lines->Add(nev);
fogptr=&fogado[0];
uts=tipbe(nevpt,fogptr,dimenz,talkuszob,uts); Form1->Memo1->Lines->Add(uts);  hatar[ksz++]=uts;

if (uts==0) {return(0);}
*/
//------------------------------------------------------------------------------------------------------------------------------

osszkult=szamlalo-1; Form1->Memo1->Lines->Add(osszkult);
//return(uts);

int osszmot[100],ossztip[100],hiszt[501];
float atltal[100],fl;
char st[50];

hatar[0]=1;
for (i=1;i<=osszkult;i++) {  osszmot[i]=0; ossztip[i]=hatar[i]-hatar[i-1];
  for (j=hatar[i-1]+1;j<=hatar[i];j++) {osszmot[i]+=elof[j];}
  atltal[i]=(float)osszmot[i]/(float)ossztip[i]; talk[i]=int(atltal[i]*.3+.5); if (talk[i]<1) {talk[i]=1;}
}
for (i=1;i<=osszkult;i++) {sprintf(st,"%d  %5d %d %.1f   %d",i,osszmot[i],ossztip[i],atltal[i],talk[i]);Form1->Memo1->Lines->Add(st);}


pt=listapt; nevpt=&nev[0];

uts=0;
lisszaml=0, ksz=1, szamlalo=1;
while (lisszaml<=lishossz) { talkuszob=talk[szamlalo];

  for (i=0;i<100;i++) {nev[i]=0;}

  i=0;
  while (*pt!=10 && *pt!=0) {nev[i++]=*pt++;lisszaml++;} pt++; lisszaml++; nev[i-1]=0; nevpt=&nev[0];  Form1->Memo1->Lines->Add(nev);

  //npp="c:/eurkat/tip-10/tip01.dat";
  fogptr=&fogado[0];
  if (szamlalo>0) {uts=tipbe(nevpt,fogptr,dimenz,talkuszob,uts); Form1->Memo1->Lines->Add(uts);  hatar[ksz++]=uts;}  // az els� megnyit�s az utols� f�jlt nyitja meg
  szamlalo++;
}



FILE *out;
out=fopen("c:/eurkat/hiszttal.dat","w");
int max,maxj;
for (i=1;i<=osszkult;i++) {
  for (j=0;j<=500;j++) {hiszt[j]=0;}
  for (j=hatar[i-1]+1;j<=hatar[i];j++) {k=elof[j];k=int((float)k/1.0+.5);hiszt[k]+=1;}
  for (j=0;j<50;j++) {st[j]=0;}
  for (j=1;j<50;j++) {fl=(float)hiszt[j]/(float)ossztip[i]; sprintf(st,"%.3f ",fl);fwrite(st,1,strlen(st),out);}
  for (j=0;j<50;j++) {st[j]=0;}
  sprintf(st," \n",hiszt[j]);fwrite(st,1,strlen(st),out);
  max=0; maxj=0;
  for (j=1;j<50;j++) {if (max<hiszt[j]) {max=hiszt[j];maxj=j;}} atltal[i]=maxj;
  //talk[i]=int((float)maxj*.7+.5); if (talk[i]<1) {talk[i]=1;}
  //talk[i]=1;
}
//talk[7]=1; talk[29]=1; talk[33]=1; talk[36]=1;// hanti, komi kiv�telez�s
//for (i=1;i<=osszkult;i++) {j=int((float)osszmot[i]/300.0+0.5); if (j==0) {j=1;} talk[i]=j;}

fclose(out);

//for (i=1;i<=osszkult;i++) {sprintf(st,"%d  %5d %d %.3f %d",i,osszmot[i],ossztip[i],atltal[i],talk[i]);Form1->Memo1->Lines->Add(st);}



return(uts);


}



int felhobe(void)
{
int i, j, nsz, hossz, indx;
FILE *in;
char szam[20], *nptr;
char str[95000], *ptr, *strptr;

nptr=&szam[0];
nptr="c:/eurkat/felho.dat";
strptr=&str[0];

in=fopen(nptr, "r");
indx=_fileno(in); hossz=filelength(indx);
fread(strptr, 1, hossz, in);
fclose(in);

for (i=0;i<=NVEKT;i++) {notael[i]=0;}

ptr=&szam[0];
strptr=&str[0];  indx=0; j=1;
while (j<hossz) {
	  for (i=0; i<20; i++) {szam[i]=0;}
      //for (i=0; i<4; i++) {szam[i]=*strptr++;j++;} strptr++;

      while (strncmp(strptr,"0",1)!=0 &&
             strncmp(strptr,"1",1)!=0 &&
             strncmp(strptr,"2",1)!=0 &&
             strncmp(strptr,"3",1)!=0 &&
             strncmp(strptr,"4",1)!=0 &&
             strncmp(strptr,"5",1)!=0 &&
             strncmp(strptr,"6",1)!=0 &&
             strncmp(strptr,"7",1)!=0 &&
             strncmp(strptr,"8",1)!=0 &&
             strncmp(strptr,"9",1)!=0
            ) {strptr++;j++;}

      if (j<hossz) {
        i=0;
        while (strncmp(strptr,"0",1)==0 ||
               strncmp(strptr,"1",1)==0 ||
               strncmp(strptr,"2",1)==0 ||
               strncmp(strptr,"3",1)==0 ||
               strncmp(strptr,"4",1)==0 ||
               strncmp(strptr,"5",1)==0 ||
               strncmp(strptr,"6",1)==0 ||
               strncmp(strptr,"7",1)==0 ||
               strncmp(strptr,"8",1)==0 ||
               strncmp(strptr,"9",1)==0
              ) {szam[i++]=*strptr++;j++;}

        if (i>0) {nsz=atoi(ptr); if (nsz<9999) {notael[nsz]=1; indx++; cim[indx]=nsz; Form1->Memo1->Lines->Add(cim[indx]);}}
      }
}

indx=0; for (i=elso;i<=utso;i++) {indx+=notael[i];}
fclose(in);
return(indx);

}



//---------------------------------------------------------------------------------------------------------


// -------------vector generation from digital notation codes: vektorok[][], hanghiszt[][] ----------------------

void vnfkatal(char *nevp, int sorsz)
{
FILE *in;
int i;
char *ptr, *fptr, adat[100], nev[50];
long int offs;

/*nevp=&nevs[0]; nevp="c:/eurkat/katalogus.dat";*/
fptr=&adat[0];

in=fopen(nevp, "rt"); offs=((long)sorsz-1)*32;
fseek(in, offs, 0);
fread(fptr, 1, 31, in);
fclose(in);

fptr=&adat[0];
for (i=0; i<50; i++) {nev[i]=0; nevs[i]=0;}
ptr=fptr; i=0;
while (i<31) {nevs[i++]=*ptr++;} nevs[30]=0;

i=0; while (nevs[i]!=32 && i<32) {i++;}
while(i<50) {nevs[i++]=0;}

delete nev,adat;

}


int vnfbe(char *nevp, char *fogp)
{
int indx,hossz;
FILE *in;

in=fopen(nevp, "r");  if (in==NULL) {return(0);}
indx=_fileno(in); hossz=filelength(indx);
fread(fogp, 1, hossz, in);
fclose(in);

return(hossz);
}


void vnfeloj(int n)
{
// *** +n a b-k szama, -n a #-eke. ****

int i;

for (i=-10; i<70; i++) {bej[i+10]=0;}

if (n>=1) {bej[11+10]=1; bej[23+10]=1; bej[-1+10]=1;}
if (n>=2) {bej[16+10]=1; bej[4+10]=1;}
if (n>=3) {bej[9+10]=1; bej[21+10]=1; bej[-3+10]=1;}
if (n==4) {bej[14+10]=1; bej[2+10]=1; bej[26+10]=1;}

if (n<=-1) {bej[5+10]=-1; bej[17+10]=-1;}
if (n<=-2) {bej[12+10]=-1; bej[24+10]=-1; bej[0+10]=-1;}
if (n<=-3) {bej[19+10]=-1; bej[7+10]=-1; bej[-5+10]=-1;}
if (n==-4) {bej[14+10]=-1; bej[2+10]=-1;}

}


int vnftransz(char *nevp, int dallamsorsz)
{
char *cptr, *ptr, *sorptr, *csptr, *kitptr, sor[500];
char csop[20];
int i,j,k,l,szaml,hanysor,sorszaml,hangszaml,sorhossz,osszhossz, hossz, nn1, utemv;
int hangm,khang,idotart,szunet,tr=0,sorok[50][800],nn[50],*pufptr,puf[3000];
float fl;

for (i=0;i<1000;i++) {vnf[i]=0;}
for (i=0;i<3000;i++) {puf[i]=1000;}
for (i=0;i<50;i++) {nn[i]=0;
  for (j=0;j<800;j++) {sorok[i][j]=1000;hang[i][j]=1000;ritm[i][j]=1000;}
}

//Form1->Memo1->Lines->Add(dallamsorsz);
vnfkatal(nevp,dallamsorsz);
/*nevptr=&nev[0];nevptr="c:/eurkat//kotta/10-001-00-00a.vnf";*/
fogptr=&vnf[0]; nevptr=&nevs[0]; kitptr=&nevs[23];
hossz=vnfbe(nevptr,fogptr);
osszhossz=0; hanysor=0; nn1=1;

int nszun=0, elozo32,vaneloj=0;

ptr=&vnf[0];
eloj=0;
while (osszhossz<hossz) {

  for (i=0;i<500;i++) {sor[i]=0;} sorptr=&sor[0]; szaml=0; hanysor+=1;

  if (hanysor>49 || hanysor==0) {return(0);}

  while (*ptr!=10 && *ptr!=0) {*sorptr++=*ptr++;szaml++;} ptr++;
  sorhossz=szaml; nn[hanysor]=sorhossz;osszhossz+=sorhossz+2;
  if (sorhossz<3) {hanysor--;}
  sorptr=&sor[0]; szaml=0; sorszaml=0; hangszaml=1;

  elozo32=0; utemv=0;

  while (szaml<=sorhossz) {
    for (i=0;i<20;i++) {csop[i]=0;} csptr=&csop[0];
    while (*sorptr!=32 && szaml<=sorhossz) {*csptr++=*sorptr++;szaml++;}
    sorptr++;szaml++;


    cptr=strpbrk(csop,"K");
    if (cptr!=0) {eloj=atoi(++cptr);  vaneloj=1;
      if (strncmp(++cptr,"#",1)==0) {eloj*=-1;}
      vnfeloj(eloj);
    }
    if (cptr==0 && vaneloj==0) {vnfeloj(0);}



    cptr=strpbrk(csop,"R");
    if (cptr!=0) {szunet=atoi(++cptr);    nszun++;   if (szunet<=2) {szunet=4;}
      if (szunet==16) {idotart=1;}
      if (szunet==8) {idotart=2;}
      if (szunet==4) {idotart=4;}
      if (szunet==2) {idotart=8;}
      if (szunet==1) {idotart=16;}
      if (szunet==0) {idotart=16;}

      ritm[hanysor][hangszaml]=idotart;
      hang[hanysor][hangszaml]=40; hangszaml+=1;
	  for (i=0;i<idotart;i++) {sorszaml+=1;sorok[hanysor][sorszaml]=40;}
    }


    cptr=strpbrk(csop,"|");
    if (cptr!=0) {szunet=atoi(++cptr);
      ritm[hanysor][hangszaml]=41;
      hang[hanysor][hangszaml]=41; hangszaml+=1; utemv+=1;
    }



    cptr=strpbrk(csop,"CDEFGAH");
    if (cptr!=0) {
      if (strncmp(cptr,"C",1)==0) {hangm=0; khang=-2;}
      if (strncmp(cptr,"D",1)==0) {hangm=2; khang=-1;}
      if (strncmp(cptr,"E",1)==0) {hangm=4; khang=0;}
      if (strncmp(cptr,"F",1)==0) {hangm=5; khang=1;}
      if (strncmp(cptr,"G",1)==0) {hangm=7; khang=2;}
      if (strncmp(cptr,"A",1)==0) {hangm=9; khang=3;}
      if (strncmp(cptr,"H",1)==0) {hangm=11; khang=4;}
      if (strncmp(++cptr,"2",1)==0) {hangm+=12; khang+=7;}
      if (strncmp(cptr,"3",1)==0)   {hangm+=24; khang+=14;}
      if (strncmp(cptr,"0",1)==0)   {hangm-=12; khang-=7;}
      if (hangm>=-10) {hangm-=bej[hangm+10];}


      if (strncmp(&csop[0],"#",1)==0) {hangm+=1; khang+=100;}
      if (strncmp(&csop[0],"b",1)==0) {hangm-=1; khang-=100;}

      cptr-=2;
      //if (strncmp(cptr,"6",1)==0) {idotart=1;}
      cptr-=1; if (strncmp(cptr,"32",1)==0) {idotart=1;} cptr++;

      cptr-=1; if (strncmp(cptr,"16",1)==0) {idotart=1;} cptr++;
      if (strncmp(cptr,"8",1)==0) {idotart=2;}
      if (strncmp(cptr,"4",1)==0) {idotart=4;}
      if (strncmp(cptr,"2",1)==0) {idotart=8;}
      if (strncmp(cptr,"1",1)==0) {idotart=16;}
      if (strncmp(cptr,"0",1)==0) {idotart=16;}

      cptr+=3;
      if (strncmp(cptr,".",1)==0) {idotart+=idotart/2;}

      hang[hanysor][hangszaml]=khang;
      ritm[hanysor][hangszaml]=idotart; hangszaml++;

      /*
      int melizma=0;
      if (idotart==1 && elozo32==0) {idotart=1; elozo32=1;melizma=1;}
      if (idotart==1 && elozo32==1 && melizma==0) {idotart=0; elozo32=0;}
      */

      for (i=0;i<idotart;i++) { if (sorszaml<800) {sorszaml+=1;}
        sorok[hanysor][sorszaml]=hangm;
      }
    }
  }

  for (i=1;i<=sorszaml;i++) {
    k=sorok[hanysor][i];
    if (k==40 && i>1) {sorok[hanysor][i]=sorok[hanysor][i-1];}
  }
  for (i=sorszaml;i>=1;i--) {
    k=sorok[hanysor][i];
    if (k==40 && i<sorszaml) {sorok[hanysor][i]=sorok[hanysor][i+1];}
  }
/*
  for (i=1;i<=hangszaml;i++) {
    hangm=hang[hanysor][i];
    if (hangm==40 && i>1) {hang[hanysor][i]=hang[hanysor][i-1];}
  }
  for (i=hangszaml;i>=1;i--) {
    hangm=hang[hanysor][i];
    if (hangm==40 && i<hangszaml) {hang[hanysor][i]=hang[hanysor][i+1];}
  }
*/

  if (hanysor==1) {szotag[dallamsorsz]=hangszaml-utemv-1;sorido[dallamsorsz]=sorszaml;}

}

//if (vaneloj==0) {Form1->Memo1->Lines->Add(dallamsorsz);}


ptr=&nevs[0];i=0;
while (nevs[i]!=0 && i<30) {ptr++;i++;}
ptr-=3;
tr=hangm-7;

if (strcmp(ptr,"hnt")==0 /*&& hanysor==1*/) {tr=0;}
if (strcmp(ptr,"vnf")==0) {tr=0;}
//if (strcmp(ptr,"wnf")==0) {tr=0;}

//Form1->Memo1->Lines->Add(tr);
dimvet=32;
for (l=1;l<=hanysor;l++) {pufptr=&puf[1];nn1=0;
  i=1; while (sorok[l][i]!=1000) {*pufptr++=sorok[l][i++]-tr;}
  nn1=i-1;
  fl=(float)nn1/(float)dimvet;
  for (i=1; i<=dimvet; i++) {j=(int)(fl*(float)i+.5);
	  if (j<1) {j=1;} if (j>nn1) {j=nn1;} nysor[l][i]=puf[j];
  }
  nysor[l][dimvet+1]=1000;
}


//if (strcmp(ptr,"wnf")==0) {tr=0;}
/* G-re transzponalas */

int gtransz=7-hangm, ktransz;
int dohely[12][3],doh=0;

if (tr!=0) {
if (khang<40) {ktransz=2-khang;}
if (khang==40) {ktransz=2-hang[hanysor][hangszaml-1];}

dohely[1][1]=-5;dohely[1][2]=11;
dohely[2][1]=-4;dohely[2][2]=4;
dohely[3][1]=-3;dohely[3][2]=9;
dohely[4][1]=-2;dohely[4][2]=2;
dohely[5][1]=-1;dohely[5][2]=7;
dohely[6][1]=0;dohely[6][2]=0;
dohely[7][1]=1;dohely[7][2]=5;
dohely[8][1]=2;dohely[8][2]=10;
dohely[9][1]=3;dohely[9][2]=3;
dohely[10][1]=4;dohely[10][2]=8;
dohely[11][1]=5;dohely[11][2]=1;


for (i=1;i<=11;i++) {if(dohely[i][1]==eloj) {doh=dohely[i][2];}}
doh+=gtransz; if (doh>=12) {doh-=12;}  if (doh>=12) {doh-=12;} if (doh<0) {doh+=12;}
for (i=1;i<=11;i++) {if(dohely[i][2]==doh) {eloj=dohely[i][1];}}


for (l=1;l<=hanysor;l++) {
  i=1; while (hang[l][i]<1000) {if (hang[l][i]<40 || hang[l][i]>60) {hang[l][i]+=ktransz;}i++;}
}

}  // if (tr!=0)

//if (eloj>0 && eloj<3) {Form1->Memo1->Lines->Add(dallamsorsz);}     // moll dallamok list�z�sa

/*
if (strcmp(ptr,"wnf")==0) { ktransz=-3; tr=5; eloj=-1;

  for (l=1;l<=hanysor;l++) {pufptr=&puf[1];nn1=0;
    i=1; while (sorok[l][i]!=1000) {*pufptr++=sorok[l][i++]-tr;}
    nn1=i-1;
    fl=(float)nn1/(float)dimvet;
    for (i=1; i<=dimvet; i++) {j=(int)(fl*(float)i+.5);
	  if (j<1) {j=1;} if (j>nn1) {j=nn1;} nysor[l][i]=puf[j];
    }
    nysor[l][dimvet+1]=1000;
  }



  for (l=1;l<=hanysor;l++) {
    i=1; while (hang[l][i]<1000) {if (hang[l][i]<40 || hang[l][i]>60) {hang[l][i]+=ktransz;}i++;}
  }

}
*/
/* ------------------------------------------------ */


/*
if (khang<-4) {
  for (l=1;l<=hanysor;l++) {
    i=1; while (hang[l][i]<1000) {if (hang[l][i]!=40) {hang[l][i]+=7;}i++;}
  }
}

if (khang>7 && khang!=40) {
  for (l=1;l<=hanysor;l++) {
    i=1; while (hang[l][i]<1000) {if (hang[l][i]!=40) {hang[l][i]-=7;}i++;}
  }
}
*/


/*
int dim;

if (nsor<=4) {dim=dimenz;}
if (nsor==11 || nsor==12) {dim=dimenz/2;}
if (nsor==10) {dim=dimenz/4;}


dim=dimvet;

for (l=1;l<=hanysor;l++) {pufptr=&puf[1];nn1=0;
  i=1; while (sorok[l][i]!=1000) {*pufptr++=sorok[l][i++]-tr;}
  nn1=i-1;

  fl=(float)nn1/(float)(dim);
  for (i=1; i<=dim; i++) {j=(int)(fl*(float)i+.5);
	  if (j<1) {j=1;} if (j>nn1) {j=nn1;} nysor[l][i]=puf[j];
  }


//  mdim=nn1;
//  fl=(float)(dim)/(float)(mdim); szaml=1;
//  for (i=1; i<=mdim; i++) {ahat=szaml; fhat=(int)(fl*(float)i+.5);
//    for (j=ahat;j<=fhat;j++) {nysor[l][szaml]=(float)(puf[i]);szaml++;}
//  }

  nysor[l][dim+1]=1000;

}
*/

for (i=0;i<3000;i++) {puf[i]=1000;}

tr=0;

if (nsor<=2) {pufptr=&puf[1]; nn1=0;
  i=1; while (nysor[nsor][i]!=1000) {*pufptr++=nysor[nsor][i++]-tr;}
  nn1=i-1;
}

if (nsor==3 || nsor==4) {pufptr=&puf[1]; k=4-nsor; j=hanysor-k; nn1=0;
   if (hanysor==1) {j=1;}
  i=1; while (nysor[j][i]!=1000) {*pufptr++=nysor[j][i++]-tr;} nn1=i-1;
}

// els� sorp�r - 1 megold.

/*
if (nsor==11) {pufptr=&puf[1]; nn1=0; j=1; k=2;
  if (hanysor==1) {k=1;}
  i=1; while (sorok[j][i]!=1000) {*pufptr++=sorok[j][i++]-tr;} nn1=i-1;
  i=1; while (sorok[k][i]!=1000) {*pufptr++=sorok[k][i++]-tr;} nn1+=i-1;

}
*/

//----------------------------------------------------


// els� sorp�r - 2 megold.



if (nsor==11 && 2<hanysor) {pufptr=&puf[1]; nn1=0; j=1; k=2;
  if (hanysor==1) {k=1;}
  i=1; while (nysor[j][i]!=1000) {*pufptr++=nysor[j][i++]-tr;} nn1=i-1;
  i=1; while (nysor[k][i]!=1000) {*pufptr++=nysor[k][i++]-tr;} nn1+=i-1;

}

int hosszusor;
if (szotag[dallamsorsz]>=hosszusorhsz && sorido[dallamsorsz]>=hosszusorido) {hosszusor=1;} else {hosszusor=0;}

if (nsor==11 && hanysor<=2 && hosszusor==1) {pufptr=&puf[1]; nn1=0; j=1;
  i=1; while (nysor[j][i]!=1000) {*pufptr++=nysor[j][i++]-tr;} nn1=i-1;
}

if (nsor==11 && hanysor<=2 && hosszusor==0) {pufptr=&puf[1]; j=1; k=2;
  if (hanysor==1) {k=1;}
  i=1; while (nysor[j][i]!=1000) {*pufptr++=nysor[j][i++]-tr;} nn1=i-1;
  i=1; while (nysor[k][i]!=1000) {*pufptr++=nysor[k][i++]-tr;} nn1+=i-1;

}

//----------------------------------------------------


if (nsor==12) {pufptr=&puf[1]; j=hanysor-1; k=hanysor; //nn1=0;
   if (hanysor==1) {j=1;}
  i=1; while (nysor[j][i]!=1000) {*pufptr++=nysor[j][i++]-tr;} nn1=i-1;
  i=1; while (nysor[k][i]!=1000) {*pufptr++=nysor[k][i++]-tr;} nn1+=i-1;
}



/*
if (nsor==10) {pufptr=&puf[1]; nn1=0;
 for (k=1;k<=hanysor;k++) {
  i=1; while (sorok[k][i]!=1000) {*pufptr++=sorok[k][i++]-tr;}
  if (k==1) {nn1=i-1;} else {nn1+=i-1;}
 }
}
*/


if (nsor==10) {pufptr=&puf[1]; nn1=0;

/*
if (hanysor==1) {
 k=1; i=1; while (sorok[k][i]!=1000) {*pufptr++=sorok[k][i++]-tr;} nn1=i-1;
}

if (hanysor==2) {
 k=1; i=1; while (sorok[k][i]!=1000) {*pufptr++=sorok[k][i++]-tr;} nn1=i-1;
 k=1; i=1; while (sorok[k][i]!=1000) {*pufptr++=sorok[k][i++]-tr;} nn1+=i-1;
 k=hanysor; i=1; while (sorok[k][i]!=1000) {*pufptr++=sorok[k][i++]-tr;} nn1+=i-1;
 k=hanysor; i=1; while (sorok[k][i]!=1000) {*pufptr++=sorok[k][i++]-tr;} nn1+=i-1;
}


if (hanysor==3) {
 k=1; i=1; while (sorok[k][i]!=1000) {*pufptr++=sorok[k][i++]-tr;} nn1=i-1;
 k=1; i=1; while (sorok[k][i]!=1000) {*pufptr++=sorok[k][i++]-tr;} nn1+=i-1;
 k=hanysor-1; i=1; while (sorok[k][i]!=1000) {*pufptr++=sorok[k][i++]-tr;} nn1+=i-1;
 k=hanysor;   i=1; while (sorok[k][i]!=1000) {*pufptr++=sorok[k][i++]-tr;} nn1+=i-1;
}
*/

if (szotag[dallamsorsz]>=hosszusorhsz && sorido[dallamsorsz]>=32) {hosszusor=1;} else {hosszusor=0;}
if (hanysor==1 && hosszusor==0) {
 for (k=1;k<=4;k++) {
  i=1; while (nysor[1][i]!=1000) {*pufptr++=nysor[1][i++]-tr;}
  if (k==1) {nn1=i-1;} else {nn1+=i-1;}
 }
}

if (hanysor==1 && hosszusor==1) {
 for (k=1;k<=2;k++) {
  i=1; while (nysor[1][i]!=1000) {*pufptr++=nysor[1][i++]-tr;}
  if (k==1) {nn1=i-1;} else {nn1+=i-1;}
 }
}

if (1<hanysor && hanysor<=4) {
 for (k=1;k<=hanysor;k++) {
  i=1; while (nysor[k][i]!=1000) {*pufptr++=nysor[k][i++]-tr;}
  if (k==1) {nn1=i-1;} else {nn1+=i-1;}
 }
}


if (hanysor>4) {
 k=1; i=1; while (nysor[k][i]!=1000) {*pufptr++=nysor[k][i++]-tr;} nn1=i-1;
 k=2; i=1; while (nysor[k][i]!=1000) {*pufptr++=nysor[k][i++]-tr;} nn1+=i-1;
 k=hanysor-1; i=1; while (nysor[k][i]!=1000) {*pufptr++=nysor[k][i++]-tr;} nn1+=i-1;
 k=hanysor;   i=1; while (nysor[k][i]!=1000) {*pufptr++=nysor[k][i++]-tr;} nn1+=i-1;
}
}


fl=(float)nn1/(float)dimenz;  tr=puf[nn1]*(int)vegtransz;
for (i=1; i<=dimenz; i++) {j=(int)(fl*(float)i+.5);
	  if (j<1) {j=1;} if (j>nn1) {j=nn1;} s1[i]=puf[j]-tr;
}


// ----------------- ritmus -----------------------------------------
/*
int utesszam, vsor;
if (nsor<=8) {vsor=nsor;}
if (nsor==11) {vsor=2;  if (hanysor<2) {vsor=1;}}
if (nsor==10) {vsor=hanysor;  if (hanysor>14) {vsor=14;}}

//vsor=1;

for (i=0;i<=1000;i++) {utes[dallamsorsz][i]=0;} j=0; utes[dallamsorsz][1]=1; utesszam=1; idotart=1;
for (l=1;l<=vsor;l++) {
  i=1;
  while(ritm[l][i]!=1000) {
    if (ritm[l][i]<20 && hang[l][i]<40) {idotart+=ritm[l][i];utesszam++;utes[dallamsorsz][utesszam]=idotart;}
    if (hang[l][i]==40) {idotart+=ritm[l][i]; utes[dallamsorsz][utesszam]=idotart;}
    i++;
  }
}

utes[dallamsorsz][0]=(float)(utesszam-1);
*/


// ----------------- ritmus-soronk�nt -----------------------------------------

int utesszam, vsor;
if (nsor<=14) {vsor=nsor;}  else {vsor=14;}

//vsor=1;

//Form1->Memo1->Lines->Add("ritm:");
for (i=0;i<=14;i++) {for (j=0;j<=33;j++) {utes0[i][j]=0;} utes0[i][1]=1;}
for (l=1;l<=vsor;l++) {  utesszam=1; idotart=1;
  i=1;
  while(ritm[l][i]!=1000) {
    if (ritm[l][i]<20 && hang[l][i]<40) {idotart+=ritm[l][i];utesszam++;utes0[l][utesszam]=idotart;}
    if (hang[l][i]==40) {idotart+=ritm[l][i]; utes0[l][utesszam]=idotart;}
    //if (hang[l][i]==41 && hang[l][i+1]<1000) {utes[dallamsorsz][l][utesszam]+=1000;}
    i++;
  }
  utes0[l][0]=(float)(utesszam);
}


float hiszt0[40];
int osszido;
for (i=0;i<40;i++) {hiszt0[i]=0;}  osszido=0;
//Form1->Memo1->Lines->Add(dallamsorsz);
for (i=1;i<=hanysor;i++) {
    k=1;
    while (nysor[i][k]!=1000) { hangm=nysor[i][k];
      if (hangm<30 && hangm>-30) {hiszt0[(int)(hangm+0.5)-7+8]+=1;osszido+=1;}
      k++;
    }
}
if (osszido==0) {osszido=1;}
for (i=1;i<40;i++) {hanghiszt[dallamsorsz][i]=50*hiszt0[i]/osszido;}


/*
for (l=1;l<=vsor;l++) { k=utes[dallamsorsz][l][0];
  Form1->Memo1->Lines->Add(" ");
  for (j=1;j<=k;j++) {Form1->Memo1->Lines->Add(utes[dallamsorsz][l][j]);}
}
*/

return(hanysor);

}


int vektfeltoltvnf(char *nevp, int dimenz, int vektszam)
{
int i,j;

//nsor=10;

vektszam=dallamszam(nevp); vektorszam=vektszam;

for (i=1;i<=vektszam;i++) {
  hanysor=vnftransz(nevp,i); notael[i]=1;  rokon[i]=0; zh[1]=7; hanys[i]=hanysor;
  for (j=1;j<=dimenz;j++) {vektorok[i][j]=s1[j];}
}

return(vektszam);
}

void katalki(char *vnfnev, int vektsz)
{
int i;
FILE *out;
char s[100];

out=fopen("c:/eurkat/valkatal.dat","a");

int szaml=1;
for (i=1;i<=vektsz;i++) {
  //if (csop[i]<0) {
  if (rokon[i]==1 && szaml<=1000) {
     for (j=0;j<100;j++) {s[j]=0;}
     for (j=0;j<30;j++) {nevs[j]=' ';}
     vnftransz(vnfnev,cim[i]);Form1->Memo1->Lines->Add(nevs);
     for (j=strlen(nevs);j<30;j++) {nevs[j]=' ';}
     sprintf(s,"%s\n",nevs);
     fwrite(s,31,1,out); szaml++;
  }
}
fclose(out);

}

//-----------------------------------------------------------------------------------------

//---------------------- generation of clusters -------------------------------------------

void felhoki(int vektsz, int tipsz, int mintagsz)
{
int i,j,k,tagsz, tiptagsz[1001];
char s[20];
float fl;

for (i=1;i<=1000;i++) {tiptagsz[i]=0;}

for (i=1;i<=NVEKT;i++) {rokon[i]=0;}

//Form1->Memo1->Lines->Add(vektsz);   Form1->Memo1->Lines->Add(tipsz);
for (i=1;i<=vektsz;i++) {fl=keresfh(i); if (fl<=2.0) {rokon[i]=minsorszam;csop[i]=minsorszam; tiptagsz[minsorszam]++;} }

FILE *out=fopen("c:/eurkat/felho.dat","w");

for (i=1;i<=tipsz;i++) {  tagsz=0;
  //for (k=0;k<20;k++) {s[k]=0;} sprintf(s,"%4d   ",i);fwrite(s,strlen(s),1,out);
  for (j=1;j<=vektsz;j++) {
    //rokon[j]=0; fl=tiptavmerfh(j,i,0);  if (fl<.775) {rokon[j]=i;}       // .775    .992
    for (k=0;k<20;k++) {s[k]=0;}
    if (rokon[j]==i && tiptagsz[i]>=mintagsz) { sprintf(s,"%4d ",cim[j]);fwrite(s,strlen(s),1,out); tagsz++;}

  }
  if (tagsz>0) {sprintf(s,"%4d ",cim[i]);fwrite(s,strlen(s),1,out); fwrite(" \n",1,2,out);  fwrite(" \n",1,2,out);}
}
fclose(out);

}



void gerjki(float rtavkusz)
{
int i,j,k,szaml;
float fl;
char s[20];

FILE *out;
out=fopen("c:/eurkat/gerj.dat","w");

rtavkusz=rtavkusz*1;

for (k=1;k<=vektorszam;k++) {  cim[k]=k; rokon[cim[k]]=0;  talalat[cim[k]]=0;}

for (i=1;i<=utso;i++) {   szaml=0;
  for (k=1;k<=vektorszam;k++) {  //cim[k]=k; rokon[cim[k]]=0;  talalat[cim[k]]=0;
    //for (i=1;i<=4;i++) {fl=vektkoord0[k][i]-vektkoord0[srsz][i]; rtav+=fl*fl;} rtav/=1.0;
    //rtav=0; for (j=1;j<=dimenz;j++) {fl=vektorok[k][j]-w[i][1][j]; rtav+=fl*fl;} rtav/=(float)dimenz; fl=rtav;
    fl=tiptavmerfh(k,i,0);
    //Form1->Memo1->Lines->Add(fl);
    if (fl<rtavkusz) {rokon[cim[k]]=i;talalat[cim[k]]=2; szaml++; for (j=0;j<20;j++) {s[j]=0;} sprintf(s,"%d ",cim[k]); fwrite(s,1,strlen(s),out);}
  }
  if (szaml>=1) {sprintf(s,"   %d",i); fwrite(s,strlen(s),1,out); fwrite(" \n",1,2,out);   fwrite(" \n",1,2,out);}
}

fclose(out);
/*
out=fopen("c:/eurkat/gerj.dat","w");
for (i=1;i<=utso;i++) {   szaml=0;
  for (k=1;k<=vektorszam;k++) {
    if (rokon[cim[k]]==i) { szaml++;
       for (j=0;j<20;j++) {s[j]=0;} sprintf(s,"%d ",cim[k]); fwrite(s,1,strlen(s),out);
    }
  }
  if (szaml>=1) {sprintf(s,"   %d",i); fwrite(s,strlen(s),1,out); fwrite(" \n",1,2,out);   fwrite(" \n",1,2,out);}
}
fclose(out);
*/

}


//---------------------------------------------------------------------------------

// --------------- Student t-statistics -------------------------
float tabl[100][100];
float* tablazatbe(char *nevp, char *fogp, int vektszam, char szun)
{
int i,szaml, poz, dim,indx;
FILE *in;
char str[20], *ptr, *sptr, ch;
float fl;
int hossz;
//float tabl[100][100];


in=fopen(nevp, "r");
indx=_fileno(in); hossz=filelength(indx);
fread(fogp, 1, hossz, in);
fclose(in);

//vektszam=hossz/296;
//vektszam=34;
ptr=fogp;
//i=1; while (*ptr!=10) {ptr++;i++;} i++; vektszam=hossz/i;

ptr=fogp;  sptr=&str[0]; szaml=0; poz=0;

while (szaml!=vektszam) { ch=0; //Form1->Memo1->Lines->Add(szaml);
	for (i=0; i<20; i++) { str[i]=0;}
    while (*ptr==szun) {ptr++;}
	i=0; while (ch!=szun && ch!=10 && i<20) {
      ch=*ptr++;
      str[i++]=ch;
    } //ptr++;
    fl=atof(sptr);   //Form1->Memo1->Lines->Add(fl);
	if (fl!=1000) {tabl[szaml+0][poz]=fl; poz++;}
	//else {szaml++; dim=poz-1; poz=1;}
    if (ch==10) {szaml++; dim=poz-1; poz=0;}
}

return(&tabl[0][0]);

}

void tproba(int vektsz, int tipsz, float m)
{
int i,j;
float fl, szoras[NPONT+1], tagsz[NPONT+1], t[NPONT+1];

for (i=1;i<=tipsz; i++) { szoras[i]=0; tagsz[i]=0.0;}

for (i=1;i<=tipsz; i++) { tagsz[i]=0.0;
  for (j=1;j<=vektsz;j++) {
    if (rokon[j]==i) { fl=keresfh(j); szoras[i]+=fl*fl; tagsz[i]+=1.0;}
  }
}


/*
int k, szaml; float atl[NPONT+1][NDIM+1];
for (i=1;i<=tipsz;i++) {
  for (k=1;k<=dimenz;k++) {atl[i][k]=0;} szaml=0;
  for (j=1;j<=vektsz;j++) {
    if (rokon[j]==i) { for (k=1;k<=dimenz;k++) {atl[i][k]+=vektorok[j][k]; szaml++;}  }
  }
  if (szaml==0) {szaml=1;}
  for (k=1;k<=dimenz;k++) {atl[i][k]/=(float)szaml;}
}

for (i=1;i<=tipsz;i++) { szoras[i]=0; tagsz[i]=0;
  for (j=1;j<=vektsz;j++) {
    if (rokon[j]==i) { for (k=1;k<=dimenz;k++) {fl=atl[i][k]-vektorok[j][k]; szoras[i]+=fl*fl;} tagsz[i]+=1;}  }
  }
}
*/


//m=2;

for (i=1;i<=tipsz;i++) {if (tagsz[i]<1) {tagsz[i]=1.0;} szoras[i]/=(tagsz[i]); szoras[i]=sqrt(szoras[i]);}
for (i=1;i<=tipsz;i++) { if (szoras[i]>0) {t[i]=fabs((0-m)/(szoras[i]/sqrt(tagsz[i])));} else {t[i]=100;}}

int szf, indx; char str[20];
tablazatbe("c:/eurkat/student-t-eo.txt",fogptr,36,9);
for (i=1;i<=tipsz;i++) {//Form1->Memo1->Lines->Add(t[i]);
   if (tagsz[i]<=30) {szf=tagsz[i]-1.0;}
   if (30<tagsz[i] && tagsz[i]<35) {indx=30;} else {indx=31;}
   if (40<tagsz[i] && tagsz[i]<50) {indx=31;} else {indx=32;}
   if (60<tagsz[i] && tagsz[i]<80) {indx=32;} else {indx=33;}
   if (100<tagsz[i] && tagsz[i]<110) {indx=33;} else {indx=34;}
   if (120<tagsz[i] && tagsz[i]<2000) {indx=34;} else {indx=35;}
   if (30<tagsz[i]) {szf=tabl[indx][0];}     //indx=szf;

   j=1; fl=0; while (t[i]>=tabl[indx][j] && j<=10) {j++;} if (1<j) {fl=tabl[0][j-1];} sprintf (str,"%4d %4d %6.3f %6.3f %6.3f",i,j,t[i],tabl[indx][j-1],fl); Form1->Memo1->Lines->Add(str);
}

}

void tproba0(int tipsorsz, int vektsz)
{

int i,j,k,szaml;
float atl[NDIM+1], tagsz, szoras, t, m, fl,fl1,fl2;

for (k=1;k<=dimenz;k++) {atl[k]=0;} szaml=0;
for (j=1;j<=vektsz;j++) {
  if (rokon[j]==tipsorsz) { for (k=1;k<=dimenz;k++) {atl[k]+=vektorok[j][k]; szaml++;}  }
}
if (szaml==0) {szaml=1;}
for (k=1;k<=dimenz;k++) {atl[k]/=(float)szaml;}

m=0; fl2=0;
for (k=1;k<=dimenz;k++) {fl1=w[tipsorsz][0][k]; fl=w[tipsorsz][1][k]-atl[k]; m+=fl*fl*fl1; fl2+=fl1;}
m=sqrt(m/fl2);

szoras=0; tagsz=0;
for (j=1;j<=vektsz;j++) {
  if (rokon[j]==tipsorsz) { for (k=1;k<=dimenz;k++) {fl=atl[k]-vektorok[j][k]; szoras+=fl*fl;} tagsz+=1;}
}
if (tagsz<1) {tagsz=1.0;} szoras/=(float)tagsz; szoras=sqrt(szoras);

if (szoras>0) {t=fabs((0-m)/(szoras/sqrt(tagsz)));} else {t=100;}

int szf, indx; char str[20];
tablazatbe("c:/eurkat/student-t-eo.txt",fogptr,36,9);

if (tagsz<=30) {szf=tagsz-1.0;}
if (30<tagsz && tagsz<35) {indx=30;} else {indx=31;}
if (40<tagsz && tagsz<50) {indx=31;} else {indx=32;}
if (60<tagsz && tagsz<80) {indx=32;} else {indx=33;}
if (100<tagsz && tagsz<110) {indx=33;} else {indx=34;}
if (120<tagsz && tagsz<2000) {indx=34;} else {indx=35;}
if (30<tagsz) {szf=tabl[indx][0];}     //indx=szf;

j=1; fl=0; while (t>=tabl[indx][j] && j<=10) {j++;} if (1<j) {fl=tabl[0][j-1];} sprintf (str,"%4d %4d %4d %6.3f %6.3f",tipsorsz,(int)tagsz,j,tabl[indx][j-1],fl); Form1->Memo1->Lines->Add(str);

FILE *out=fopen("c:/eurkat/tipatl.dat","a");
for (k=1;k<=dimenz;k++) {sprintf(str," %.3f", atl[k]); fwrite(str,strlen(str),1,out);}
fwrite(" \n",2,1,out); fclose(out);

}
//-------------------------------------------------------------------------------------------------

//------------------------- Distance measurement functions ------------------------------------------

float hanghiszttiptav(int dsorsz, int tipsorsz, int dim)
{
int i;
float tav, fl;

/*
for (i=1;i<=dim;i++) {suly[i]=0.2;}
suly[4]=1; suly[5]=1;
//suly[6]=1; suly[7]=1;
suly[11]=1; suly[12]=1;
suly[16]=1; suly[17]=1;
suly[18]=1; suly[19]=1;
norm=0; for (i=1;i<=dim;i++) {norm+=hangsuly[i];} if (norm==0) {norm=1.0;} for (i=1;i<=dim;i++) {hangsuly[i]*=norm;}
*/

tav=0;
for (i=1;i<=dim;i++) {fl=hanghiszt[dsorsz][i]-w[tipsorsz][2][i]; tav+=fl*fl*hangsuly[i];}
tav=sqrt(tav/hahinorm);

//Form1->Memo1->Lines->Add("tav: ");
//for (i=1;i<=30;i++) {Form1->Memo1->Lines->Add(hiszt1[i]);}
//for (i=1;i<=dim;i++) {Form1->Memo1->Lines->Add(nyd[pnt1][1][i]);}
//Form1->Memo1->Lines->Add(tav);

return(tav);

}


void vektnorm(int vektsz, int vektdim)
{
int i,j;
//float max[NDIM+1];

float sum;
for (i=1;i<=vektsz;i++) {
  sum=0; for (j=1;j<=vektdim;j++) {sum+=fabs(vektorok[i][j]);}
  //sum=-1000; for (j=1;j<=vektdim;j++) {if (sum<fabs(vektorok[i][j])) {sum=vektorok[i][j];}}
  if (sum==0) {sum=1;}
  for (j=1;j<=vektdim;j++) {vektorok[i][j]/=pow(sum,1.0);vektorok[i][j]*=20.0;}
}

}


float tavmod(int dsorsz, int vektdim)
{
int k;
float tsuly, maxhang, minhang, hangterjatl;
    /*
    hangterjatl=0;
    for (k=1;k<=dimenz;k++) {fl=w[xkoord][ykoord][1][k]-7.0;hangterjatl+=fabs(fl);}
    hangterjatl=hangterjatl/float(dimenz)/1.0;
    if (hangterjatl==0) {hangterjatl=.1;}
    */

    maxhang=0;
    for (k=1;k<=dimenz;k++) { if (fabs(vektorok[dsorsz][k])-7.0>maxhang) {maxhang=fabs(vektorok[dsorsz][k])-7.0;}}
    minhang=0;
    for (k=1;k<=dimenz;k++) { if (fabs(vektorok[dsorsz][k])-7.0<minhang) {minhang=fabs(vektorok[dsorsz][k])-7.0;}}

    hangterjatl=maxhang-minhang;
    if (hangterjatl<1) {hangterjatl=1;}

    tsuly=12.0/hangterjatl;
    if (tsuly>2) {tsuly=2;}
    if (tsuly<.8) {tsuly=.8;}

    if (dallamv==0) {tsuly=1;}
    //tsuly=1;

return(tsuly);

}


float suly[NDIM+1];
void sulyvekt(int vektsorsz, int vektdim)
{
float fl, sum;
int i,j;

//if (vektsorsz>utso) {Form1->Memo1->Lines->Add("???"); vektsorsz=utso;}
float max=0.0;  int maxi=0;
for (i=1;i<=vektdim;i++) {
  fl=vektorok[vektsorsz][i]-0.0;
  suly[i]=1.0-exp(-2.5*fl*fl);  if (suly[i]<.05) {suly[i]=.05;}
  //if (fl<.5) {suly[i]=.0;} else {suly[i]=1.0;}
  if (max<suly[i]) {max=suly[i];maxi=i;}
}
//if (max*.5<suly[vektdim]) {suly[vektdim]=0.05;}

sum=0;
for (i=1;i<=vektdim;i++) {sum+=suly[i];}
sum/=(float)vektdim;

if (sum==0) {sum=1.0;}

//for (i=1;i<=vektdim;i++) {suly[i]=0.05;}   suly[9]=1; suly[18]=1; suly[19]=1; suly[21]=1; suly[22]=1; suly[26]=1;  suly[27]=1;  sum=7/(float)vektdim;
for (i=1;i<=vektdim;i++) {suly[i]/=sum;}
//for (i=1;i<=vektdim;i++) {suly[i]=1;}


//return(&suly[0]);

}


void vekttavmatr(int vektsz, int tipsorsz)
{
int i,j,k;
float fl,fl1,fl2,max,atltav, tavm1,tavm2;
float sulyv1[NDIM+1],sulyv[NDIM+1];

for (i=1;i<=vektsz;i++) {
  for (j=1;j<=vektsz;j++) {vekttav[i][j]=0;}
}
for (i=1;i<=dimenz;i++) {sulyv[i]=w[tipsorsz][0][i];}


max=-10000;   atltav=0;
for (i=1;i<=vektsz;i++) {  tavm1=tavmod(i,dimenz);
  //sulyvekt(i,vektdim); for (k=1;k<=vektdim;k++) {sulyv1[k]=suly[k]/2;}
  for (j=1;j<=vektsz;j++) {
    //sulyvekt(j,vektdim); for (k=1;k<=vektdim;k++) {sulyv[k]=suly[k]/2+sulyv1[k];}

    //fl1=0;
    //for (k=1;k<=vektdim;k++) {fl=vektorok[i][k]-vektorok[j][k];fl1+=fl;}
    //atltav=fl1/(float)vektdim;

    fl1=0;
    for (k=1;k<=dimenz;k++) {fl=vektorok[i][k]-vektorok[j][k]-atltav;fl1+=fl*fl*sulyv[k];}
    //fl1/=(float)vektdim;
    fl1=sqrt(fl1);
    tavm2=tavmod(j,dimenz); if (tavm1<tavm2) {tavm1=tavm2;}fl1*=tavm1;

    fl2=0;
    for (k=1;k<=dimenz2;k++) {fl=hanghiszt[i][k]-hanghiszt[j][k];fl2+=fl*fl*hangsuly[k];}
    fl2=sqrt(fl2);

    fl=(1-hahisuly)*fl1+hahisuly*fl2;   Form1->Memo1->Lines->Add(fl);
    vekttav[i][j]=fl;

    if (max<fl) {max=fl;}
  }

}

return;

}


float tavmeres0(int sorsz1, int sorsz2)
{
int k;
float fl,fl1,fl2,tavm1,tavm2,val,mer,sulyv[NDIM+1];

//tavm1=tavmod(sorsz1,vektdim);

sulyvekt(sorsz1,dimenz); for (k=1;k<=dimenz;k++) {sulyv[k]=suly[k]/2.0;}
sulyvekt(sorsz2,dimenz); for (k=1;k<=dimenz;k++) {sulyv[k]+=suly[k]/2.0;}
//for (k=1;k<=dimenz1;k++) {sulyv[k]=1.0;}
fl1=0; fl2=0;
for (k=1;k<=dimenz;k++) {fl=vektorok[sorsz1][k]-vektorok[sorsz2][k];fl1+=fl*fl*sulyv[k];fl2+=sulyv[k];}
//fl1/=(float)vektsz;
fl1=sqrt(fl1/fl2);     //Form1->Memo1->Lines->Add(fl1);

fl2=0;
for (k=1;k<=dimenz2;k++) {fl=hanghiszt[sorsz1][k]-hanghiszt[sorsz2][k];fl2+=fl*fl*hangsuly[k];}
fl2=sqrt(fl2);
fl=(1-hahisuly)*fl1+hahisuly*fl2;   //Form1->Memo1->Lines->Add(fl);

fl2=6;
if (hahisuly<=0.41) {fl2=4.5;}
if (hahisuly<=0.01) {fl2=3.2;}
if (fl>fl2) {fl=fl2;}   // hahisuly=0.3: 4.5,  5   hahisuly=1: 6.0    hahisuly=0: 3.5, 3.2
//tavm2=tavmod(sorsz2,vektdim); if (tavm1<tavm2) {tavm1=tavm2;}fl1*=tavm1;

//mer=log(.5)/tk/tk;   //Form1->Memo1->Lines->Add(mer);
//mer=log(.5)/tk;
//val=1.0;
//if (fl1>tk*0.33 && sorsz1!=sorsz2 && notael[sorsz1]==1 && notael[sorsz2]==1) {/*rokvalosz=expon[int(fl1/tavlep+.5)];*/ rokvalosz=exp(mer*fl1);}

return(fl);

}

float expon[1001], tavlep;
float rokvalosz;

float tavmeres(int sorsz1, int sorsz2, int vektdim, float tk)
{
int k;
float fl,fl1,fl2,tavm1,tavm2,val,mer,sulyv[NDIM+1];

tavm1=tavmod(sorsz1,dimenz);

//sulyvekt(sorsz1,dimenz); for (k=1;k<=dimenz;k++) {sulyv[k]=suly[k]/2.0;}
//sulyvekt(sorsz2,dimenz); for (k=1;k<=dimenz;k++) {sulyv[k]+=suly[k]/2.0;}
for (k=1;k<=dimenz;k++) {sulyv[k]=1.0;}
fl1=0; fl2=0;
for (k=1;k<=dimenz;k++) {fl=vektorok[sorsz1][k]-vektorok[sorsz2][k];fl1+=fl*fl*sulyv[k];fl2+=sulyv[k];}
//fl1/=(float)vektsz;
fl1=sqrt(fl1/fl2);     //Form1->Memo1->Lines->Add(fl1);

fl2=0;
for (k=1;k<=dimenz2;k++) {fl=hanghiszt[sorsz1][k]-hanghiszt[sorsz2][k];fl2+=fl*fl*hangsuly[k];}
fl2=sqrt(fl2);
fl=(1-hahisuly)*fl1+hahisuly*fl2;   //Form1->Memo1->Lines->Add(fl);

tavm2=tavmod(sorsz2,dimenz); if (tavm1<tavm2) {tavm1=tavm2;} fl*=tavm1;

//mer=log(.5)/tk/tk;   //Form1->Memo1->Lines->Add(mer);
mer=log(.5)/tk;
//val=1.0;
if (fl>tk*0.33 && sorsz1!=sorsz2 && notael[sorsz1]==1 && notael[sorsz2]==1) {/*rokvalosz=expon[int(fl1/tavlep+.5)];*/ rokvalosz=exp(mer*fl);}

return(fl);

}

// ---------- MRP clustering functions (not in use) --------------------------------------

float rokval[NVEKT_MIN+1][NVEKT_MIN+1];
//float rokval[NVEKT+1][NVEKT+1];
float mer(int vektsz, int pnt, float tk)
// *** pnt-tol meri az osszes ELO pont tav.-gat, kiszamitja az inform-t **
// *** rokon[k]-ba 4-et ir, ha a k pont kozel van pnt-hez *****

{
int k;
float fl,val,mer,tav,tavols[NVEKT+1];


//roksz=0;
for (k=1; k<=vektsz; k++) { tavols[k]=0;
  //if (pnt!=k /*&& notael[k]==1*/) { tav=vekttav[pnt][k]; tavols[k]=tav/nyujt2;}
  if (pnt!=k /*&& notael[k]==1*/) { tav=tavmeres(pnt,k,dimenz,tk); tavols[k]=tav;}


}

mer=log(.5)/tk;
//mer=log(.5)/tk/tk;   //Form1->Memo1->Lines->Add(mer);
val=1.0;
for (k=1; k<=vektsz; k++) {
  if (tavols[k]>tk*0.33 && k!=pnt && notael[k]==1) {
	  //fl=exp(mer*tavols[k]);  rokval[pnt][k]=fl; rokval[k][pnt]=fl;//Form1->Memo1->Lines->Add(fl);
      fl=expon[int(tavols[k]/tavlep+.5)];  //rokval[pnt][k]=fl; rokval[k][pnt]=fl;//Form1->Memo1->Lines->Add(fl);
	  //fl=exp(mer*tavols[k]*tavols[k]);  rokval[pnt][k]=fl; rokval[k][pnt]=fl;//Form1->Memo1->Lines->Add(fl);
	  val*=(1.0-fl);
  }
}
val=1.0-val;
if (val<=0) {val=.000001;}
if (val>=1) {val=.9999;}
//Form1->Memo1->Lines->Add(val);


/*
val=0;
for (k=1; k<=pontsz; k++) {
	if (tavols[k]>TAVMIN && notael[k]==1) {
		fl=exp(mer*tavols[k]); val=val+fl-val*fl;
	}
}
*/

//float ainf, inf;
//ainf=-1.0*val*log10(val); inf=ainf-(1.0-val)*log10(1.0-val);

/*
fl1=val; fl=.0;
for (k=1; k<=pontsz; k++) { fl=exp(mer*tavols[k]);
  if (tavols[k]>TAVMIN && notael[k]==1 && fl>minval) {
	  fl=fl1/(1.0-fl);
	  if (fl<.0001) {fl=.0001;} if (fl>.999) {fl=.999;}
	  fl2=fl*log10(fl)+(1.0-fl)*log10(1.0-fl); fl2*=-1.0;
	  if (fl2<inf) {rokon[k]=3; roksz++;}
  }
}
*/
return(val);

}

int csatlak(int csszam, float tkusz)
{
int i,k,m,szaml,minindx,kozpont,hozzaad;
float atltav, mintav,min0,kozsuly;

hozzaad=0;  kozsuly=0.5;
for (m=1;m<=utso;m++) {
  if (csop[m]==0) {
    mintav=10000;
    for (k=1;k<=csszam;k++) {  kozpont=kozp[k];   atltav=0;  szaml=0; min0=10000;
      for (i=1;i<=utso;i++) {
       if (abs(csop[i])==kozpont) {atltav+=vekttav[m][i];szaml++;
         if (vekttav[m][i]<min0) {min0=vekttav[m][i];}
       }
     }
     //if (szaml==0) {szaml=1;} atltav/=(float)szaml;
     if (szaml<2) {szaml=2;} atltav=(atltav-min0)*(1.0-kozsuly)/((float)szaml-1)+kozsuly*min0;
     if (atltav<mintav) {mintav=atltav;minindx=kozpont;}
   }
   if (mintav<tkusz*nyujt2) {csop[m]=minindx;hozzaad++;}

  }
}

return(hozzaad);

}

float val[NVEKT_MIN+1];
int csomopont00(int vektszam, int csszam, int minroksz, float tkusz, float atlvalszor, float rokvalszor)
{
int i,j,k,elovektor,csomo,tagszam,rokszam;  //minindx,maxsorsz,rokszam;
float maxval,fl,atlval; //mintav
char s[20];

//rokvalszor=0.01;
//tkusz=1.5; //  1.2
//sprintf(s,"nyujt2: %.3f",nyujt2); Form1->Memo1->Lines->Add(s);


float alf, maxtav=0;

for (i=1;i<=vektszam;i++) {
  for (j=1;j<i;j++) {fl=tavmeres(i,j,dimenz,tkusz);
    if (maxtav<fl) {maxtav=fl;}
  }
}
tavlep=maxtav/1000.0;

alf=log(.5)/tkusz;

//alf=log(.5)/tkusz/tkusz;
for (i=1;i<=1000;i++) {expon[i]=exp(alf*tavlep*(float)i);}


for (i=1;i<=vektszam;i++) {notael[i]=1;} for (i=1;i<=NCSOM_MIN;i++) {kozp[i]=0;}

atlval=0;
for (i=1;i<=vektszam;i++) {csop[i]=0;
  val[i]=mer(vektszam,i,tkusz); atlval+=val[i];Form1->Memo1->Lines->Add(val[i]);
}
//rokszam=0;
atlval/=(float)vektszam;

//float rokvalkusz=0; for (i=1;i<=vektszam;i++) {for (j=1;j<i;j++) { if (rokvalkusz<rokval[i][j]) {rokvalkusz=rokval[i][j];}}} Form1->Memo1->Lines->Add(rokvalkusz); rokvalkusz*=.2;
float rokvalkusz; //rokvalkusz=0; k=0; for (i=1;i<=vektszam;i++) {for (j=1;j<i;j++) { rokvalkusz+=rokval[i][j];k++;}}  rokvalkusz=5.0*rokvalkusz/(float)k;  Form1->Memo1->Lines->Add(rokvalkusz);


// ---- csszam darab csom�ponti vektor kijel�l�se, nem lehetnek t�l k�zel egym�shoz ---
// ----- atlval-n�l nagyobb felid. val�sz�n�s�g eset�n ------------------------

rokszam=0; int ossztagszam=0;
for (k=1;k<=csszam;k++) {  maxval=0;
  for (i=1;i<=vektszam;i++) {
    if (maxval<val[i] && csop[i]==0) {maxval=val[i];csomo=i;}
  }

  if (atlval*atlvalszor<=maxval) {           // 0.3:16     1.22:10

    /*
    csop[csomo]=-1*csomo; rokszam++;
    for (i=1;i<=vektszam;i++) {
      if (vekttav[csomo][i]<=tkusz*nyujt2 && csop[i]==0) {csop[i]=csomo;}
    }
    */

    tagszam=0;  rokvalkusz=maxval*rokvalszor;
    for (i=1;i<=vektszam;i++) { fl=tavmeres(csomo,i,dimenz,tkusz);
      if (rokvalosz>=rokvalkusz && csop[i]==0) {tagszam++;}
    }

    if (tagszam>=0) {  tagszam=0;
      for (i=1;i<=vektszam;i++) { fl=tavmeres(csomo,i,dimenz,tkusz);
        if (rokvalosz>=rokvalkusz && csop[i]==0 && tagszam<=100) {csop[i]=csomo;tagszam++;}
      }
      rokszam++;kozp[rokszam]=csomo;csop[csomo]=-1*csomo; ossztagszam+=tagszam;
    }
    else {csop[csomo]=-10000;}

    sprintf(s,"%d %.3f",csomo,maxval); Form1->Memo1->Lines->Add(s);
  }
  else {k=csszam+1;}
}

csszam=rokszam; ossztagszam+=rokszam;
sprintf(s,"csomoszam: %d",csszam); Form1->Memo1->Lines->Add(s);
sprintf(s,"ossztagszam: %d",ossztagszam); Form1->Memo1->Lines->Add(s);


//------------------------------------------------------------------------------

// ----- minden vektort a hozz� legk�zelibb csom�ponthoz rendel, ha tkusz-n�l k�zelebb van -----
/*
float mintav; int minindx;
for (i=1;i<=vektszam;i++) { mintav=1000.0; minindx=0;  if (csop[i]==-10000) {csop[i]=0;}
  for (j=1;j<=csszam;j++) { k=kozp[j];
      fl=tavmeres(i,k,dimenz,tkusz);
      if (fl<mintav) {mintav=fl;minindx=k;}

  }
  if (mintav<tkusz*1000.0 && csop[i]==0) {csop[i]=minindx;}
}
for (i=1;i<=vektszam;i++) {csop[i]=abs(csop[i]);}
*/
// -----------------------------------------------------------------------------
/*
float valkusz, minval;
int minsorsz, tal;

valkusz=1000;
for (i=1;i<=vektszam;i++) {
  if (csop[i]==0) {k=csopval(vektszam,csszam,i,tkusz); if (minvalosz<valkusz) {valkusz=minvalosz;j=k;}}
}
fl=(1.0-valkusz)/200.0;

minval=valkusz;
while (valkusz<=1.0+fl) { Form1->Memo1->Lines->Add(valkusz);
  tal=0;  minval=10000;
  for (i=1;i<=vektszam;i++) {
    //if (csop[i]==-10000) {csop[i]=0;}  tal=0;

    if (csop[i]==0) { k=csopval(vektszam,csszam,i,tkusz);
      if (minvalosz<=valkusz) {csop[i]=kozp[k]*-1;tal=1;Form1->Memo1->Lines->Add(kozp[k]);}
      else {if (minvalosz<minval) {minval=minvalosz;minsorsz=i;}}
    }
  }
  if (tal==1) {valkusz+=fl;} else {valkusz=minval+fl;Form1->Memo1->Lines->Add("lep");}
  //for (i=1;i<=vektszam;i++) {csop[i]=abs(csop[i]);}
}

for (i=1;i<=vektszam;i++) {csop[i]=abs(csop[i]);}
*/

// ----- a sz�lekhez k�zeli vektorok csatlakoztat�sa a megfelel� csoporthoz -----
//k=0; for (i=1;i<=10;i++) {fl=tkusz+(2.0*tkusz-tkusz)/10.0*(float)i; k+=csatlak(csszam,fl);Form1->Memo1->Lines->Add(k);}


FILE *out;
out=fopen("c:/eurkat/felho-cs.dat","w");

//float atltav;
for (i=1;i<=utso;i++) {notael[i]=0;}

elovektor=0;
for (k=1;k<=csszam;k++) {
  sprintf(s,"  %d   ",kozp[k]); fwrite(s,strlen(s),1,out);

  rokszam=0;
  for (i=1;i<=vektszam;i++) {if (abs(csop[i])==kozp[k]) {notael[i]=1;rokszam++;} else {notael[i]=0;}}
  notael[kozp[k]]=1;

  if (minroksz<=rokszam) {     // 2


  // a k-adik csom�ponthoz tartoz� vektorok ki�r�sa a felho.dat-ba -------------

  maxval=0;
  for (i=1;i<=vektszam;i++) {
    if (abs(csop[i])==kozp[k]) {
      // a v�gleges csom�ponti vektor kiv�laszt�sa a csatlakoztat�s ut�n -----------
      //fl=mer(vektszam,i,tkusz*0.5); if (maxval<fl) {maxval=fl;}

      for (j=0;j<20;j++) {s[j]=0;}
      sprintf(s,"%4d ",cim[i]); fwrite(s,strlen(s),1,out); elovektor++;
    }
  }
  //fwrite(" \n",2,1,out);
  sprintf(s,"  %4d ",k); fwrite(s,strlen(s),1,out);

  fwrite(" \n",2,1,out);   fwrite(" \n",2,1,out);
  }

}
fclose(out);
for (i=1;i<=vektorszam;i++) {notael[i]=1;}



/*
float csopelo[100][50];
int kult;

for (i=1;i<100;i++) { for (j=1;j<50;j++) {csopelo[i][j]=0;}}
for (k=1;k<=csszam;k++) {  rokszam=0;
  for (i=1;i<=vektszam;i++) {
    if (abs(csop[i])==kozp[k]) { kult=i/50+1; csopelo[k][kult]+=1;rokszam++;}
  }
  //for (i=1;i<=vektszam;i++) {csopelo[k][i]/=(float)rokszam;}
}
out=fopen("c:/eurkat/csopelo.dat","w");
for (k=1;k<=csszam;k++) {
  for (j=0;j<20;j++) {s[j]=0;}
  for (i=1;i<=33;i++) { sprintf(s,"%6.3f ",csopelo[k][i]*1.0); fwrite(s,strlen(s),1,out);}
  fwrite(" \n",2,1,out);
}
fclose(out);
*/


/*
out=fopen("c:/eurkat/felho-mins.dat","w");
int minsor;
for (k=1;k<=csszam;k++) {  minsor=1000; minindx=0; elovektor=0;
  for (i=1;i<=vektszam;i++) {
    if (abs(csop[i])==kozp[k]) {elovektor++;}
    if (abs(csop[i])==kozp[k] && hanys[i]<minsor) {minsor=hanys[i]; minindx=i;}
  }

  if (elovektor>=3) {
    for (j=0;j<20;j++) {s[j]=0;}
    sprintf(s,"%d ",minindx); fwrite(s,strlen(s),1,out); elovektor++;
  }

}
fclose(out);
*/


int kk;
for (k=1;k<=csszam;k++) { kk=kozp[k];
  for (i=1;i<=dimenz;i++) {w[k][1][i]=vektorok[kk][i];w[k][0][i]=1;}
  for (i=1;i<=dimenz2;i++) {w[k][2][i]=hanghiszt[kk][i];}
}

Form1->Memo1->Lines->Add(elovektor);
return(csszam);

}
//------------------------------------------------------------------------------------

// ----------- Clustering significance tests ----------------------------------------
float inference(int vektsz)
{
int i,j,szaml;
float fl,fl2,atltav,atlinfer,korr,tavszoras,infszoras;

//tavmeres0(10,10,dimenz); return(0);



szaml=0; atltav=0;
for (i=1;i<=vektsz;i++) {
  for (j=1;j<i;j++) {fl=tavmeres0(i,j);szaml++;atltav+=fl;}
}
if (szaml==0) {szaml=1;}
atltav/=(float)szaml;

tavszoras=0;
for (i=1;i<=vektsz;i++) {
  for (j=1;j<i;j++) {fl=tavmeres0(i,j)-atltav;tavszoras+=fl*fl;}
}
tavszoras=sqrt(tavszoras/(float)(szaml));

/*
int hat[]={1,9,19,30,40,50,59,69,79,89,99,108,118,128,142,156,160,165,0};
//Form1->Memo1->Lines->Add(hat[0]); return(0);
i=0;
while (hat[i+1]!=0) {
  for (j=hat[i];j<hat[i+1];j++) {rokon[j]=i+1;}
  i++;
}
//for (i=hat[1];i<hat[2];i++) {Form1->Memo1->Lines->Add(rokon[i]);} return(0);
*/

atlinfer=0;
for (i=1;i<=vektsz;i++) {
  for (j=1;j<i;j++) {
    if (rokon[i]==rokon[j]) {fl=1;} else {fl=0.0;}
    atlinfer+=fl;
  }
}
atlinfer/=(float)szaml;

infszoras=0;
for (i=1;i<=vektsz;i++) {
  for (j=1;j<i;j++) {
    if (rokon[i]==rokon[j]) {fl=1-atlinfer;} else {fl=0.0-atlinfer;}
    infszoras+=fl*fl;
  }
}
infszoras=sqrt(infszoras/(float)(szaml));

korr=0;
for (i=1;i<=vektsz;i++) {
  for (j=1;j<i;j++) {
    fl=tavmeres0(i,j);
    if (rokon[i]==rokon[j]) {fl2=1;} else {fl2=0.0;}
    korr+=(fl-atltav)*(fl2-atlinfer);
  }
}
korr=korr/(tavszoras*infszoras*(szaml-1));

Form1->Memo1->Lines->Add(korr);
return(korr);

}


float silhouette(int vektsz, int vektsorsz)
{
int i,indx,sajindx, tagsz[1001], furtszam, minsorsz;
float fl,szep[1001],minszep,szil;

sajindx=rokon[vektsorsz];

for (i=1;i<=1000;i++) {szep[i]=0;tagsz[i]=0;}  furtszam=0;

for (i=1;i<=vektsz;i++) { indx=rokon[i];
  if (i!=vektsorsz) {szep[indx]+=tavmeres0(vektsorsz,i); tagsz[indx]+=1;}
  if (furtszam<indx) {furtszam=indx;}
}

for (i=1;i<=furtszam;i++) {
  fl=(float)tagsz[i]; if (fl==0) {fl=1.0;}
  szep[i]/=fl;
}

minszep=1000;minsorsz=0;
for (i=1;i<=furtszam;i++) {
  if (szep[i]<minszep && i!=sajindx) {minszep=szep[i]; minsorsz=i;}
}

if (szep[sajindx]<szep[minsorsz]) {szil=1.0-szep[sajindx]/szep[minsorsz];} else {szil=szep[minsorsz]/szep[sajindx]-1;}
if (szep[sajindx]==szep[minsorsz]) {szil=0.0;}
if (tagsz[sajindx]==0) {szil=10;}

return(szil);

}


float szil(int vektsz, int tipsorsz)
{
int i,szaml;
float atlszil;

atlszil=0; szaml=0;
for (i=1;i<=vektsz;i++) { if (rokon[i]==tipsorsz) {atlszil+=silhouette(vektsz,i); szaml++;} }
if (szaml==0) {szaml=1;}
atlszil/=(float)szaml;
Form1->Memo1->Lines->Add(atlszil);

return(atlszil);
}

//-------------------------------------------------------------------------------------

//------- functions for graphical representation -------------------------------------

long int csoportszin(int sorsz)
{
//int i, kk,m,b[5],delta=255,feh;
int i, kk,feh;
long int szin;

feh=255*pow(2,0)+255*pow(2,8)+255*pow(2,16);
kk=csop[sorsz];
for (i=1; i<=kozpontszam;i++) {
  if (abs(csop[sorsz])==kozp[i]) {kk=i;}
  //if (abs(csop[sorsz])==i) {kk=i;}
}


/*
for (i=1;i<=5;i++) {if (7<kk) {kk-=7; delta-=51;}}
//Form1->Memo1->Lines->Add(kk);
m=kk;
for (i=4;i>=1;i--) {b[i]=m/pow(2,i-1); m=m-b[i]*pow(2,i-1);}
for (i=1;i<=4;i++) {b[i]*=delta;}
szin=b[1]*pow(2,0)+b[2]*pow(2,8)+b[3]*pow(2,16)+b[4]*pow(2,32);
*/

if (feh<kk) {kk-=feh;}
szin=int((float)kk*(float)feh/100.0+.5)+100;

return(szin);

}

long int csoportszin_kmed(int sorsz)
{
int i, kk,m,b[5],delta=255, feh;
long int szin;

feh=255*pow(2,0)+255*pow(2,8)+255*pow(2,16);
kk=abs(csop[sorsz]);
for (i=1; i<=kozpontszam;i++) {
  //if (abs(csop[sorsz])==kozp[i]) {kk=i;}
  if (abs(csop[sorsz])==i) {kk=i;}
}

/*
for (i=1;i<=5;i++) {if (7<kk) {kk-=7; delta-=51;}}
//Form1->Memo1->Lines->Add(kk);
m=kk;
for (i=4;i>=1;i--) {b[i]=m/pow(2,i-1); m=m-b[i]*pow(2,i-1);}
for (i=1;i<=4;i++) {b[i]*=delta;}
szin=b[1]*pow(2,0)+b[2]*pow(2,8)+b[3]*pow(2,16)+b[4]*pow(2,32);
*/

return(szin);

}

long int kultszin(int sorsz)
{
int i, kk,m,b[5],delta=255; //feh;
long int szin;

//feh=255*pow(2,0)+255*pow(2,8)+255*pow(2,16)+255*pow(2,32);
kk=1; i=1;
while (hatar[i]<sorsz) {kk=i;i++;}

//for (i=1;i<=5;i++) {if (osszkult<kk) {kk-=kk; delta-=51;}}

m=kk;
for (i=4;i>=1;i--) {b[i]=m/pow(2,i-1); m=m-b[i]*pow(2,i-1);}
for (i=1;i<=4;i++) {b[i]*=delta;}
szin=b[1]*pow(2,0)+b[2]*pow(2,8)+b[3]*pow(2,16)+b[4]*pow(2,32);

return(szin);

}

long int szurke(float arny)
{
//int i, kk,m,b[5],delta=255,feh;
int kk,feh;
long int szin;

feh=255*pow(2,0)+255*pow(2,8)+255*pow(2,16);

kk=int(255.0*arny+0.5);
szin=kk*pow(2,0)+kk*pow(2,8)+kk*pow(2,16);

if (feh<szin) {szin-=feh;}

return(szin);

}
//----------------------------------------------------------------------------------

//-------------- MDS functions ------------------------------------------------------

float vektgrad3d(int vektsz, int vektdim, int vdim, float lamb, float nagytav, float kissuly)
{
int i,j,ii,sorsz;
float siktav[NPONT+1],suly[NPONT+1],grad[NPONT+1][11],fl,fl1,fl2, gradnagys;

float sulyp[10];

//lamb=.001;

//for (i=1;i<=vektsz;i++) {suly[i]=1.0;}

for (ii=1;ii<=vektsz;ii++) { sorsz=ii;


// ------------- sulyoz�sok ------------------------------

for (i=1;i<=vektsz;i++) {suly[i]=1;
  if (vekttav[sorsz][i]>nyujtas*nagytav) {suly[i]=kissuly;}
  //Form1->Memo1->Lines->Add(suly[i]);
}

/*
for (i=1;i<=vektsz;i++) {suly[i]=kissuly;
  if (i==8 || ii==8) {suly[i]=1.0;}
}
*/
//------------------------------------------------------------



for (i=1;i<=vektsz;i++) {fl1=0;
  for (j=1;j<=vdim;j++) {fl=vektkoord0[i][j]-vektkoord0[sorsz][j];fl1+=fl*fl;}
  siktav[i]=fl1; //Form1->Memo1->Lines->Add(fl1);
}


// ----------- sokdim vekttav[] - 3dim s�ktav[] hiba --------------------------------------------
/*
fl1=0;
for (i=1;i<=vektsz;i++) {fl=vekttav[sorsz][i]*vekttav[sorsz][i]/(float)vektdim; fl=siktav[i]-fl;fl1+=fl*fl;}
fl=sqrt(fl1);
return(fl);
*/


// ------- gradiens sz�m�t�s, ha vekttav[i][sorsz]=vekttav[sorsz][i] -----------------
/*
for (j=1;j<=vdim;j++) {fl=0;
  for (i=1;i<=vektsz;i++) {fl1=vekttav[i][sorsz]*vekttav[i][sorsz]/(float)vektdim; fl+=(siktav[i]-fl1)*(vektkoord0[sorsz][j]-vektkoord0[i][j])*suly[i];}
  grad[sorsz][j]=2.0*fl;  //Form1->Memo1->Lines->Add(fl);
}
*/

// ------- gradiens sz�m�t�s, ha vekttav[i][sorsz]!=vekttav[sorsz][i] -----------------

for (j=1;j<=vdim;j++) {fl=0;
  for (i=1;i<=vektsz;i++) {
    fl1=vekttav[i][sorsz]*vekttav[i][sorsz]/(float)vektdim;
    fl2=vekttav[sorsz][i]*vekttav[sorsz][i]/(float)vektdim;
    fl+=(2.0*siktav[i]-fl1-fl2)*(vektkoord0[sorsz][j]-vektkoord0[i][j])*suly[i];
  }
  grad[sorsz][j]=2.0*fl;  //Form1->Memo1->Lines->Add(fl);
}


// ------- k�zeli pontok �sszeterel�se -------------------------------
/*
for (j=1;j<=vdim;j++) {fl=0;
  for (i=1;i<=vektsz;i++) {fl+=(vektkoord0[sorsz][j]-vektkoord0[i][j])*suly[i];}
  grad[sorsz][j]+=100.0*fl;  //Form1->Memo1->Lines->Add(fl);
}
*/

} // ii



//  ------ vektkoord0[] elmozd�t�sa a grad. ir�ny�ba ----------------------
gradnagys=0;
for (ii=1;ii<=vektsz;ii++) { sorsz=ii;

//fl=sqrt(grad[sorsz][1]*grad[sorsz][1]+grad[sorsz][2]*grad[sorsz][2]+grad[sorsz][3]*grad[sorsz][3]);
fl=0; for (j=1;j<=vdim;j++) {fl+=grad[sorsz][j]*grad[sorsz][j];}  fl=sqrt(fl);


//if (fl<kezdgrad*.00001) {fl=kezdgrad*.00001;}
//fl1=lamb;
fl1=1.0/fl*lamb;
gradnagys=+fl;

/*
fl=vektkoord0[sorsz][1]-fl1*grad[sorsz][1];if (fl>0 && fl<terx) {vektkoord0[sorsz][1]=fl;}
fl=vektkoord0[sorsz][2]-fl1*grad[sorsz][2];if (fl>0 && fl<tery) {vektkoord0[sorsz][2]=fl;}
fl=vektkoord0[sorsz][3]-fl1*grad[sorsz][3];if (fl>0 && fl<terz) {vektkoord0[sorsz][3]=fl;}
*/

for (j=1;j<=vdim;j++) {
  fl=vektkoord0[sorsz][j]-fl1*grad[sorsz][j];if (fl>0 && fl<term[1]) {vektkoord0[sorsz][j]=fl;}
}

//Form1->Memo1->Lines->Add(vektkoord0[sorsz][1]);



// --------- �j s�lypont sz�m�t�sa, a pontrendszer eltol�sa �gy, hogy a s�lypont a t�rk�p k�zep�re essen -----------------------------------
fl=0;fl1=0;fl2=0;
for (i=1;i<=vdim;i++) {sulyp[i]=0;}
for (i=1;i<=vektsz;i++) {
/*
fl+=vektkoord0[i][1];
fl1+=vektkoord0[i][2];
fl2+=vektkoord0[i][3];
*/
for (j=1;j<=vdim;j++) {sulyp[j]+=vektkoord0[i][j];}

}
//fl/=(float)vektsz; fl1/=(float)vektsz; fl2/=(float)vektsz; fl-=(float)terx/2;  fl1-=(float)tery/2; fl2-=(float)terz/2;
//for (i=1;i<=vektsz;i++) {vektkoord0[i][1]-=fl; vektkoord0[i][2]-=fl1;vektkoord0[i][3]-=fl2;}
for (i=1;i<=vdim;i++) {sulyp[i]/=(float)vektsz;}  for (i=1;i<=vdim;i++) {sulyp[i]-=(float)term[i]/2;}
for (i=1;i<=vektsz;i++) {
  for (j=1;j<=vdim;j++) {vektkoord0[i][j]-=sulyp[j];}
}


/*
x=int(vektkoord0[sorsz][1]+.5);
y=int(vektkoord0[sorsz][2]+.5);
z=int(vektkoord0[sorsz][3]+.5);
//if (x<terx && x>0 && y<tery && y>0 && z<terz && z>0) {vektkoord[sorsz][1]=x;vektkoord[sorsz][2]=y;vektkoord[sorsz][3]=z;}
if (x<=0) {x=0;} if (x>terx) {x=terx;}
if (y<=0) {y=0;} if (y>tery) {y=tery;}
if (z<=0) {z=0;} if (z>terz) {z=terz;}
vektkoord[sorsz][1]=x;vektkoord[sorsz][2]=y;vektkoord[sorsz][3]=z;


for (i=1;i<=terx;i++) {for (j=1;j<=tery;j++) {talalat[i][j]=0;}}
for (i=1;i<=vektsz;i++) {x=int(vektkoord[i][1]+.5); y=int(vektkoord[i][2]+.5); talalat[x][y]=1;}
*/

} // ii
gradnagys/=(float)vektsz;


return(gradnagys);

}

float vektgrad3d1pont(int vektsz, int sorsz, int vektdim, int vdim, float lamb, float nagytav, float kissuly)
{
int i,j;
float siktav[NPONT+1],suly[NPONT+1],grad[NPONT+1][11],fl,fl1,fl2, gradnagys;
float sulyp[10];


//lamb=.001;

//for (i=1;i<=vektsz;i++) {suly[i]=1.0;}

//for (ii=1;ii<=vektsz;ii++) { sorsz=ii;



for (i=1;i<=vektsz;i++) {suly[i]=1;
  if (vekttav[sorsz][i]>nyujtas*nagytav) {suly[i]=kissuly;}
  //Form1->Memo1->Lines->Add(suly[i]);
}


for (i=1;i<=vektsz;i++) {fl1=0;
  for (j=1;j<=vdim;j++) {fl=vektkoord0[i][j]-vektkoord0[sorsz][j];fl1+=fl*fl;}
  siktav[i]=fl1; //Form1->Memo1->Lines->Add(fl1);
}


// ----------- sokdim vekttav[] - 3dim s�ktav[] hiba --------------------------------------------
/*
fl1=0;
for (i=1;i<=vektsz;i++) {fl=vekttav[sorsz][i]*vekttav[sorsz][i]/(float)vektdim; fl=siktav[i]-fl;fl1+=fl*fl;}
fl=sqrt(fl1);
return(fl);
*/


// ------- gradiens sz�m�t�s, ha vekttav[i][sorsz]=vekttav[sorsz][i] -----------------
/*
for (j=1;j<=vdim;j++) {fl=0;
  for (i=1;i<=vektsz;i++) {fl1=vekttav[i][sorsz]*vekttav[i][sorsz]/(float)vektdim; fl+=(siktav[i]-fl1)*(vektkoord0[sorsz][j]-vektkoord0[i][j])*suly[i];}
  grad[sorsz][j]=2.0*fl;  //Form1->Memo1->Lines->Add(fl);
}
*/

// ------- gradiens sz�m�t�s, ha vekttav[i][sorsz]!=vekttav[sorsz][i] -----------------
//float fl2;
for (j=1;j<=vdim;j++) {fl=0;
  for (i=1;i<=vektsz;i++) {
    fl1=vekttav[i][sorsz]*vekttav[i][sorsz]/(float)vektdim;
    fl2=vekttav[sorsz][i]*vekttav[sorsz][i]/(float)vektdim;
    fl+=(2.0*siktav[i]-fl1-fl2)*(vektkoord0[sorsz][j]-vektkoord0[i][j])*suly[i];
  }
  grad[sorsz][j]=2.0*fl;  //Form1->Memo1->Lines->Add(fl);
}


// ------- k�zeli pontok �sszeterel�se -------------------------------
/*
for (j=1;j<=vdim;j++) {fl=0;
  for (i=1;i<=vektsz;i++) {fl+=(vektkoord0[sorsz][j]-vektkoord0[i][j])*suly[i];}
  grad[sorsz][j]+=100.0*fl;  //Form1->Memo1->Lines->Add(fl);
}
*/

//} // ii



//  ------ vektkoord0[] elmozd�t�sa a grad. ir�ny�ba ----------------------
gradnagys=0;
//for (ii=1;ii<=vektsz;ii++) { sorsz=ii;

//fl=sqrt(grad[sorsz][1]*grad[sorsz][1]+grad[sorsz][2]*grad[sorsz][2]+grad[sorsz][3]*grad[sorsz][3]);
fl=0; for (j=1;j<=vdim;j++) {fl+=grad[sorsz][j]*grad[sorsz][j];}  fl=sqrt(fl);


//if (fl<kezdgrad*.00001) {fl=kezdgrad*.00001;}
//fl1=lamb;
fl1=1.0/fl*lamb;
gradnagys=+fl;

/*
fl=vektkoord0[sorsz][1]-fl1*grad[sorsz][1];if (fl>0 && fl<terx) {vektkoord0[sorsz][1]=fl;}
fl=vektkoord0[sorsz][2]-fl1*grad[sorsz][2];if (fl>0 && fl<tery) {vektkoord0[sorsz][2]=fl;}
fl=vektkoord0[sorsz][3]-fl1*grad[sorsz][3];if (fl>0 && fl<terz) {vektkoord0[sorsz][3]=fl;}
*/
for (j=1;j<=vdim;j++) {
  fl=vektkoord0[sorsz][j]-fl1*grad[sorsz][j];if (fl>0 && fl<terx) {vektkoord0[sorsz][j]=fl;}
}

//Form1->Memo1->Lines->Add(vektkoord0[sorsz][1]);



// --------- �j s�lypont sz�m�t�sa, a pontrendszer eltol�sa �gy, hogy a s�lypont a t�rk�p k�zep�re essen -----------------------------------
fl=0;fl1=0;fl2=0;
for (i=1;i<=vdim;i++) {sulyp[i]=0;}
for (i=1;i<=vektsz;i++) {
/*
fl+=vektkoord0[i][1];
fl1+=vektkoord0[i][2];
fl2+=vektkoord0[i][3];
*/
for (j=1;j<=vdim;j++) {sulyp[j]+=vektkoord0[i][j];}
}
//fl/=(float)vektsz; fl1/=(float)vektsz; fl2/=(float)vektsz; fl-=(float)terx/2;  fl1-=(float)tery/2; fl2-=(float)terz/2;
//for (i=1;i<=vektsz;i++) {vektkoord0[i][1]-=fl; vektkoord0[i][2]-=fl1;vektkoord0[i][3]-=fl2;}
for (i=1;i<=vdim;i++) {sulyp[i]/=(float)vektsz;}  for (i=1;i<=vdim;i++) {sulyp[i]-=(float)term[i]/2;}
for (i=1;i<=vektsz;i++) {
  for (j=1;j<=vdim;j++) {vektkoord0[i][j]-=sulyp[j];}
}


/*
x=int(vektkoord0[sorsz][1]+.5);
y=int(vektkoord0[sorsz][2]+.5);
z=int(vektkoord0[sorsz][3]+.5);
//if (x<terx && x>0 && y<tery && y>0 && z<terz && z>0) {vektkoord[sorsz][1]=x;vektkoord[sorsz][2]=y;vektkoord[sorsz][3]=z;}
if (x<=0) {x=0;} if (x>terx) {x=terx;}
if (y<=0) {y=0;} if (y>tery) {y=tery;}
if (z<=0) {z=0;} if (z>terz) {z=terz;}
vektkoord[sorsz][1]=x;vektkoord[sorsz][2]=y;vektkoord[sorsz][3]=z;


for (i=1;i<=terx;i++) {for (j=1;j<=tery;j++) {talalat[i][j]=0;}}
for (i=1;i<=vektsz;i++) {x=int(vektkoord[i][1]+.5); y=int(vektkoord[i][2]+.5); talalat[x][y]=1;}
*/

//} // ii
//gradnagys/=(float)vektsz;


return(gradnagys);

}


void tisztazas(int alterdim)
{
float fl1;
int i,j,k,ciklusszam;
//char s[300];

char *str=new char[20];
Form1->Edit5->GetTextBuf(str,20); float kozelarany=atof(str);

float maxtav=-1000;
for (i=1;i<=utso;i++) {
  for (j=1;j<=utso;j++) { if (maxtav<vekttav[i][j]) {maxtav=vekttav[i][j];}}
}
maxtav*=kozelarany; //Form1->Memo1->Lines->Add(maxtav);


int kival[1000];
float tav1,tav2;
for (i=1;i<=utso;i++) { kival[i]=0;
  for (j=1;j<=utso;j++) {  tav1=0; tav2=0;
    //for (k=1;k<=dimenz;k++) {fl1=w[i][1][k]-w[j][1][k];tav1+=fabs(fl1);}
    for (k=1;k<=alterdim;k++) {fl1=vektkoord0[i][k]-vektkoord0[j][k];tav1+=fl1*fl1;}
    tav1=sqrt(tav1); //Form1->Memo1->Lines->Add(tav1);
    if (tav1>.0 && vekttav[i][j]<maxtav && i!=j) {kival[i]=1;Form1->Memo1->Lines->Add(i);}
  }
}

int cikl;
float lamb=.01,nagytav=.1,kissuly=.01,  la,dla,hiba,kezdgrad,fl;
ciklusszam=1000;

k=0; la=lamb*10.0;  dla=(la-lamb)/((float)ciklusszam*.75);  hiba=0;


kezdgrad=vektgrad3d1pont(utso,valvektor,dimenz,alterdim,la,nagytav,kissuly);


for (int szaml=1;szaml<=utso;szaml++) {valvektor=szaml;

if (kival[valvektor]==1) {

k=0;
for (cikl=1;cikl<=ciklusszam;cikl++) {
  //if (cikl>ciklusszam/2) {nagytav+=dnagytav;kissuly=.1;}
  //fl=vektgrad(utso,dimenz,la,nagytav,kissuly);
  fl=vektgrad3d1pont(utso,valvektor,dimenz,alterdim,la,nagytav,kissuly);
  hiba=fel*hiba+rn*fl;
  la-=dla; if (la<lamb) {la=lamb;}
  //if (k==500) {sulypont(utso,alterdim);nyujt=1.0;forgat(5); Form1->PaintBox1Click(Sender);k=0;Application->ProcessMessages();if (tanvege==1) {cikl=ciklusszam;}}
  k++;
}

}

}

//sulypont(utso,alterdim);

}
//--------------------------------------------------------------------------------

//------------ assigning training vectors to learning vectors ---------------------
float keresfh(int dsorsz)
{
int i,k,m,minh[230],minhely;
float tav[130],tavols,mintavols,fl,fl2,mintav;


mintavols=10000.0;
for (i=1;i<=utso;i++) {tavols=.0;

    for (k=1;k<=dimenz;k++) {fl=w[i][1][k]-(float)vektorok[dsorsz][k]; tav[k]=fl*fl;}

    tavols=0;fl2=1.0;

    if (hahisuly<0.999) {
    for (k=1;k<=dimenz;k++) {fl=w[i][0][k];tavols+=tav[k]*fl;fl2+=fl;}
    tavols=sqrt(tavols/fl2);
    tavols*=tavmod(dsorsz,dimenz);
    }

    if (0.0001<hahisuly) {fl2=hanghiszttiptav(dsorsz,i,dimenz2);}

    tavols=tavols*(1.0-hahisuly)+fl2*hahisuly;

    if (tavols<=mintavols) {mintavols=tavols;minsorszam=i;}
}


for (k=1;k<=dimenz;k++) {minh[k]=0;fohang[k]=0;}
for (k=1;k<=dimenz;k++) {fl=w[minsorszam][1][k]-(float)vektorok[dsorsz][k]; tav[k]=fl*fl;}

for (m=1;m<=nhely;m++) {mintav=10000;
  for (k=1;k<=dimenz-4;k++) {
    if (tav[k]<mintav && minh[k]==0) {mintav=tav[k];minhely=k;}
  }
  if (minhely>dimenz) {minhely=dimenz;}
  fohang[minhely]=1.0;

  k=minhely; while (fabs(vektorok[dsorsz][k]-vektorok[dsorsz][minhely])<2 && k>1) {minh[k]=1;k--;}
  k=minhely; while (fabs(vektorok[dsorsz][k]-vektorok[dsorsz][minhely])<2 && k<dimenz-4) {minh[k]=1;k++;}

}


for (k=1;k<=dimenz;k++) {if (tav[k]<1 && w[minsorszam][1][k]>=0.5) {fohang[k]=1;}}

//for (k=1;k<=dimenz;k++) {fl=w[minsorszam][1][k]-(float)vektorok[dsorsz][k]; tav[k]=fl*fl;}
/*
tavols=0;fl2=1.0;
for (k=1;k<=dimenz;k++) {fl=w[minsorszam][0][k];tavols+=tav[k]*fl;fl2+=fl;}
tavols=sqrt(tavols/fl2);
tavols*=tavmod(dsorsz,dimenz);
*/
//Form1->Memo1->Lines->Add(dimenz);
return(mintavols);

}

float tiptavmerfh(int dsorsz, int wsorsz, int transzp)
{
int k;
float tav[130],tavols,fl,fl2;
float atl1,atl2;

if (transzp==1) {
fl2=0; for (k=1;k<=dimenz;k++) {fl2+=w[wsorsz][0][k];}  fl2=(float)dimenz;
atl2=0; for (k=1;k<=dimenz;k++) {atl2+=(w[wsorsz][1][k]-(float)vektorok[dsorsz][k]);/**w[minx][miny][0][k];*/} atl1=atl2/fl2;
}
else {atl1=0;}

for (k=1;k<=dimenz;k++) {fl=w[wsorsz][1][k]-(float)vektorok[dsorsz][k]-atl1; tav[k]=fl*fl;}
tavols=.0;fl2=1.0;
for (k=1;k<=dimenz;k++) {fl=w[wsorsz][0][k];tavols+=tav[k]*fl;fl2+=fl;}
tavols=sqrt(tavols/fl2);
tavols*=tavmod(dsorsz,dimenz);

fl2=0;
for (k=1;k<=dimenz2;k++) {fl=w[wsorsz][2][k]-hanghiszt[dsorsz][k]; fl2+=fl*fl*hangsuly[k];}   fl2=sqrt(fl2/hahinorm);
tavols=tavols*(1.0-hahisuly)+fl2*hahisuly; //Form1->Memo1->Lines->Add(tavols);
return(tavols);

}


int tiptavfh(int dsorsz, float tavkusz, float tures, int kult, int transz)
{
int i,k,ossztal,tal[3000];
float tav[130],tavols,fl,fl2,mintavols;
float atl1, atl2;

//tures=0.0; tavkusz=2.0; hahisuly=0.3;

ossztal=0;  mintavols=100000.0;
for (i=1;i<=utso;i++) {
    tal[i]=0;

    if (transz==1) {
    //fl2=0; for (k=1;k<=dimenz;k++) {fl2+=w[i][j][2][k];}
    fl2=(float)dimenz;
    atl2=0; for (k=1;k<=dimenz;k++) {atl2+=(w[i][1][k]-(float)vektorok[dsorsz][k]);} atl1=atl2/fl2;  //atl1=0;
    }
    else {atl1=0;}

    for (k=1;k<=dimenz;k++) {fl=w[i][1][k]-(float)vektorok[dsorsz][k]-atl1;tav[k]=fl*fl;}
    tavols=0;fl2=1.0;
    for (k=1;k<=dimenz;k++) {fl=w[i][0][k];tavols+=tav[k]*fl;fl2+=fl;}
    tavols=sqrt(tavols/fl2);
    tavols*=tavmod(dsorsz,dimenz);

    if (0.0001<hahisuly) {fl2=hanghiszttiptav(dsorsz,i,dimenz2);}  else {fl2=0;}
    tavols=tavols*(1.0-hahisuly)+fl2*hahisuly;


    if (tavols<mintavols) {mintavols=tavols;minsorszam=i;}
    if (tavols<tavkusz*tures+0.0001) {talalat[i]+=1;ossztal++;tipelterj[i][kult]+=1-tavols/(tavkusz*1.1);tipelterj[i][0]+=1;tal[i]=1;/*Form1->Memo1->Lines->Add("tures");*/}   // .5
    //if (tavols<tavkusz*.01) {talalat[i][j]+=1;ossztal++;tipelterj[i][j][kult]=1;tipelterj[i][j][0]+=1;tal[i][j]=1;}

}

if (mintavols<tavkusz && tures>0.0001  && tal[minsorszam]<0.0001) {talalat[minsorszam]=1;ossztal++;tipelterj[minsorszam][kult]=1-mintavols/(tavkusz*1.1);tipelterj[minsorszam][0]=1;}
if (mintavols<tavkusz && tures<0.0001 && tal[minsorszam]<100000) {talalat[minsorszam]+=1;ossztal++;tipelterj[minsorszam][kult]+=1-mintavols/(tavkusz*1.1);tipelterj[minsorszam][0]+=1;}

return(ossztal);

}
//-----------------------------------------------------------------------------

//-------------------   adjusting the number of learning vectors ---------------------------
float dmintav, atlmintav0 , dtipsz, tipsz0;

int tipszam(int tipsz, float szorkusz)
{
int i,j,sorsz,ksz;
float fl,fl1,fl2, wtav, wtav2, mintiptav, atltav[NPONT+1], minwtav[NPONT+1], tal[NPONT+1], mintav[NPONT+1], minsorsz[NPONT+1];

for (i=1;i<=tipsz;i++) {atltav[i]=0;tal[i]=0;mintav[i]=1000;minsorsz[i]=0;tal[i]=0;}


float atlmintav=0;

for (i=1;i<=tipsz;i++) {
  fl2=0; for (k=1;k<=dimenz;k++) {fl2+=w[i][0][k];}
  for (j=1;j<i;j++) {
    mintiptav=1000;
    fl1=0; for (k=1;k<=dimenz;k++) { fl=w[i][1][k]-w[j][1][k]; fl1+=fl*fl*w[i][0][k];}
    wtav=sqrt(fl1/fl2);

    fl1=0; for (k=1;k<=dimenz2;k++) { fl=w[i][2][k]-w[j][2][k]; fl1+=fl*fl*hangsuly[k];}
    wtav2=sqrt(fl1/hahinorm);
    wtav=wtav*(1-hahisuly)+wtav2*hahisuly;
    if (wtav<mintiptav) {mintiptav=wtav;}   //Form1->Memo1->Lines->Add(wtav);
  }
  atlmintav+=mintiptav; minwtav[i]=mintiptav;
}
atlmintav/=tipsz;
//fl=atlmintav-atlmintav0; dmintav=0.0/2.0*dmintav+1.0/1.0*fl; atlmintav0=atlmintav;
if (atlmintav>=atlmintav0+0.03) {dmintav=1;} else {dmintav-=1;}  atlmintav0=atlmintav;   //if (dmintav<-0.99 && 80<tipsz) {return(tipsz);}
//Form1->Memo1->Lines->Add(atlmintav);

for (i=1;i<=vektorszam;i++) {fl=keresfh(i);atltav[minsorszam]+=fl;tal[minsorszam]+=1; //Form1->Memo1->Lines->Add(tal[minsorszam]);
  if (fl<mintav[minsorszam]) {mintav[minsorszam]=fl; minsorsz[minsorszam]=(float)i;}
}
float atltiptav=0;
for (i=1;i<=tipsz;i++) {if (tal[i]==0) {tal[i]=1;} atltav[i]/=tal[i];atltiptav+=atltav[i];}
atltiptav/=(float)tipsz;    //if (atltiptav<atlmintav*szorkusz*0.85 && 80<tipsz) {return(tipsz);}
//Form1->Memo1->Lines->Add(atltiptav);

/*
int szaml1, szaml2, szaml;
if (atltiptav<atlmintav*szorkusz*0.8) {

  tipsz0=tipsz;
  ksz=int((float)vektorszam/(float)(tipsz0)*2+0.5);  if (ksz<6) {ksz=6;}  //ksz=vektorszam/100*2;
  for (i=1;i<=tipsz0;i++) { Form1->Memo1->Lines->Add(tal[i]);
    szaml=0; for (j=1;j<=dimenz;j++) {if (w[i][0][j]>0.9) {szaml++;}}
    szaml1=0; for (j=1;j<=dimenz;j++) {if (w[i][0][j]>0.05) {szaml1++;}}
    szaml2=0; for (j=1;j<=dimenz;j++) {if (w[i][0][j]>0.2) {szaml2++;}}
    fl1=(float)szaml1/5.0; fl2=(float)szaml1/3.0;
    if (szaml<fl1 && szaml2>fl2 && tipsz<=tipsz0+19 && tal[i]>ksz) {  tipsz+=1;  sorsz=(int)minsorsz[i]; Form1->Memo1->Lines->Add(tal[i]);
    //if (tal[i]>ksz) {  tipsz+=1;  sorsz=(int)minsorsz[i]; Form1->Memo1->Lines->Add(tal[i]);
      for (j=1;j<=dimenz;j++) {w[tipsz][1][j]=vektorok[sorsz][j]; w[tipsz][0][j]=w[i][0][j];} for (j=1;j<=dimenz2; j++) {w[tipsz][2][j]=hanghiszt[sorsz][j];}
      for (j=1;j<=3;j++) {vektkoord0[tipsz][j]=vektkoord0[i][j];vektkoord[tipsz][j]=vektkoord[i][j];}
    }
  }

  //return(tipsz);
}
*/

char s[20];
sprintf(s,"neighbour dist: %.3f",atlmintav);  Form1->Memo1->Lines->Add(s);
sprintf(s,"stand.dev: %.3f",atltiptav);  Form1->Memo1->Lines->Add(s);
sprintf(s,"stasd.dev/neigh.dist: %.3f",atltiptav/atlmintav);  Form1->Memo1->Lines->Add(s);
sprintf(s,"clust.size: %.3f",(float)vektorszam/(float)tipsz);  Form1->Memo1->Lines->Add(s);
//sprintf(s,"datlmintav: %.3f",dmintav);  Form1->Memo1->Lines->Add(s);



//if (tipsz>tipsz0) {dtipsz=1;} else {dtipsz-=1;} //if (dtipsz<=-0.99 && 80<tipsz) {return(tipsz);}
dtipsz=tipsz-tipsz0; fl=atltiptav/atlmintav; if (dtipsz<5 && fl<szorkusz*0.9) {dtipsz=-1;}
fl=(float)vektorszam/(float)tipsz; if (fl<5) {dtipsz=-1;}

fl=atlmintav*szorkusz;  tipsz0=tipsz; ksz=int((float)vektorszam/(float)(tipsz0*2)+0.5);  if (ksz>10) {ksz=10;}
if (atltiptav/atlmintav<szorkusz*0.8) {return(tipsz);}
if ((float)vektorszam/(float)tipsz<4) {return(tipsz);}

for (i=1;i<=tipsz0;i++) {  //Form1->Memo1->Lines->Add(minsorsz[i]);
  if (fl<atltav[i] && atlmintav<minwtav[i] && tipsz<=tipsz0+49 && tal[i]>=ksz) { tipsz+=1;  sorsz=(int)(minsorsz[i]+0.5); //Form1->Memo1->Lines->Add(tal[i]);
    if (minwtav[i]<atltav[i]*3.0) {for (j=1;j<=dimenz;j++) {w[tipsz][1][j]=w[i][1][j]+(random(10)-5)/20000.0; w[tipsz][0][j]=w[i][0][j]; w[tipsz][2][j]=w[i][2][j]+(random(10)-5)/20000.0;} }
    else {for (j=1;j<=dimenz;j++) {w[tipsz][1][j]=vektorok[sorsz][j]; w[tipsz][0][j]=w[i][0][j];} for (j=1;j<=dimenz2;j++) {w[tipsz][2][j]=hanghiszt[sorsz][j];} }
    for (j=1;j<=3;j++) {vektkoord0[tipsz][j]=vektkoord0[i][j];vektkoord[tipsz][j]=vektkoord[i][j];}
  }
}

return(tipsz);
}
//-----------------------------------------------------------------------------


//---- SOC functions -----------------------------------------------------------------

void adaptfhtop( int minsorszam, int dsorsz, float tavk0, float tavk1, float eta, int dim)
{
int i,j,k,felt;
float fl,fl2,tav,tav2,eta2;

for (i=1;i<=utso;i++) { tav=0;

  for (j=1;j<=dim;j++) {
    fl=vektkoord0[i][j]-vektkoord0[minsorszam][j]; tav+=fl*fl;
  }
  tav=sqrt(tav);


  tav2=0;
  for (j=1;j<=dimenz;j++) {
     fl=vektorok[dsorsz][j]-vektorok[i][j]; tav2+=fl*fl;
  }
  tav2=sqrt(tav2/(float)dimenz); //if (tav2>1.0) {Form1->Memo1->Lines->Add(tav2);}

  felt=0;  eta2=eta*.1;
  if (tav<tavk0 && tav>=tavk1 && tav2>=.0) {felt=1;/*Form1->Memo1->Lines->Add(tav2);*/}
  
  if (minsorszam==i) {felt=1;eta2=eta;}

  if (felt==1) {    //Form1->Memo1->Lines->Add(i);
     if (hahisuly<0.99) {
       for (k=1;k<=dimenz;k++) {
         fl=vektorok[dsorsz][k]-w[i][1][k];w[i][1][k]+=eta2*fl*(1-hahisuly);
         fl=fohang[k]-w[i][0][k];w[i][0][k]+=eta2*fl*.99*(1-hahisuly*0); if (w[i][0][k]<.1) {w[i][0][k]=.1;}

        //fl=w[i][1][k]-0.0; fl=1.0-exp(-1.5*fl*fl)-w[i][0][k];w[i][0][k]+=eta2*fl; if (w[i][0][k]<.1) {w[i][0][k]=.1;}  //if (w[i][1][k]<2.0) {w[i][0][k]+=(.3-w[i][0][k])*eta2;}
        //fl=vektorok[dsorsz][k]-0.0; fl=1.0-exp(-3.5*fl*fl)-w[i][0][k];w[i][0][k]+=eta2*fl; if (w[i][0][k]<.05) {w[i][0][k]=.05;}  //if (w[i][1][k]<2.0) {w[i][0][k]+=(.3-w[i][0][k])*eta2;}
        //fl=1.0-1.0/(1.0+exp(-6.1*(fl-4.0))); fl=fl-w[i][0][k]; if (vektorok[dsorsz][k]<=0.01) {fl=0.1-w[i][0][k];}   w[i][0][k]+=eta2*fl;   if (w[i][0][k]<.1) {w[i][0][k]=.1;}  //if (w[i][1][k]<2.0) {w[i][0][k]+=(.3-w[i][0][k])*eta2;}
        //w[i][0][k]=1.0;
       }
     }
     if (0.001<hahisuly) {
       fl2=0;
       for (k=1;k<=dimenz2;k++) {
         fl=hanghiszt[dsorsz][k]-w[i][2][k];w[i][2][k]+=eta2*fl*hahisuly*5; fl2+=w[i][2][k];  //Form1->Memo1->Lines->Add(w[i][2][k]);
       }
       //if (fl2==0) {fl2=10;} for (k=1;k<=dimenz2;k++) {w[i][2][k]=50/fl2*w[i][2][k];}
     }

  }
}

}



void somtavpont(int sorszam)
{
int i,k;
float fl,fl1,fl2;

for (i=1;i<=utso;i++) {
    fl2=0; for (k=1;k<=dimenz;k++) {fl2+=w[sorszam][0][k];}  fl2=(float)dimenz/fl2;
    fl1=0; for (k=1;k<=dimenz;k++) {fl=w[i][1][k]-w[sorszam][1][k];fl1+=fl*fl*w[sorszam][0][k]*fl2;}
    vekttav[sorszam][i]=sqrt(fl1);  //Form1->Memo1->Lines->Add(vekttav[xx][yy][i][j]);
}

}


void somtavmatr(void)
{
int i,m;
float fl,max;

for (i=1;i<=utso;i++) {
  for (m=1;m<=utso;m++) {vekttav[i][m]=0;}
}

for (i=1;i<=utso;i++) {somtavpont(i);}

max=-10000;
for (i=1;i<=utso;i++) {
  for (m=1;m<=utso;m++) {if (max<vekttav[i][m]) {max=vekttav[i][m];}}
}

fl=(float)term[1]*1.5*krittav/max;  nyujtas=fl*max; //fl=.5;
for (i=1;i<=utso;i++) {
  for (m=1;m<=utso;m++) {vekttav[i][m]*=fl;}
}


}


void somtavpont2(int sorszam)
{
int i,k;
float fl,fl1,fl2;

for (i=1;i<sorszam;i++) {
    fl2=0; for (k=1;k<=dimenz;k++) {fl2+=w[sorszam][0][k];} fl2=(float)dimenz/fl2;
    fl1=0; for (k=1;k<=dimenz;k++) {fl=w[i][1][k]-w[sorszam][1][k];fl1+=fl*fl*fl2;}
    fl1=sqrt(fl1);

    fl2=0; for (k=1;k<=dimenz2;k++) {fl=w[i][2][k]-w[sorszam][2][k];fl2+=fl*fl*hangsuly[k];}
    fl2=sqrt(fl2/hahinorm);

    fl=fl1*(1.0-hahisuly)+fl2*hahisuly;
    if (hahisuly>0.99) {fl=fl2;}
    vekttav[sorszam][i]=fl;
    vekttav[i][sorszam]=fl;
}
vekttav[sorszam][sorszam]=0;

}


void somtavnorm(void)
{
int i,m;
float fl,max;

/*
for (i=1;i<=utso;i++) {
  for (m=1;m<=utso;m++) {vekttav[i][m]=0;}
}
*/

for (i=1;i<=utso;i++) {somtavpont2(i);}

max=-10000;
for (i=1;i<=utso;i++) {
  for (m=1;m<i;m++) {if (max<vekttav[i][m]) {max=vekttav[i][m];}}
}

if (max==0) {max=1.0;}
fl=(float)term[1]*1.0*krittav/max;  nyujtas=fl*max; //fl=.5;
for (i=1;i<=utso;i++) {
  for (m=1;m<=utso;m++) {vekttav[i][m]*=fl;}
}

}
//-------------------------------------------------------------------------------


//--------Minimal spanning tree functions ------------------------------------------------

int mini,minj;
float krustav[NPONT+1][NPONT+1];

float minval(int dim, float tavkusz)
{
int i,j;
float mintav;

mintav=1000; mini=0;minj=0;
for (i=1;i<=dim;i++) {
  for (j=1;j<i;j++) {
    if (krustav[i][j]<mintav && krustav[i][j]<=tavkusz && i!=j) {mintav=krustav[i][j];mini=i;minj=j;}
  }
}

return(mintav);

}


void kruskal(int dim, float tavkusz)
{
int i,j,k, elszam, fa[2000];
float mintav;
char s[100];

for (i=1;i<=dim;i++) {
  for (j=1;j<=dim;j++) { feltetel[i][j]=0;  krustav[i][j]=vekttav[i][j];
  }
}

for (i=1;i<2000;i++) {fa[i]=10000;}
k=1;
for (i=1;i<=dim;i++) {
  for (j=1;j<i;j++) {
    if (krustav[i][j]<=tavkusz) {k++;}
    else {krustav[i][j]=1000;krustav[j][i]=1000;}
  }
}
elszam=k-1;
//Form1->Memo1->Lines->Add(elszam); return;

for (i=1;i<=dim;i++) {fa[i]=i;}
int minfa,maxfa;

j=0;
for (k=1;k<=elszam;k++) { mintav=minval(dim, tavkusz);
  if (fa[mini]!=fa[minj]) {
    j++; feltetel[mini][minj]=1;  //feltetel[minj][mini]=1;
    if (fa[minj]<fa[mini]) {minfa=fa[minj];maxfa=fa[mini];} else {minfa=fa[mini];maxfa=fa[minj];}
    sprintf(s,"%d %d %.3f   %d",fa[mini],fa[minj],mintav,minfa); Form1->Memo1->Lines->Add(s);
    for (i=1;i<=dim;i++) {if (fa[i]==maxfa) {fa[i]=minfa;}}
    //sprintf(s,"%d %d %.3f   %d",fa[minfa],fa[maxfa],mintav,minfa); Form1->Memo1->Lines->Add(s);   Form1->Memo1->Lines->Add(" ");
  }
  krustav[mini][minj]=1000;
}


}
//-----------------------------------------------------------------------------




//-------------------- Generating PS files (not in use) -----------------------------------------------------------------------
void postker1(int X0, int Y0, int X1, int Y1, char *npp)
{
FILE *out;
char s[1000], fejlec[20000], *st, *spt;
int indx, nnn,i;


/*npp = "c:/eurkat/dvabr.ps";*/ out = fopen( npp, "w"); indx=fclose(out);
out = fopen( npp, "w");


for (i=0;i<20000;i++) {fejlec[i]=0;}
for (i=0;i<1000;i++) {s[i]=0;}

st=&fejlec[0]; spt=&s[0];


//st="%!PS-Adobe-3.0 EPSF-3.0 \n %%BoundingBox: 97 197 501 601 \n %%Creator:nkorr.c \n %%Title: bazis \n %%EndComments \n /M {moveto} bind def \n /L {lineto} bind def \n /R {rlineto} bind def \n /D { M -2 2 R 4 0 R 0 -4 R closepath fill} def \n /T { 2 0 360 arc stroke} def \n /K { M -2 0 R 4 0 R -2 0 R 0 2 R 0 -4 R } def \n /CS {stringwidth 2 div neg exch 2 div neg exch rmoveto } bind def \n /Times-Roman findfont \n 30 scalefont \n setfont \n stroke \n \n";
//nnn=strlen(st); fwrite(st,nnn,1,out);


st="%!PS-Adobe-3.0 EPSF-3.0 \n %%BoundingBox: 97 197 501 601 \n %%Creator:nkorr.c \n %%Title: bazis \n %%EndComments \n /M {moveto} bind def \n /L {lineto} bind def \n /R {rlineto} bind def \n /D { 2 setlinewidth M -4 4 R 8 0 R 0 -8 R closepath} def \n /T { 1 setlinewidth 1 0 360 arc stroke 1 setlinewidth stroke} def \n /T2 { 2 setlinewidth 2 0 360 arc fill stroke 1 setlinewidth stroke} def \n /T3 { 2 setlinewidth 3 0 360 arc fill stroke 1 setlinewidth stroke} def \n /T4 { 2 setlinewidth 4 0 360 arc fill stroke 1 setlinewidth stroke} def \n /K { .5 setlinewidth M -1 0 R 2 0 R -1 0 R 0 1 R 0 -2 R stroke 1 setlinewidth stroke} def \n /K2 { 2 setlinewidth M -3 0 R 6 0 R -3 0 R 0 3 R 0 -6 R stroke 1 setlinewidth stroke} def \n/CS {stringwidth 2 div neg exch 2 div neg exch rmoveto } bind def \n /Times-Roman findfont \n 12 scalefont \n setfont \n stroke \n \n";
nnn=strlen(st); fwrite(st,nnn,1,out);



sprintf(s, "0 0 translate\n"); nnn=strlen(s); fwrite(s,nnn,1,out);
sprintf(s, "1 1 scale\n"); nnn=strlen(s); fwrite(s,nnn,1,out);

sprintf(s, "0 setgray\n"); nnn=strlen(s); fwrite(s,nnn,1,out);
sprintf(s, "1 setlinewidth 2 setlinecap\n"); nnn=strlen(s); fwrite(s,nnn,1,out);
sprintf(s, "newpath %d %d M 0 %d R %d 0 R 0 %d R closepath\n",X0,Y0,Y1,X1,-1*Y1);
nnn=strlen(s); fwrite(s,nnn,1,out);

sprintf(s, "1 setgray fill 0 setgray\n"); nnn=strlen(s); fwrite(s,nnn,1,out);

sprintf(s, "0 0 translate\n"); nnn=strlen(s); fwrite(s,nnn,1,out);
sprintf(s, "1 1 scale\n"); nnn=strlen(s); fwrite(s,nnn,1,out);

sprintf(s, "0 setgray\n"); nnn=strlen(s); fwrite(s,nnn,1,out);

st="M";
sprintf(s, "%d %d %s \n", X0,Y0,st); nnn=strlen(s); fwrite(s,nnn,1,out);
sprintf(s, "2 setlinewidth 2 setlinecap\n"); nnn=strlen(s); fwrite(s,nnn,1,out);

sprintf(s, "newpath %d %d M 0 %d R %d 0 R 0 %d R closepath\n",X0,Y0,Y1,X1,-1*Y1);
nnn=strlen(s); fwrite(s,nnn,1,out);
sprintf(s, "stroke \n"); nnn=strlen(s); fwrite(s,nnn,1,out);


/*
y=Y0+Y1+10;
sprintf(s, "newpath %d %d M 0 %d R %d 0 R 0 %d R closepath\n",X0,y,Y1,X1,-1*Y1);
nnn=strlen(s); fwrite(s,nnn,1,out);
*/

sprintf(s, "stroke \n"); nnn=strlen(s); fwrite(s,nnn,1,out);

/*
y=Y0+2*Y1+20;
sprintf(s, "newpath %d %d M 0 %d R %d 0 R 0 %d R closepath\n",X0,y,Y1,X1,-1*Y1);
nnn=strlen(s); fwrite(s,nnn,1,out);
sprintf(s, "stroke \n"); nnn=strlen(s); fwrite(s,nnn,1,out);

y=Y0+3*Y1+30;
sprintf(s, "newpath %d %d M 0 %d R %d 0 R 0 %d R closepath\n",X0,y,Y1,X1,-1*Y1);
nnn=strlen(s); fwrite(s,nnn,1,out);
sprintf(s, "stroke \n"); nnn=strlen(s); fwrite(s,nnn,1,out);

y=Y0+4*Y1+40;
sprintf(s, "newpath %d %d M 0 %d R %d 0 R 0 %d R closepath\n",X0,y,Y1,X1,-1*Y1);
nnn=strlen(s); fwrite(s,nnn,1,out);
sprintf(s, "stroke \n"); nnn=strlen(s); fwrite(s,nnn,1,out);
*/

/*
lepx=(float)X1/(float)(NDIM+1); lepy=200.0;
x=X0; y=Y0-45;
	sprintf(s, "%d %d M \n", x,Y0); nnn=strlen(s); fwrite(s,nnn,1,out);
	sprintf(s, "%d %d R \n", 0,-10); nnn=strlen(s); fwrite(s,nnn,1,out);
	sprintf(s, "%d %d M \n", x,y); nnn=strlen(s); fwrite(s,nnn,1,out);
	sprintf(s, "gsave \n"); nnn=strlen(s); fwrite(s,nnn,1,out);
	sprintf(s, "%d %d translate \n", x,y); nnn=strlen(s); fwrite(s,nnn,1,out);
	sprintf(s, "0 rotate \n"); nnn=strlen(s); fwrite(s,nnn,1,out);
	sprintf(s, "(0) CS \n"); nnn=strlen(s); fwrite(s,nnn,1,out);
	sprintf(s, "(0) show \n"); nnn=strlen(s); fwrite(s,nnn,1,out);
	sprintf(s, "grestore \n"); nnn=strlen(s); fwrite(s,nnn,1,out);

x=(int)(15*lepx+X0+.5); y=Y0-45;
	sprintf(s, "%d %d M \n", x,Y0); nnn=strlen(s); fwrite(s,nnn,1,out);
	sprintf(s, "%d %d R \n", 0,-10); nnn=strlen(s); fwrite(s,nnn,1,out);
	sprintf(s, "%d %d M \n", x,y); nnn=strlen(s); fwrite(s,nnn,1,out);
	sprintf(s, "gsave \n"); nnn=strlen(s); fwrite(s,nnn,1,out);
	sprintf(s, "%d %d translate \n", x,y); nnn=strlen(s); fwrite(s,nnn,1,out);
	sprintf(s, "0 rotate \n"); nnn=strlen(s); fwrite(s,nnn,1,out);
	sprintf(s, "(15) CS \n"); nnn=strlen(s); fwrite(s,nnn,1,out);
	sprintf(s, "(15) show \n"); nnn=strlen(s); fwrite(s,nnn,1,out);
	sprintf(s, "grestore \n"); nnn=strlen(s); fwrite(s,nnn,1,out);

x=(int)(30*lepx+X0+.5); y=Y0-45;
	sprintf(s, "%d %d M \n", x,Y0); nnn=strlen(s); fwrite(s,nnn,1,out);
	sprintf(s, "%d %d R \n", 0,-10); nnn=strlen(s); fwrite(s,nnn,1,out);
	sprintf(s, "%d %d M \n", x,y); nnn=strlen(s); fwrite(s,nnn,1,out);
	sprintf(s, "gsave \n"); nnn=strlen(s); fwrite(s,nnn,1,out);
	sprintf(s, "%d %d translate \n", x,y); nnn=strlen(s); fwrite(s,nnn,1,out);
	sprintf(s, "0 rotate \n"); nnn=strlen(s); fwrite(s,nnn,1,out);
	sprintf(s, "(30) CS \n"); nnn=strlen(s); fwrite(s,nnn,1,out);
	sprintf(s, "(30) show \n"); nnn=strlen(s); fwrite(s,nnn,1,out);
	sprintf(s, "grestore \n"); nnn=strlen(s); fwrite(s,nnn,1,out);
*/

/*
x=X0+X1/2; y=Y0-70;
st=&s[0]; st="Co-ordinate order";
	sprintf(s, "%d %d M \n", x,y); nnn=strlen(s); fwrite(s,nnn,1,out);
	sprintf(s, "gsave \n"); nnn=strlen(s); fwrite(s,nnn,1,out);
	sprintf(s, "%d %d translate \n", x,y); nnn=strlen(s); fwrite(s,nnn,1,out);
	sprintf(s, "0 rotate \n"); nnn=strlen(s); fwrite(s,nnn,1,out);
	sprintf(s, "(%s) CS \n", st); nnn=strlen(s); fwrite(s,nnn,1,out);
	sprintf(s, "(%s) show \n", st); nnn=strlen(s); fwrite(s,nnn,1,out);
	sprintf(s, "grestore \n"); nnn=strlen(s); fwrite(s,nnn,1,out);
	sprintf(s, "stroke \n"); nnn=strlen(s); fwrite(s,nnn,1,out);


x=X0-60; y=Y0+(5*Y1+40)/2;
st=&s[0]; st="Melody Contours";
	sprintf(s, "%d %d M \n", x,y); nnn=strlen(s); fwrite(s,nnn,1,out);
	sprintf(s, "gsave \n"); nnn=strlen(s); fwrite(s,nnn,1,out);
	sprintf(s, "%d %d translate \n", x,y); nnn=strlen(s); fwrite(s,nnn,1,out);
	sprintf(s, "90 rotate \n"); nnn=strlen(s); fwrite(s,nnn,1,out);
	sprintf(s, "(%s) CS \n", st); nnn=strlen(s); fwrite(s,nnn,1,out);
	sprintf(s, "(%s) show \n", st); nnn=strlen(s); fwrite(s,nnn,1,out);
	sprintf(s, "grestore \n"); nnn=strlen(s); fwrite(s,nnn,1,out);
	sprintf(s, "stroke \n"); nnn=strlen(s); fwrite(s,nnn,1,out);

    sprintf(s, "2 setlinewidth 2 setlinecap\n"); nnn=strlen(s); fwrite(s,nnn,1,out);
*/
indx=fclose(out);

}


void postscrk(int X0, int Y0, int X1, int Y1, char *npp)
{
FILE *out;
char s[100], *st;
int indx, nnn, i,  x1,y1, kepszel,kepmag;
float fl1,fl2, cmag,lepes;


st=&s[0];
//npp = "c:/eurkat/dvabr.ps";
out = fopen( npp, "a");

Y0+=10;
kepmag=(float)Y1; kepszel=(float)X1;
lepes=(float)(kepmag-kepmag/10.0)/27.0; cmag=kepmag/20.0+.0*lepes;

fl2=(float)Y1*.02;
//st=septr;

x1=X0+5;
y1=Y1+Y0-15;

sprintf(s, "%d %d M \n", x1,y1); nnn=strlen(s); fwrite(s,nnn,1,out);
sprintf(s, "gsave \n"); nnn=strlen(s); fwrite(s,nnn,1,out);
sprintf(s, "%d %d translate \n", x1,y1); nnn=strlen(s); fwrite(s,nnn,1,out);
//sprintf(s, "(%s) show \n", st); nnn=strlen(s); fwrite(s,nnn,1,out);
sprintf(s, "grestore \n"); nnn=strlen(s); fwrite(s,nnn,1,out);
sprintf(s, "stroke \n"); nnn=strlen(s); fwrite(s,nnn,1,out);


sprintf(s, "1 setlinewidth 2 setlinecap\n"); nnn=strlen(s); fwrite(s,nnn,1,out);
x1=X0; y1=Y0+(int)(cmag+4*lepes+.5); st="M";
sprintf(s, "%d %d %s \n", x1,y1,st); nnn=strlen(s); fwrite(s,nnn,1,out);
x1=X1+X0;st="L";
sprintf(s, "%d %d %s \n", x1,y1,st); nnn=strlen(s); fwrite(s,nnn,1,out);

x1=X0; y1=Y0+(int)(cmag+7*lepes+.5); st="M";
sprintf(s, "%d %d %s \n", x1,y1,st); nnn=strlen(s); fwrite(s,nnn,1,out);
x1=X1+X0;st="L";
sprintf(s, "%d %d %s \n", x1,y1,st); nnn=strlen(s); fwrite(s,nnn,1,out);

x1=X0; y1=Y0+(int)(cmag+11*lepes+.5); st="M";
sprintf(s, "%d %d %s \n", x1,y1,st); nnn=strlen(s); fwrite(s,nnn,1,out);
x1=X1+X0;st="L";
sprintf(s, "%d %d %s \n", x1,y1,st); nnn=strlen(s); fwrite(s,nnn,1,out);

x1=X0; y1=Y0+(int)(cmag+14*lepes+.5); st="M";
sprintf(s, "%d %d %s \n", x1,y1,st); nnn=strlen(s); fwrite(s,nnn,1,out);
x1=X1+X0;st="L";
sprintf(s, "%d %d %s \n", x1,y1,st); nnn=strlen(s); fwrite(s,nnn,1,out);

x1=X0; y1=Y0+(int)(cmag+17*lepes+.5); st="M";
sprintf(s, "%d %d %s \n", x1,y1,st); nnn=strlen(s); fwrite(s,nnn,1,out);
x1=X1+X0;st="L";
sprintf(s, "%d %d %s \n", x1,y1,st); nnn=strlen(s); fwrite(s,nnn,1,out);
sprintf(s, "stroke \n"); nnn=strlen(s); fwrite(s,nnn,1,out);

//sprintf(s, "stroke \n"); nnn=strlen(s); fwrite(s,nnn,1,out);



//float nullszint=w[valvektor][1][dimenz-1]-0;
float nullszint=7;


sprintf(s, "1 setlinewidth 2 setlinecap\n"); nnn=strlen(s); fwrite(s,nnn,1,out);
st="M";
fl1=(float)(nullsav-1)/(float)dimenz*kepszel; x1=(int)(fl1+.5)+X0;
//fl1=(float)(nullsav)/(float)dimenz*kepszel; x1=(int)(fl1+.5)+X0;
y1=Y0+(int)(cmag+(w[cim[valvektor]][1][nullsav]-nullszint+7)*lepes+.5);
//y1=Y0+(int)(cmag+(nymot0[1]-nymot0[dimenz]+7)*lepes+.5);
sprintf(s, "%d %d %s \n", x1,y1,st); nnn=strlen(s); fwrite(s,nnn,1,out);


  fl1=(float)(1-0)/(float)dimenz*kepszel; x1=(int)(fl1+.5)+X0;
  y1=Y0+(int)(cmag+(w[cim[valvektor]][1][1]-nullszint+7)*lepes+.5);
  st="M";
  sprintf(s, "%d %d %s \n", x1,y1,st); nnn=strlen(s); fwrite(s,nnn,1,out);

for (i=nullsav+1; i<=dimenz-nullsav-1; i++) {
  fl1=(float)(i-0)/(float)dimenz*kepszel; x1=(int)(fl1+.5)+X0;
  y1=Y0+(int)(cmag+(w[cim[valvektor]][1][i]-nullszint+7)*lepes+.5);
  st="L";
  sprintf(s, "%d %d %s \n", x1,y1,st); nnn=strlen(s); fwrite(s,nnn,1,out);
}
sprintf(s, "stroke \n"); nnn=strlen(s); fwrite(s,nnn,1,out);
sprintf(s, " \n"); nnn=strlen(s); fwrite(s,nnn,1,out);

/*
int k;
for (k=1;k<=utso;k++) {
  if (rokon[k]==1 && talalat[k]>=1) {
    fl1=(float)(1-0)/(float)dimenz*kepszel; x1=(int)(fl1+.5)+X0;
    y1=Y0+(int)(cmag+(w[k][1][1]-nullszint+7)*lepes+.5);
    st="M";
    sprintf(s, "%d %d %s \n", x1,y1,st); nnn=strlen(s); fwrite(s,nnn,1,out);
    for (i=nullsav+1; i<=dimenz-nullsav-1; i++) {
      fl1=(float)(i-0)/(float)dimenz*kepszel; x1=(int)(fl1+.5)+X0;
      y1=Y0+(int)(cmag+(w[k][1][i]-nullszint+7)*lepes+.5);
      st="L";
      sprintf(s, "%d %d %s \n", x1,y1,st); nnn=strlen(s); fwrite(s,nnn,1,out);
   }
   sprintf(s, "stroke \n"); nnn=strlen(s); fwrite(s,nnn,1,out);
   sprintf(s, " \n"); nnn=strlen(s); fwrite(s,nnn,1,out);
  }
}
*/





/*
sprintf(s, "1 setlinewidth 2 setlinecap\n"); nnn=strlen(s); fwrite(s,nnn,1,out);
for (i=1; i<=dimenz; i++) {
  fl1=(float)(i-0)/(float)dimenz*kepszel; x1=(int)(fl1+.5)+X0;
  y1=Y0+(int)(cmag+(w[valvektor][0][i]*(-10.0)+7)*lepes+.5);
  st="M";
  sprintf(s, "%d %d %s \n", x1,y1,st); nnn=strlen(s); fwrite(s,nnn,1,out);
  fl1=(float)(i-0)/(float)dimenz*kepszel; x1=(int)(fl1+.5)+X0;
  y1+=(int)(w[valvektor][0][i]*20.0*lepes+.5);
  st="L";
  sprintf(s, "%d %d %s \n", x1,y1,st); nnn=strlen(s); fwrite(s,nnn,1,out);
}
sprintf(s, "stroke \n"); nnn=strlen(s); fwrite(s,nnn,1,out);
sprintf(s, " \n"); nnn=strlen(s); fwrite(s,nnn,1,out);


if (dallamrajz==1) {
sprintf(s, "1 setlinewidth 2 setlinecap\n"); nnn=strlen(s); fwrite(s,nnn,1,out);
st="M";
fl1=(float)(1)/(float)dimenz*kepszel; x1=(int)(fl1+.5)+X0;
y1=Y0+(int)(cmag+(nymot0[1]-nullszint+7)*lepes+.5);
sprintf(s, "%d %d %s \n", x1,y1,st); nnn=strlen(s); fwrite(s,nnn,1,out);

for (i=1; i<=dimenz; i++) {
  fl1=(float)(i-0)/(float)dimenz*kepszel; x1=(int)(fl1+.5)+X0;
  y1=Y0+(int)(cmag+(nymot0[i]-nullszint+7)*lepes+.5);
  st="L";
  sprintf(s, "%d %d %s \n", x1,y1,st); nnn=strlen(s); fwrite(s,nnn,1,out);
}
sprintf(s, "stroke \n"); nnn=strlen(s); fwrite(s,nnn,1,out);
sprintf(s, " \n"); nnn=strlen(s); fwrite(s,nnn,1,out);
dallamrajz=0;

}
*/

indx=fclose(out);


}





void feltolt4(void)
{
int i,j,k;
float fl1,fl2, d1,d2,d3,d4, g1,g2,g3,g4, f1,f2,f3,f4, a,b,c;


nagyitas=1.0;  ny=1.0;

/******* e4 koruli forgatas *********/

d1=.999; d2=(1.0-d1*d1)*.9; d3=sqrt(1.0-d1*d1-d2*d2);

g1=d2;
a=d3*d3+d2*d2; b=2.0*g1*d1*d3; c=g1*g1*(d2*d2+d1*d1)-d2*d2;
g3=(-1.0*b+sqrt(b*b-4.0*a*c))/2.0/a;
g2=-1.0*(g1*d1+g3*d3)/d2;

fl1=(d1*g3-g1*d3)/(g1*d2-d1*g2);
fl2=-1.0*(fl1*g2+g3)/g1;

f3=1.0*sqrt(1.0/(fl1*fl1+fl2*fl2+1.0));
f2=fl1*f3;
f1=fl2*f3;

forg1[1][1]=d1; forg1[1][2]=g1; forg1[1][3]=f1; forg1[1][4]=.0;
forg1[2][1]=d2; forg1[2][2]=g2; forg1[2][3]=f2; forg1[2][4]=.0;
forg1[3][1]=d3; forg1[3][2]=g3; forg1[3][3]=f3; forg1[3][4]=.0;
forg1[4][1]=.0; forg1[4][2]=.0; forg1[4][3]=.0; forg1[4][4]=1.0;


/********* e1 koruli forgatas **********/

d2=.999; d3=sqrt(1.0-d2*d2)*.9; d4=sqrt(1.0-d2*d2-d3*d3);

g2=d3;
a=d3*d3+d4*d4; b=2.0*g2*d2*d4; c=g2*g2*(d2*d2+d3*d3)-d3*d3;
g4=(-1.0*b+sqrt(b*b-4.0*a*c))/2.0/a; /**** +- ****/
g3=-1.0*(g2*d2+g4*d4)/d3;

fl1=(d4*g2-g4*d2)/(g3*d2-d3*g2);
fl2=-1.0*(fl1*d3+d4)/d2;

f4=+1.0*sqrt(1.0/(fl1*fl1+fl2*fl2+1.0));      /**** +- *****/
f2=fl2*f4;
f3=fl1*f4;

forg2[1][1]=1.0; forg2[1][2]=.0; forg2[1][3]=.0; forg2[1][4]=.0;
forg2[2][1]=.0;  forg2[2][2]=d2; forg2[2][3]=g2; forg2[2][4]=f2;
forg2[3][1]=.0;  forg2[3][2]=d3; forg2[3][3]=g3; forg2[3][4]=f3;
forg2[4][1]=.0;  forg2[4][2]=d4; forg2[4][3]=g4; forg2[4][4]=f4;


/********* e2 koruli forgatas **********/

f1=.999; f3=sqrt(1.0-f1*f1)*.9; f4=sqrt(1.0-f1*f1-f3*f3);

g1=f3;
a=f3*f3+f4*f4; b=2.0*g1*f1*f4; c=g1*g1*(f3*f3+f1*f1)-f3*f3;
g4=(-1.0*b+sqrt(b*b-4.0*a*c))/2.0/a; /**** +- ****/
g3=-1.0*(g1*f1+g4*f4)/f3;

fl1=(g4*f1-g1*f4)/(g1*f3-g3*f1);
fl2=-1.0*(fl1*g3+g4)/g1;

d4=+1.0*sqrt(1.0/(fl1*fl1+fl2*fl2+1.0));      /**** +- *****/
d1=fl2*d4;
d3=fl1*d4;

forg3[1][1]=f1;  forg3[1][2]=.0;  forg3[1][3]=g1;  forg3[1][4]=d1;
forg3[2][1]=.0;  forg3[2][2]=1.0; forg3[2][3]=.0;  forg3[2][4]=.0;
forg3[3][1]=f3;  forg3[3][2]=.0;  forg3[3][3]=g3;  forg3[3][4]=d3;
forg3[4][1]=f4;  forg3[4][2]=.0;  forg3[4][3]=g4;  forg3[4][4]=d4;

/******* e3 koruli forgatas *********/

d1=.999; d2=(1.0-d1*d1)*.9; d4=sqrt(1.0-d1*d1-d2*d2);

g1=d2;
a=d2*d2+d4*d4; b=2.0*g1*d1*d4; c=g1*g1*(d2*d2+d1*d1)-d2*d2;
g4=(-1.0*b+sqrt(b*b-4.0*a*c))/2.0/a;
g2=-1.0*(g1*d1+g4*d4)/d2;

fl1=(d1*g4-g1*d4)/(d1*g2-g1*d2);
fl2=-1.0*(fl1*d2+d4)/d1;

f4=1.0*sqrt(1.0/(fl1*fl1+fl2*fl2+1.0));
f2=fl1*f4;
f1=fl2*f4;

forg4[1][1]=d1; forg4[1][2]=g1; forg4[1][3]=.0; forg4[1][4]=f1;
forg4[2][1]=d2; forg4[2][2]=g2; forg4[2][3]=.0; forg4[2][4]=f2;
forg4[3][1]=.0; forg4[3][2]=.0; forg4[3][3]=1.0; forg4[3][4]=.0;
forg4[4][1]=d4; forg4[4][2]=g4; forg4[4][3]=.0; forg4[4][4]=f4;


cc[1][1]=1.0; cc[1][2]=.0; cc[1][3]=.0; cc[1][4]=.0;
cc[2][1]=.0; cc[2][2]=1.0; cc[2][3]=.0; cc[2][4]=.0;
cc[3][1]=.0; cc[3][2]=.0;  cc[3][3]=1.0; cc[3][4]=.0;
cc[4][1]=.0; cc[4][2]=.0;  cc[4][3]=.0; cc[4][4]=1.0;


/*
cc[1][1]=1.0; cc[1][2]=.0;
cc[2][1]=.0; cc[2][2]=.0;
cc[3][1]=.0; cc[3][2]=.0;
cc[4][1]=.0; cc[4][2]=1.0;
*/

//baz[0][1]=.0; baz[0][2]=.0; baz[0][3]=0.0; baz[0][4]=.0;


for (i=0; i<=ND; i++) {
	for (j=0; j<=ND; j++) { baz[i][j]=0;}
	baz[i][i]=70;
}


for (k=1; k<=pontsz; k++) {
  for (i=1; i<=2; i++) { z[k][i]=.0;
	 for (j=1; j<=ND; j++) { z[k][i]+=cc[j][i]*vektkoord0[k][j];}
  }
}

}
//--------------------------------------------------------------------------------


//------ graphical representation of vector systems --------------------------------
void feltolt3(void)
{
int i,j,k;
double fl, forg;
int sajszam;

for (j=1; j<=dimenz; j++) {sv[j]=1.0;}
sajszam=1;

nagyitas=1.0; ny=1.0;
forg=.9999; fl=sqrt(1.0-forg*forg);

forg1[1][1]=1.0; forg1[1][2]=.0; forg1[1][3]=.0;
forg1[2][1]=.0; forg1[2][2]=forg; forg1[2][3]=-1.0*fl;
forg1[3][1]=.0; forg1[3][2]=fl; forg1[3][3]=forg;

forg2[1][1]=forg; forg2[1][2]=fl; forg2[1][3]=.0;
forg2[2][1]=-1.0*fl; forg2[2][2]=forg; forg2[2][3]=.0;
forg2[3][1]=.0; forg2[3][2]=.0; forg2[3][3]=1.0;

forg3[1][1]=forg; forg3[1][2]=.0; forg3[1][3]=fl;
forg3[2][1]=.0; forg3[2][2]=1.0; forg3[2][3]=.0;
forg3[3][1]=-1.0*fl; forg3[3][2]=.0; forg3[3][3]=forg;


cc[1][1]=1.0; cc[1][2]=.0;
cc[2][1]=.0; cc[2][2]=1.0;
cc[3][1]=.0; cc[3][2]=.0;

/* egysegvektorok definialasa */

baz[0][1]=.0; baz[0][2]=.0; baz[0][3]=0.0;

for (i=1; i<=ND; i++) {
  for (j=1; j<=ND; j++) {baz[i][j]=0;}
  baz[i][i]=70;
}

pontsz=utso-elso+1;
for (k=0; k<=pontsz; k++) {
  for (i=1; i<=2; i++) { z[k][i]=.0;
	 for (j=1; j<=ND; j++) { z[k][i]+=cc[j][i]*vektkoord0[k][j];}
  }
}

}

void sulypont(int pontsz, int dim)
{
int k,j;

for (j=1;j<=dim;j++) {sulyp[j]=.0;}

for (k=1;k<=pontsz;k++) {
  for (j=1;j<=dim;j++) {sulyp[j]+=vektkoord0[k][j];}
}
for (j=1;j<=dim;j++) {sulyp[j]/=(float)pontsz;}

}


void forgat(float dc1)
{
double fl, vekt[8];
int i,j,k,l;

if (dc1==1.0) {
 for (l=1; l<=2; l++) {
  for (k=1; k<=2; k++) {
	for (i=1; i<=ND; i++) {  vekt[i]=.0;
	 for (j=1; j<=ND; j++) { vekt[i]+=forg1[i][j]*cc[j][k];}
	}
  for (i=1; i<=ND; i++) { cc[i][k]=vekt[i];}
  }
 }
}

if (dc1==2.0) {
 for (l=1; l<=2; l++) {
  for (k=1; k<=2; k++) {
	for (i=1; i<=ND; i++) {  vekt[i]=.0;
	 for (j=1; j<=ND; j++) { vekt[i]+=forg2[i][j]*cc[j][k];}
	}
  for (i=1; i<=ND; i++) { cc[i][k]=vekt[i];}
  }
 }
}

if (dc1==3.0) {
 for (l=1; l<=2; l++) {
  for (k=1; k<=2; k++) {
	for (i=1; i<=ND; i++) {  vekt[i]=.0;
	 for (j=1; j<=ND; j++) { vekt[i]+=forg3[i][j]*cc[j][k];}
	}
  for (i=1; i<=ND; i++) { cc[i][k]=vekt[i];}
  }
 }
}


if (dc1==4.0) {
 for (l=1; l<=2; l++) {
  for (k=1; k<=2; k++) {
	for (i=1; i<=ND; i++) {  vekt[i]=.0;
	 for (j=1; j<=ND; j++) { vekt[i]+=forg4[i][j]*cc[j][k];}
	}
  for (i=1; i<=ND; i++) { cc[i][k]=vekt[i];}
  }
 }
}

if(dc1==5.0) { ny*=nagyitas;}

if (dc1==6.0) {ptav*=nagyitas;}


for (k=1; k<=pontsz; k++) {
  for (i=1; i<=2; i++) { fl=.0;
	 for (j=1; j<=ND; j++) { fl+=cc[j][i]*(vektkoord0[k][j]-sulyp[j])*ny;}
	 z[k][i]=fl;
  }
}

for (k=1; k<=pontsz; k++) {z[k][1]+=terx/2;z[k][2]+=tery/2;}

}



void bazforg(float dc1)
{
double fl;
int i,j,k;


if(dc1==4.0) {
  for (k=1; k<=ND; k++) {
	 for (j=1; j<=ND; j++) { baz[k][j]*=nagyitas;}
  }
}

for (k=1; k<=ND; k++) {
  for (i=1; i<=2; i++) { fl=.0;
	 for (j=1; j<=ND; j++) { fl+=cc[j][i]*(baz[k][j]);}
	 bz[k][i]=fl;
  }

}

}

int sikgen(float a, float b, float c, float d, float lep, float szin, int mer1, int mer2, int kezd)
{
int i,j,k,szaml, rr,gg,bb;
float x,y,z,rn[10];

szaml=0;    randomize();   rr=int((float)245*szin+.5); gg=int((float)100*szin+.5); bb=int((float)245*szin+.5);
for (i=1;i<=mer1;i++) { x=(float)i*lep;
  for (j=1;j<=mer2;j++) { y=(float)j*lep; z=-1.0/c*(a*x+b*y+d);
    for (k=1;k<=3;k++) {rn[k]=random(100)/100.0*lep;}
    for (k=4;k<=6;k++) {rn[k]=random(100)/100.0*lep;}
    for (k=7;k<=9;k++) {rn[k]=random(10);}
    vektorok[kezd+szaml][1]=x+rn[1]; vektorok[kezd+szaml][2]=y+rn[2];vektorok[kezd+szaml][3]=z+rn[3];
    vektorok[kezd+szaml][4]=a+rn[4]; vektorok[kezd+szaml][5]=b+rn[5];vektorok[kezd+szaml][6]=c+rn[6];
    vektorok[kezd+szaml][7]=rr+rn[7]; vektorok[kezd+szaml][8]=gg+rn[8];vektorok[kezd+szaml][9]=bb+rn[9];
    szaml++;
  }
}

return(kezd+szaml);
}
//---------------------------------------------------------------------------


//------ C++ Builder interactive functions ------------------------------------
//---------------------------------------------------------------------------
//---- graphical representation of the learning vectors in MDS map ----------------------
void __fastcall TForm1::PaintBox1Click(TObject *Sender)
{
int xmeret,ymeret;
char *koor, koord[4], sorsz[10], *ssz;
int i,j, x1,x2,y1,y2, centr1, centr2;
float fl1, fl2,fl;

ssz=&sorsz[0]; koor=&koord[0]; koord[1]=0; koord[2]=0;

ymeret=PaintBox1->Height-1;
xmeret=PaintBox1->Width-1;
PaintBox1->Cursor=crCross;

fl1=(float)xmeret/(float)terx*nyujt; fl2=(float)ymeret/(float)tery*nyujt;
centr1=xmeret/2; centr2=ymeret/2;

PaintBox1->Canvas->Brush->Color=clWhite;

//x1=centr1;y1=centr2; x2=centr1+20; y2=centr2+20;
PaintBox1->Canvas->Rectangle(0,0,xmeret,ymeret);



int xx,yy,zz,ww,ii;

for (ii=1;ii<=utso;ii++) {
xx=int(vektkoord0[ii][1]+.5);
yy=int(vektkoord0[ii][2]+.5);
zz=int(vektkoord0[ii][3]+.5);
ww=int(vektkoord0[ii][4]+.5);
//if (x<terx && x>0 && y<tery && y>0 && z<terz && z>0) {vektkoord[sorsz][1]=x;vektkoord[sorsz][2]=y;vektkoord[sorsz][3]=z;}
if (xx<=0) {xx=0;} if (xx>terx) {xx=terx;}
if (yy<=0) {yy=0;} if (yy>tery) {yy=tery;}
if (zz<=0) {zz=0;} if (zz>terz) {zz=terz;}
if (ww<=0) {ww=0;} if (ww>terw) {ww=terw;}
vektkoord[ii][1]=xx;vektkoord[ii][2]=yy;vektkoord[ii][3]=zz;vektkoord[ii][4]=ww;
}




//for (i=1;i<=1000;i++) {talalat[i]=1;}

/* ********* terkep *********** */
/*
x2=(int)(bz[0][1]*fl1+.5)+centr1;
y2=(int)(bz[0][2]*fl2+.5)+centr2;
for (k=1; k<=ND; k++) {
	  x1=(int)(bz[k][1]*fl1+.5)+centr1;
	  y1=(int)(-1.0*bz[k][2]*fl2+.5)+centr2;
	  PaintBox1->Canvas->MoveTo(x1,y1);
      PaintBox1->Canvas->LineTo(x2,y2);
}
*/


PaintBox1->Canvas->Brush->Color=clGreen;

int k, szin[10001];
float ossztal;
ossztal=0; for (k=1;k<=utso;k++) {ossztal+=(float)talalat[k];}
//szinhat=2324;
//szinhat=58;

for (i=1;i<=10000;i++) {szin[i]=0;}

for (k=1;k<=utso;k++) {//i=vektkoord[k][1]; j=vektkoord[k][2];


  if (cim[k]==valvekt) {szin[k]=4;}
  //if (cim[k]<=szinhat && szin[i][j]!=4) {szin[i][j]=1;}
  //if (cim[k]>szinhat && szin[i][j]==0 && szin[i][j]!=4) {szin[i][j]=2;}
  //if (cim[k]>szinhat && szin[i][j]==1 && szin[i][j]!=4) {szin[i][j]=3;}


  //if (tipelt[cim[k]][valvekt]==1) {szin[i][j]=2;} else {szin[i][j]=1;}
  //szin[i][j]=1;
  //if (vektorok[k][1]==1 && vektorok[k][8]==1 && vektorok[k][9]==1 && vektorok[k][10]==1 && vektorok[k][15]==1 && vektorok[k][23]==1) {szin[i][j]=4;}
  //if (vektorok[k][17]==1 && vektorok[k][18]==1 && vektorok[k][19]==1 && vektorok[k][20]==1) {szin[i][j]=3;}

  //if (vektorok[k][10]==1 && vektorok[k][16]!=1) {szin[i][j]=3;}
  //if (vektorok[k][10]!=1 && vektorok[k][16]==1) {szin[i][j]=4;}
  //if (vektorok[k][5]==1) {szin[i][j]=4;}




}

int hh, sug;
char *ch=new char[10];

int feh=255*pow(2,0)+255*pow(2,8)+255*pow(2,16);
long int szin0;


sug=2;
for (k=1;k<=utso;k++) {
  //i=vektkoord[k][1]; j=vektkoord[k][2];
  //i=int(z[k][1]+.5); j=int(z[k][2]+.5);

  /*
  x1=(int)(fl1*((float)i+(float)j*cos(alfa)+.5));
  y1=(int)(fl2*((float)j*sin(alfa)+.5));
  x2=x1;
  */

  //sug=1*int(pow(talalat[k],0.6)+.5);
  //if (talalat[cim[k]]==0) {sug=1; szin[k]=3;}  else {szin[k]=1;sug=4;}


  //if(cim[k]==valvekt) {szin[k]=4;}
  //if(rokon[cim[k]]==1) {szin[k]=4;}
 /*
  szinhatar[1]=378; szinhatar[2]=641;
  szin[cim[k]]=5;
  if (cim[k]>=szinhatar[1]) {szin[cim[k]]=2;}
  if (cim[k]>=szinhatar[2]) {szin[cim[k]]=1;sug=3;}
  if (cim[k]>=szinhatar[3]) {szin[cim[k]]=6;sug=3;}
  if (cim[k]>=szinhatar[4]) {szin[cim[k]]=1;sug=2;}
  if (cim[k]>=szinhatar[5]) {szin[cim[k]]=4;}
  if (cim[k]>=szinhatar[6]) {szin[cim[k]]=7;}
  //if (cim[k]>=szinhatar[9]) {szin[k]=8;}
  */



  x1=(int)(fl1*z[k][1]+z[k][2]*cos(alfa)+.5);
  y1=(int)(fl2*z[k][2]*sin(alfa)+.5);
  //x2=x1;


  //hh=sqrt(val[k]*10.0);
  //hh=talalat[k]*100.0+.5);
  y2=y1+(int)((float)talalat[k]*oszl+.5);

  //szin[i][j]=1;
  /*
  if (szin[k]==1) {PaintBox1->Canvas->Brush->Color=clGreen;PaintBox1->Canvas->Pen->Color=clGreen;}
  if (szin[k]==2) {PaintBox1->Canvas->Brush->Color=clYellow;PaintBox1->Canvas->Pen->Color=clYellow;}
  if (szin[k]==3) {PaintBox1->Canvas->Brush->Color=clMaroon;PaintBox1->Canvas->Pen->Color=clMaroon;}
  if (szin[k]==4) { PaintBox1->Canvas->Brush->Color=clBlue;PaintBox1->Canvas->Pen->Color=clBlue;}
  if (szin[k]==5) { PaintBox1->Canvas->Brush->Color=clBlack;PaintBox1->Canvas->Pen->Color=clBlack;}
  if (szin[k]==6) { PaintBox1->Canvas->Brush->Color=clRed;PaintBox1->Canvas->Pen->Color=clRed;}
  if (szin[k]==7) { PaintBox1->Canvas->Brush->Color=clOlive;PaintBox1->Canvas->Pen->Color=clOlive;}
  */

    if (szinrendszer==5) {
    szin[cim[k]]=szin0=csoportszin_kmed(cim[k]);   //Memo1->Lines->Add(cim[k]);
    if (csop[k]<0) {sug=3;}  else {sug=2;}
    PaintBox1->Canvas->Brush->Color=TColor(szin0);PaintBox1->Canvas->Pen->Color=TColor(szin0); if (szin0==feh) {PaintBox1->Canvas->Pen->Color=clBlack;}
  }



  if (szinrendszer==0) {
    szin[cim[k]]=szin0=csoportszin(cim[k]);   //Memo1->Lines->Add(cim[k]);
    if (csop[k]<=0) {sug=3;}  else {sug=3;}
    PaintBox1->Canvas->Brush->Color=TColor(szin0);PaintBox1->Canvas->Pen->Color=TColor(szin0); if (szin0==feh) {PaintBox1->Canvas->Pen->Color=clBlack;}
  }

  if (szinrendszer==1) {   sug=3;
    szin[cim[k]]=szin0=kultszin(cim[k]);
    PaintBox1->Canvas->Brush->Color=TColor(szin0);PaintBox1->Canvas->Pen->Color=TColor(szin0); if (szin0==feh) {PaintBox1->Canvas->Pen->Color=clBlack;}


    /*
    if (cim[k]>=1) {sug=3;PaintBox1->Canvas->Brush->Color=clBlack;PaintBox1->Canvas->Pen->Color=clBlack;}
    if (cim[k]>=314) {sug=3;PaintBox1->Canvas->Brush->Color=clGreen;PaintBox1->Canvas->Pen->Color=clGreen;}
    if (cim[k]>=803) {sug=3;PaintBox1->Canvas->Brush->Color=clBlue;PaintBox1->Canvas->Pen->Color=clBlue;}
    if (cim[k]>=1404) {sug=3;PaintBox1->Canvas->Brush->Color=clRed;PaintBox1->Canvas->Pen->Color=clRed;}
    if (cim[k]>=2013) {sug=3;PaintBox1->Canvas->Brush->Color=clYellow;PaintBox1->Canvas->Pen->Color=clYellow;}
    if (cim[k]>=2382) {sug=5;PaintBox1->Canvas->Brush->Color=clMaroon;PaintBox1->Canvas->Pen->Color=clMaroon;}
    if (cim[k]>=2725) {sug=5;PaintBox1->Canvas->Brush->Color=clWhite;PaintBox1->Canvas->Pen->Color=clBlack;}
    */
  }

  if (szinrendszer==3) {
    sug=4;
    if (vektorok[cim[k]][10]>0.7) {PaintBox1->Canvas->Brush->Color=clRed;PaintBox1->Canvas->Pen->Color=clRed;}
    if (vektorok[cim[k]][15]>0.7) {PaintBox1->Canvas->Brush->Color=clYellow;PaintBox1->Canvas->Pen->Color=clYellow;}
    if (vektorok[cim[k]][10]>0.7 && vektorok[cim[k]][15]>0.7) {PaintBox1->Canvas->Brush->Color=clYellow;PaintBox1->Canvas->Pen->Color=clRed;}
  }

  if (szinrendszer==4) {sug=2; PaintBox1->Canvas->Brush->Color=clBlack;  PaintBox1->Canvas->Pen->Color=clBlack;
    if (notael[cim[k]]==1) {sug=4; PaintBox1->Canvas->Brush->Color=clRed;PaintBox1->Canvas->Pen->Color=clRed;}
    //if (notael[cim[k]]==2) {sug=4; PaintBox1->Canvas->Brush->Color=clGreen;PaintBox1->Canvas->Pen->Color=clGreen;}
    //if (notael[cim[k]]==3) {sug=4; PaintBox1->Canvas->Brush->Color=clBlack;PaintBox1->Canvas->Pen->Color=clBlack;}
  }

  if (szinrendszer==5) {sug=2; PaintBox1->Canvas->Brush->Color=clGreen; if (cim[k]>szinhat) {sug=4; PaintBox1->Canvas->Brush->Color=clRed;}}

  //PaintBox1->Canvas->Brush->Color=clGreen; PaintBox1->Canvas->Pen->Color=clGreen;
  PaintBox1->Canvas->Rectangle(x1-1,ymeret-y1,x1+1,ymeret-y2);
  PaintBox1->Canvas->Ellipse(x1+sug,ymeret-y1-sug,x1-sug,ymeret-y1+sug);
  PaintBox1->Canvas->Brush->Color=clWhite;

        if (nevadas==4) {itoa(cim[k]-0,ch,10);}
        //if (nevadas==1) {ch=nevad(k);}
        //if (nevadas==2) {ch=nevad2(k);}
        //if (nevadas==3) {ch=nevadhang(k);}
        //if (nevadas==5) {ch=nevadnepz(k);}
        //if (nevadas==6) {ch=nevadzhang(k-8);}
        //if (nevadas==7) {ch=nevadgen(k);}
        //if (nevadas==8) {ch=nevadgenmit(k);}
        //if (nevadas==9) {ch=nevadgen_32(k);}
        //if (nevadas==10) {ch=nevadgenmit_31(k);}
        //if (nevadas==11) {ch=nevad_szity(k);}
        //if (nevadas==12) {ch=szotarbe("c:/genetika/korrel/nev-137.txt",cim[k]);}   //c:/genetika/csoforr.dat
        //if (nevadas==12) {ch=szotarbe("c:/genetika/korrel/nev-NyEurAzs.txt",cim[k]);}   //c:/genetika/csoforr.dat
        //if (nevadas==12) {ch=szotarbe(abrszov,cim[k]);}

  if (nevadas!=0) {PaintBox1->Canvas->TextOut(x1-2,ymeret-y1+4,ch);}
  PaintBox1->Canvas->Brush->Color=clGreen; PaintBox1->Canvas->Pen->Color=clBlack;
}

//return;
// -------------- �lek berajzol�sa -----------------------------


char *str=new char[20];
Edit5->GetTextBuf(str,20); kozelarany=atof(str);

if (elrajz==1) {
float maxtav=-1000;
for (i=1;i<=utso;i++) {
  for (j=1;j<=utso;j++) { if (maxtav<vekttav[i][j]) {maxtav=vekttav[i][j];}}
}
maxtav*=kozelarany;
//Memo1->Lines->Add(fl1);
float xx1,yy1,xx2,yy2, mintav;



PaintBox1->Canvas->Pen->Color=clGray;

for (i=1;i<=utso;i++) {elszam[i]=0;}

int aa,bb,cc,xx;
aa=0;bb=0;xx=0;cc=0;

for (i=1;i<=utso;i++) {
  mintav=1000; for (j=1;j<=utso;j++) {if (vekttav[i][j]<mintav && vekttav[i][j]>0) {mintav=vekttav[i][j];}}
  for (j=1;j<=utso;j++) {  //elszam[i]+=1;

     //k=10; if (vektorok[cim[i]][k]<7 || vektorok[cim[j]][k]<7) {feltetel[i][j]=100;}


    //if (vekttav[i][j]<maxtav && vekttav[j][i]<maxtav && talalat[i]>=1 && talalat[j]>=1) {  if (i!=j && feltetel[i][j]!=0) { elszam[i]+=1; elszam[j]+=1;aa++;}
    if (vekttav[i][j]<maxtav && vekttav[j][i]<maxtav ) {  if (i!=j) { elszam[i]+=1; elszam[j]+=1;aa++;}

      //xx1=vektkoord[i][1];yy1=vektkoord[i][2];xx2=vektkoord[j][1];yy2=vektkoord[j][2];
      xx1=z[i][1]; yy1=z[i][2]; xx2=z[j][1]; yy2=z[j][2];

      //x2=x1;
      x1=(int)(fl1*xx1+yy1*cos(alfa)+.5);
      y1=(int)(fl2*yy1*sin(alfa)+.5);
      x2=(int)(fl1*xx2+yy2*cos(alfa)+.5);
      y2=(int)(fl2*yy2*sin(alfa)+.5);

      //if (talalat[i]>3 && talalat[j]>3 && fabs(talalat[i]-talalat[j])<2) {PaintBox1->Canvas->Pen->Color=clGreen;PaintBox1->Canvas->MoveTo(x1-0,ymeret-y1-0); PaintBox1->Canvas->LineTo(x2-0,ymeret-y2-0);}

      if (utso<500) { PaintBox1->Canvas->Pen->Width=1;
      if (feltetel[i][j]==1) {PaintBox1->Canvas->Pen->Color=clGreen; PaintBox1->Canvas->Pen->Width=2; if (i!=j) {xx++;} }
      if (feltetel[i][j]==-1) {PaintBox1->Canvas->Pen->Color=clMaroon;}    // Maroon
      if (feltetel[i][j]==0) {PaintBox1->Canvas->Pen->Color=clGreen; PaintBox1->Canvas->Pen->Width=1; cc++;}     // Grey

      //fl=pow((talalat[i]+talalat[j])*0.5,3.0)*talalat[0]/7.0;
      //szin0=szurke(1.0-fl); PaintBox1->Canvas->Brush->Color=TColor(szin0);PaintBox1->Canvas->Pen->Color=TColor(szin0);   PaintBox1->Canvas->Pen->Width=5*fl+0.2;

      if (feltetel[i][j]!=100) {PaintBox1->Canvas->MoveTo(x1-0,ymeret-y1-0); PaintBox1->Canvas->LineTo(x2-0,ymeret-y2-0);} PaintBox1->Canvas->Pen->Width=1;
      }
      else {PaintBox1->Canvas->MoveTo(x1-0,ymeret-y1-0); PaintBox1->Canvas->LineTo(x2-0,ymeret-y2-0);}

    }

  }
}

PaintBox1->Canvas->Pen->Color=clBlack;

}


}
//---------------------------------------------------------------------------

//------- graphical representation of the contour type learning vectors pointed by the serial number in Edit1 ---------------
void __fastcall TForm1::PaintBox2Click(TObject *Sender)
{
int xmeret,ymeret;
int k, x1,y1,sorsz;
float fl1, fl2;


/*Edit3->GetTextBuf(ch, sizeof(ch)+1); sorsz=atoi(ch);*/

//if (x2==0) {x2=mx;y2=my;sorsz=1;}

ymeret=PaintBox2->Height-1;
xmeret=PaintBox2->Width-1;

fl1=(float)xmeret/(float)dimenz; fl2=(float)ymeret/40.0;  fl2*=lept;

PaintBox2->Canvas->Brush->Color=clWhite;

PaintBox2->Canvas->Rectangle(0,0,xmeret,ymeret);




PaintBox2->Canvas->MoveTo(0,ymeret/2);
x1=(int)((float)dimenz*fl1+.5);
PaintBox2->Canvas->LineTo(x1,ymeret/2);



x1=(int)((float)dimenz*fl1+.5);
y1=(int)(4.0*fl2+.5);
PaintBox2->Canvas->MoveTo(0,ymeret/2-y1);
PaintBox2->Canvas->LineTo(x1,ymeret/2-y1);

x1=(int)((float)dimenz*fl1+.5);
y1=(int)(-3.0*fl2+.5);
PaintBox2->Canvas->MoveTo(0,ymeret/2-y1);
PaintBox2->Canvas->LineTo(x1,ymeret/2-y1);


x1=(int)((float)dimenz*fl1+.5);
y1=(int)(7.0*fl2+.5);
PaintBox2->Canvas->MoveTo(0,ymeret/2-y1);
PaintBox2->Canvas->LineTo(x1,ymeret/2-y1);

x1=(int)((float)dimenz*fl1+.5);
y1=(int)(-7.0*fl2+.5);
PaintBox2->Canvas->MoveTo(0,ymeret/2-y1);
PaintBox2->Canvas->LineTo(x1,ymeret/2-y1);

x1=(int)((float)dimenz*fl1+.5);
y1=(int)(10.0*fl2+.5);
PaintBox2->Canvas->MoveTo(0,ymeret/2-y1);
PaintBox2->Canvas->LineTo(x1,ymeret/2-y1);

x1=(int)((float)dimenz*fl1+.5);
y1=(int)(-10.0*fl2+.5);
PaintBox2->Canvas->MoveTo(0,ymeret/2-y1);
PaintBox2->Canvas->LineTo(x1,ymeret/2-y1);

PaintBox2->Canvas->Pen->Color=clBlack;
y1=(int)((0-7)*fl2+.5);
PaintBox2->Canvas->MoveTo(0,ymeret/2-y1);
//PaintBox2->Canvas->MoveTo(0,ymeret/2);
PaintBox2->Canvas->Pen->Width=4;

tipabr=1;

if (tipabr==1) {
sorsz=1;
for (k=1;k<=dimenz;k++) {
  x1=(int)((float)k*fl1+.5);
  y1=(int)((w[valvektor][sorsz][k]-7)*fl2+.5);
  PaintBox2->Canvas->LineTo(x1,ymeret/2-y1);
}

PaintBox2->Canvas->Pen->Width=1;
}


if (tipabr==0) {
for (k=1;k<=dimenz;k++) {
  x1=(int)((float)k*fl1+.5);
  y1=(int)((vektorok[cim[valvektor]][k]-7)*fl2+.5);
  PaintBox2->Canvas->LineTo(x1,ymeret/2-y1);
}

PaintBox2->Canvas->Pen->Width=1;
}


if (tipabr==2) {
for (k=1;k<=dimenz2;k++) {
  x1=(int)((float)k*fl1+.5);
  y1=(int)((w[valvektor][2][k])*fl2+.5);
  PaintBox2->Canvas->LineTo(x1,ymeret/2-y1);
}

PaintBox2->Canvas->Pen->Width=1;
}

PaintBox2->Canvas->Pen->Color=clGreen;

int cc;
for (i=1;i<=vektorszam;i++) {cc=cim[i]; //cc=i;
  if (rokon[cc]==1) {//j=szotag[cc];
    PaintBox2->Canvas->MoveTo(0,ymeret/2);
    for (k=1;k<=dimenz;k++) {
      x1=(int)((float)k*fl1+.5);
      y1=(int)((vektorok[cc][k]-7)*fl2+.5);
      PaintBox2->Canvas->LineTo(x1,ymeret/2-y1);  //Memo1->Lines->Add(vektorok[i][k]);
    }
  }
}

PaintBox2->Canvas->Pen->Color=clRed;
for (k=1;k<=dimenz;k++) {
  x1=(int)((float)k*fl1+.5);
  y1=(int)((atl[k]-7)*fl2+.5);
  PaintBox2->Canvas->LineTo(x1,ymeret/2-y1);
}




/*
for (i=1;i<=utso;i++) {cc=i;
  if (rokon[cc]==1) {
  PaintBox2->Canvas->MoveTo(0,ymeret/2);
  for (k=1;k<=dimenz;k++) {
      x1=(int)((float)k*fl1+.5);
      y1=(int)((w[cc][1][k]-7)*fl2+.5);
      PaintBox2->Canvas->LineTo(x1,ymeret/2-y1);  //Memo1->Lines->Add(vektorok[i][k]);
    }
  }
}
*/


PaintBox2->Canvas->Pen->Color=clRed;
PaintBox2->Canvas->MoveTo(0,ymeret/2);
sorsz=0;
for (k=1;k<=dimenz;k++) {
  x1=(int)((float)k*fl1+.5);
  y1=(int)((w[valvektor][sorsz][k])*fl2*10.1+.5);
  PaintBox2->Canvas->MoveTo(x1,ymeret/2+y1);
  PaintBox2->Canvas->LineTo(x1,ymeret/2-y1);
}
PaintBox2->Canvas->Pen->Color=clBlack;


}
//---------------------------------------------------------------------------


//---------------------------------------------------------------------------
void __fastcall TForm1::Button1Click(TObject *Sender)
{
int i;
elrajz=1; elrajz2=1;

PaintBox1Click(Sender);

char *str=new char[30];
Memo1->Lines->Add(" ");
for (i=1;i<=utso;i++) {sprintf(str,"%d %d",i,elszam[i]);Memo1->Lines->Add(str);}
Memo1->Lines->Add(nyujtas);
//elrajz2=0; elrajz=0;

}
//---------------------------------------------------------------------------

// --- select melody type by clicking to a dot in the MDS map. the serial number appears in Edit1  -----------------------
void __fastcall TForm1::PaintBox1MouseUp(TObject *Sender, TMouseButton Button,
	TShiftState Shift, int X, int Y)
{
float fl1,fl2;
int xmeret,ymeret,xkoord,ykoord,i,k;
char s[300];


//return;

for (i=1;i<=NVEKT_MIN;i++) {rokon[i]=0;}

if (motdimenz==0) {motdimenz=6;}

//Edit5->GetTextBuf(s,sizeof(s)+1); kozelarany=atof(s);

Edit5->GetTextBuf(s,20); kozelarany=atof(s);

float maxtav=-1000;
for (i=1;i<=utso;i++) {
  for (k=1;k<=utso;k++) { if (maxtav<vekttav[i][k]) {maxtav=vekttav[i][k];}}
}
//maxtav*=kozelarany;



ymeret=PaintBox1->Height-1;
xmeret=PaintBox1->Width-1;
PaintBox1->Cursor=crCross;

fl1=(float)xmeret/(float)terx*nyujt; fl2=(float)ymeret/(float)tery*nyujt;

//alfa=2*3.14/8.0;

//ykoord=int((ymeret-Y)/fl2/sin(alfa)+.5);
//xkoord=int((float)X/fl1-(float)ykoord*cos(alfa)+.5);
//ykoord-=1;


Memo1->Text=" ";
//Edit1->Text=xkoord;  Edit2->Text=ykoord; Edit3->Text=talalat[minsorszam];
/*
for (i=1;i<=utso;i++) {elof[i]=0;rokon[i]=0;}
for (i=1;i<=utso;i++) {k=cim[i]; rokon[k]=0;
  if (vektkoord[i][1]==xkoord && vektkoord[i][2]==ykoord) { rokon[k]=1;Memo1->Lines->Add(k-0);//furt(k,1);
    for (j=1;j<=utso;j++) {if (kapcsolat[j]!=0) {elof[j]=1;}}
  }
}
*/


//for (k=1;k<=utso;k++) {rokon[k]=0;}

float minegertav,egtav;
int x1,y1;
minegertav=10000;
for (k=1;k<=utso;k++) { //rokon[cim[k]]=0;
  x1=(int)(fl1*z[k][1]+z[k][2]*cos(alfa)+.5);
  y1=(int)(fl2*z[k][2]*sin(alfa)+.5);
  y1=ymeret-y1;
  egtav=sqrt((float)((x1-X)*(x1-X)+(y1-Y)*(y1-Y)));
  if (egtav<minegertav) {minegertav=egtav;valvektor=k;}
}
//rokon[cim[valvektor]]=1;


int srsz;
//float rtavkusz=2.0*nyujt;

srsz=cim[valvektor];  valvekt=cim[valvektor];
Edit1->Text=valvekt;


haskusz=1.7;

float fl;
float rtavkusz=haskusz; //srsz=1318;
//for (i=1;i<=3;i++) {racskoord[i]=(int)(vektkoord0[srsz][i]+.5);}
for (k=1;k<=vektorszam;k++) {  rokon[cim[k]]=0;  //talalat[cim[k]]=0;
  //for (i=1;i<=4;i++) {fl=vektkoord0[k][i]-vektkoord0[srsz][i]; rtav+=fl*fl;} rtav/=1.0;
  //rtav=0; for (i=1;i<=dimenz;i++) {fl=vektorok[k][i]-w[srsz][1][i]; rtav+=fl*fl;} rtav/=(float)dimenz; fl=rtav;
  fl=tiptavmerfh(k,srsz,0);
  if (fl<rtavkusz) {rokon[cim[k]]=1;talalat[cim[k]]=2;Memo1->Lines->Add(cim[k]);}

}

//Edit9->GetTextBuf(nevs,100); Memo1->Lines->Add(nevs);
//katalki(vnfnev0,vektorszam);

/*
float fl;
for (i=1;i<=vektorszam;i++) {cim[i]=i;rokon[cim[i]]=0; talalat[cim[i]]=0;
  fl=tiptavmerfh(i,srsz,0);
  if (fl<.99) {rokon[cim[i]]=1; talalat[cim[i]]=1;Memo1->Lines->Add(i);}
}
*/



//Memo1->Lines->Add(" ");
Memo1->Lines->Add(cim[valvektor]);

//Memo1->Lines->Add(talalat[valvektor]);

//Memo1->Lines->Add(szotarbe("d:/etim/szokeszl.dat",cim[valvektor]));
//szobokor(valvektor,maxtav);
//for (i=1;i<=dimenz;i++) {if (w[valvektor][1][i]>=5) {Memo1->Lines->Add(nevadnepz(i));}}

PaintBox2Click(Sender);    //!!!!!!!!!!!!!!!!

PaintBox4Click(Sender);


xracs=xkoord;yracs=ykoord;
int X0,Y0, X1,Y1;
//X0=99; Y0=199; X1=400; Y1=300;
X0=20;Y0=480;X1=100;Y1=70;
//X0=20;Y0=480;X1=70;Y1=50;
postker1(X0,Y0,X1,Y1, "c:/eurkat/gyokabr.ps");
postscrk(X0,Y0,X1,Y1, "c:/eurkat/gyokabr.ps");



}
//---------------------------------------------------------------------------
void __fastcall TForm1::PaintBox2MouseUp(TObject *Sender, TMouseButton Button,
	TShiftState Shift, int X, int Y)
{
int xmeret,ymeret;
int i,k, x1,x2,y1,y2,sorsz;
float fl1, fl2;
char ch[20];

Edit1->GetTextBuf(ch, sizeof(ch)+1); x2=atoi(ch);
Edit2->GetTextBuf(ch, sizeof(ch)+1); y2=atoi(ch);
/*Edit3->GetTextBuf(ch, sizeof(ch)+1); sorsz=atoi(ch);*/

if (x2==0) {x2=mx;y2=my;/*sorsz=1;*/}

ymeret=PaintBox2->Height-1;
xmeret=PaintBox2->Width-1;

fl1=(float)xmeret/(float)dimenz; fl2=(float)ymeret/40.0;  fl2*=lept;

PaintBox2->Canvas->Brush->Color=clWhite;

PaintBox2->Canvas->Rectangle(0,0,xmeret,ymeret);




PaintBox2->Canvas->MoveTo(0,ymeret/2);
x1=(int)((float)dimenz*fl1+.5);
PaintBox2->Canvas->LineTo(x1,ymeret/2);



x1=(int)((float)dimenz*fl1+.5);
y1=(int)(4.0*fl2+.5);
PaintBox2->Canvas->MoveTo(0,ymeret/2-y1);
PaintBox2->Canvas->LineTo(x1,ymeret/2-y1);

x1=(int)((float)dimenz*fl1+.5);
y1=(int)(-3.0*fl2+.5);
PaintBox2->Canvas->MoveTo(0,ymeret/2-y1);
PaintBox2->Canvas->LineTo(x1,ymeret/2-y1);


x1=(int)((float)dimenz*fl1+.5);
y1=(int)(7.0*fl2+.5);
PaintBox2->Canvas->MoveTo(0,ymeret/2-y1);
PaintBox2->Canvas->LineTo(x1,ymeret/2-y1);

x1=(int)((float)dimenz*fl1+.5);
y1=(int)(-7.0*fl2+.5);
PaintBox2->Canvas->MoveTo(0,ymeret/2-y1);
PaintBox2->Canvas->LineTo(x1,ymeret/2-y1);

x1=(int)((float)dimenz*fl1+.5);
y1=(int)(10.0*fl2+.5);
PaintBox2->Canvas->MoveTo(0,ymeret/2-y1);
PaintBox2->Canvas->LineTo(x1,ymeret/2-y1);

x1=(int)((float)dimenz*fl1+.5);
y1=(int)(-10.0*fl2+.5);
PaintBox2->Canvas->MoveTo(0,ymeret/2-y1);
PaintBox2->Canvas->LineTo(x1,ymeret/2-y1);

y1=(int)((0-7)*fl2+.5);
PaintBox2->Canvas->MoveTo(0,ymeret/2-y1);
//PaintBox2->Canvas->MoveTo(0,ymeret/2);
PaintBox2->Canvas->Pen->Width=4;
sorsz=1;
for (k=1;k<=dimenz;k++) {
  x1=(int)((float)k*fl1+.5);
  y1=(int)((w[(x2-1)*tery+y2][sorsz][k]-7)*fl2+.5);
  PaintBox2->Canvas->LineTo(x1,ymeret/2-y1);
}
PaintBox2->Canvas->Pen->Width=1;


PaintBox2->Canvas->Pen->Color=clGreen;

i=rokind;
while (rokon[i]!=1 && i<=utso) {i++;}
float fl;
if (rokon[i]==1) {
  PaintBox2->Canvas->MoveTo(0,ymeret/2);

  for (k=1;k<=dimenz;k++) {
    if (vektorok[i][k]>=1) {fl=4;} else {fl=0;}

    x1=(int)((float)k*fl1+.5);
    y1=(int)((fl-7+2)*fl2+.5);
    PaintBox2->Canvas->LineTo(x1,ymeret/2-y1);
  }

}

Memo1->Lines->Add(i);
rokind=i+1; if (utso<rokind) {rokind=1;}





PaintBox2->Canvas->Pen->Color=clRed;
PaintBox2->Canvas->MoveTo(0,ymeret/2);
sorsz=0;
for (k=1;k<=dimenz;k++) {
  x1=(int)((float)k*fl1+.5);
  y1=(int)((w[(x2-1)*tery+y2][sorsz][k])*fl2*10+.5);
  PaintBox2->Canvas->MoveTo(x1,ymeret/2+y1);
  PaintBox2->Canvas->LineTo(x1,ymeret/2-y1);
}
PaintBox2->Canvas->Pen->Color=clBlack;


}
//---------------------------------------------------------------------------
// ---- notation of a selevted melody (not in use) ---------------------------------
void __fastcall TForm1::PaintBox3Click(TObject *Sender)
{
return;
int sorsz;
int hossz=Memo1->SelLength; hossz++;
int k, x1,x2,y1,y2, sortav,vtav,also, koz,eleje;
int hangm,rit,hanysor,ker,b;
char *ch=new char[60],*nevp;

int zx21,zy21,zx22,zy22;



Memo1->GetSelTextBuf(ch,hossz); sorsz=atoi(ch);  sorsz=cim[sorsz]; Memo1->Lines->Add(sorsz);
//vnfkatal("c:/eurkat/katalogusr+csuv+cser.dat",sorsz);
//Edit1->Text=sorsz; //nevp=&nevs[9]; Edit8->Text=nevp;
//Edit1->GetTextBuf(ch,sizeof(ch)+1); sorsz=atoi(ch); kottanota=sorsz;

if (sorsz==0) {sorsz=1;} kottanota=sorsz;

hatar1=100000; dimvet=dimenz;
int vnfjel=1;

char *vnfnev= new char[100];

//vnfnev0="c:/eurkat/katalreg+gyujst+pujst.dat";
//vnfnev2="c:/eurkat/katalreg+gyujst+pujst.dat";

vnfnev=vnfnev0;

if (sorsz<=hatar1) {
  if (vnfjel==1) {hanysor=vnftransz(vnfnev,sorsz);nevp=&nevs[9]; Memo1->Lines->Add(nevp); Memo1->Lines->Add(hanysor); Edit6->Text=nevp;}
  //if (cdcjel==1) {nmagy=cdcbe(vnfnev,cdcfogp);hanysor=cdctransz(sorsz);eloj=0;Edit8->Text=cdctul.nev;}
}
/*
if (hatar1<sorsz && sorsz<=hatar2 && magyar==1) {
  if (vnfjel2==1) {hanysor=vnftransz(vnfnev2,sorsz-hatar1);nevp=&nevs[9]; Edit8->Text=nevp;}
  //if (cdcjel2==1) {cdcbe(vnfnev2,cdcfogp);hanysor=cdctransz(sorsz-hatar1);eloj=0;Edit8->Text=cdctul.nev;}
}
*/

//if (hatar2<sorsz) {Edit8->Text="tipus";return;}



PaintBox3->Canvas->Brush->Color=clWhite;
vupx=PaintBox3->Width-1; vupy=PaintBox3->Height-1;
PaintBox3->Canvas->Rectangle(0,0,vupx,vupy);

int hanysor2=hanysor;

if (hanysor2>8) {hanysor2=8;}


sortav=(vupy)/(hanysor2+1); vtav=6; koz=12; eleje=5;
for (k=0; k<hanysor2; k++) {
  for (i=0; i<5; i++) {
	  x1=2; y1=18+k*sortav+i*vtav; x2=vupx-2; y2=y1;
      PaintBox3->Canvas->MoveTo(x1,y1);
      PaintBox3->Canvas->LineTo(x2,y2);
  }
}

/*kptr=&kotta1[0]; eloj=*kptr++;*/

also=18+4*vtav;
if (eloj>0) {x1=2; x2=8; y1=also-4*vtav/2-3; y2=y1+6;
 PaintBox3->Canvas->Ellipse(x1,y1,x2,y2);
 PaintBox3->Canvas->MoveTo(x1,y1);
 PaintBox3->Canvas->LineTo(x1,y1-5);
}
if (eloj>1) {x1=10; x2=16; y1=also-7*vtav/2-3; y2=y1+6;
 PaintBox3->Canvas->Ellipse(x1,y1,x2,y2);
 PaintBox3->Canvas->MoveTo(x1,y1);
 PaintBox3->Canvas->LineTo(x1,y1-5);
 }
if (eloj>2) {x1=18; x2=24; y1=also-3*vtav/2-3; y2=y1+6;
 PaintBox3->Canvas->Ellipse(x1,y1,x2,y2);
 PaintBox3->Canvas->MoveTo(x1,y1);
 PaintBox3->Canvas->LineTo(x1,y1-5);  eleje=10;
}
if (eloj>3) {x1=26; x2=32; y1=also-6*vtav/2-3; y2=y1+6;
 PaintBox3->Canvas->Ellipse(x1,y1,x2,y2);
 PaintBox3->Canvas->MoveTo(x1,y1);
 PaintBox3->Canvas->LineTo(x1,y1-5);    eleje=20;
}

if (eloj<0) {x1=4; y1=also-8*vtav/2;
  PaintBox3->Canvas->MoveTo(x1-3,y1-3);
  PaintBox3->Canvas->LineTo(x1+3,y1+3);
  PaintBox3->Canvas->MoveTo(x1-3,y1+3);
  PaintBox3->Canvas->LineTo(x1+3,y1-3);
}
if (eloj<-1) {x1=8; y1=also-5*vtav/2;
  PaintBox3->Canvas->MoveTo(x1-3,y1-3);
  PaintBox3->Canvas->LineTo(x1+3,y1+3);
  PaintBox3->Canvas->MoveTo(x1-3,y1+3);
  PaintBox3->Canvas->LineTo(x1+3,y1-3);
}

if (eloj<-2) {x1=12; y1=also-9*vtav/2;
  PaintBox3->Canvas->MoveTo(x1-3,y1-3);
  PaintBox3->Canvas->LineTo(x1+3,y1+3);
  PaintBox3->Canvas->MoveTo(x1-3,y1+3);
  PaintBox3->Canvas->LineTo(x1+3,y1-3);
}


int kk;
for (k=0; k<hanysor2; k++) { sorsz=1; also=18+k*sortav+4*vtav; i=1;

  kk=k;
  if (k==6 && hanysor>8) {kk=hanysor-2;}
  if (k==7 && hanysor>8) {kk=hanysor-1;}

  while (hang[kk+1][i]!=1000) {  ker=0;b=0;
	  rit=ritm[kk+1][i]; hangm=hang[kk+1][i]; i++;
      if (hangm>50) {hangm-=100;ker=1;}
      if (hangm<-50) {hangm+=100;b=1;}
	  x1=eleje+sorsz*koz; x2=x1+6; y1=also-hangm*vtav/2-3; y2=y1+6;
      if (rit<8) {PaintBox3->Canvas->Brush->Color=clBlack;}
      if (hangm<40) {PaintBox3->Canvas->Ellipse(x1,y1,x2,y2);}
      PaintBox3->Canvas->Brush->Color=clWhite;

      if (b==1) {//b=0;
        PaintBox3->Canvas->Ellipse(x1-5,y1,x2-5,y2);
        PaintBox3->Canvas->MoveTo(x1-5,y1);
        PaintBox3->Canvas->LineTo(x1-5,y1-5);
      }
      if (ker==1) {//ker=0;
         PaintBox3->Canvas->MoveTo(x1-3-5,y1-3+3);
         PaintBox3->Canvas->LineTo(x1+3-5,y1+3+3);
         PaintBox3->Canvas->MoveTo(x1-3-5,y1+3+3);
         PaintBox3->Canvas->LineTo(x1+3-5,y1-3+3);
      }

	  if (hangm>=10 && hangm<40) {
        PaintBox3->Canvas->MoveTo(x1-5,also-5*vtav);
        PaintBox3->Canvas->LineTo(x1+5,also-5*vtav);
      }
	  if (hangm>=12 && hangm<40) {
        PaintBox3->Canvas->MoveTo(x1-5,also-6*vtav);
        PaintBox3->Canvas->LineTo(x1+5,also-6*vtav);

      }
	  if (hangm<=-2) {
        PaintBox3->Canvas->MoveTo(x1-5,also+vtav);
        PaintBox3->Canvas->LineTo(x1+5,also+vtav);
      }
	  if (hangm<=-4) {
        PaintBox3->Canvas->MoveTo(x1-5,also+2*vtav);
        PaintBox3->Canvas->LineTo(x1+5,also+2*vtav);
      }

      if (hangm==40) {
        PaintBox3->Canvas->MoveTo(x1+2,also-4*vtav);
        PaintBox3->Canvas->LineTo(x1-2,also-1*vtav);
      }

      if (hangm==41) {
        PaintBox3->Canvas->MoveTo(x1,also-4*vtav);
        PaintBox3->Canvas->LineTo(x1,also-0*vtav);
	  }

      int xp=x1+5;
      if (hangm<=4) {x1=eleje+vtav/2+sorsz*koz+2;        x2=x1; y2=y1-16; zx21=x1+5;zy21=y2+4;zx22=x2+5;zy22=zy21+4;}
      if (hangm>4)  {x1=eleje+vtav/2+sorsz*koz-3; y1+=2; x2=x1; y2=y1+20; zx21=x1+7;zy21=y2-4;zx22=x2+7;zy22=zy21-4;}


	  if (rit<=8 && hangm<40) {
        PaintBox3->Canvas->MoveTo(x1,y1);
        PaintBox3->Canvas->LineTo(x2,y2);
	  }

      PaintBox3->Canvas->Pen->Width=2;

      if (rit==1 && hangm<40) {
        PaintBox3->Canvas->MoveTo(x2,y2);
        PaintBox3->Canvas->LineTo(zx21,zy21);
        PaintBox3->Canvas->MoveTo(x2,zy21);
        PaintBox3->Canvas->LineTo(zx22,zy22);
      }

  	  if (rit==2 && hangm<40) {
        PaintBox3->Canvas->MoveTo(x2,y2);
        PaintBox3->Canvas->LineTo(zx21,zy21);
      }

	  if (rit==3 && hangm<40) {
        PaintBox3->Canvas->MoveTo(x2,y2);
        PaintBox3->Canvas->LineTo(zx21,zy21);
        PaintBox3->Canvas->Ellipse(xp+3,y1,xp+5,y1+2);
      }
	  if (rit==6 && hangm<40) {PaintBox3->Canvas->Ellipse(xp+3,y1,xp+5,y1+2);}

      if (rit==12 && hangm<40) {PaintBox3->Canvas->Ellipse(xp+3,y1,xp+5,y1+2);}

      PaintBox3->Canvas->Pen->Width=1;
	  sorsz++;
  }
}

delete ch;

}
//---------------------------------------------------------------------------
//----------- generating the MDS maps of contour and degree distribution learning vectors --------
void __fastcall TForm1::Button2Click(TObject *Sender)
{
char s[100];
int i,j,k,cikl;
float fl,hiba,krtav;

tipabr=0;

Memo1->Clear();
dimenz=NDIM;

fel=99.0/100.0; rn=1.0/100.0;

Edit4->GetTextBuf(s,sizeof(s)+1);  krtav=atof(s);  krittav=krtav;

for (i=1;i<=NVEKT;i++) { cim[i]=i;
  for (j=0;j<=dimenz;j++) {vektorok[i][j]=0;}
}
terx=20;tery=20;terz=1;terw=1; term[1]=terx;term[2]=tery;

/*
for (i=1;i<=10000;i++) {
  for (j=0;j<=dimenz;j++) {sorok[i][j]=0;}
}
*/


for (i=0;i<1000000;i++) {fogado[i]=0;}
fogptr=&fogado[0];
//npp=&s[0];

float lamb,la, nagytav,kissuly;
elso=1; //ciklusszam=2000;
//nagytav=1.7;kissuly=.2;lamb=.05;

int elofhat, altdim=2;
char *nevs=new char[100]; for (i=0;i<100;i++) {nevs[i]=0;}
dallamv=1;  dimenz=64; dimenz2=24;

for (i=1;i<=dimenz2;i++) {hangsuly[i]=0.2;}
  hangsuly[10]=1.0;
  hangsuly[4]=1.0; hangsuly[5]=1.0;
  hangsuly[11]=1.0; hangsuly[12]=1.0;
  hangsuly[16]=1.0; hangsuly[17]=1.0;
  hangsuly[18]=1.0; hangsuly[19]=1.0;
fl=0; for (i=1;i<=dimenz2;i++) {fl+=hangsuly[i];} if (fl==0) {fl=1.0;}   hahinorm=fl;


// -------------------------------- program parameters -----------------------------------------------
oszl=8;nagytav=1.8;kissuly=.01;lamb=.02;alfa=2.0*3.1415926535/4.0; nyujt=1;elrajz=1;ciklusszam=4000; szinrendszer=4;nevadas=0;
vektorszam=2527;krittav=krtav;dimenz=64;dimenz2=24;nsor=10;szinhat=2324;haskusz=-.1; alfa=2.0*3.1415926535/4.0; oszl=0.1; Memo1->Lines->Add(dimenz); //return;
Edit9->GetTextBuf(nevs,100); Memo1->Lines->Add(nevs);  //return;

//vektorszam=vektfeltoltvnf(nevs,dimenz,vektorszam); vnfnev0=nevs;
//Memo1->Lines->Add(vektorszam);  return;

//hahisuly=.0;

krittav=krtav; //dimenz=84; //abrszov="c:/eurkat/nev-47k.dat"; nevadas=12;
terx=22;tery=22;terz=1; term[1]=terx;term[2]=tery;
//terx=8;tery=8;terz=8;terw=8;
npp="c:/eurkat/mds-som.dat"; elofhat=0; utso=wbe_mds_som(npp,fogptr,dimenz,elofhat,1); Memo1->Lines->Add(utso);
npp="c:/eurkat/mds-som2.dat"; elofhat=0; utso=wbe_mds_som(npp,fogptr,dimenz2,elofhat,2); Memo1->Lines->Add(utso);
npp="c:/eurkat/mds-som-suly.dat"; wbe_mds_som(npp,fogptr,dimenz,elofhat,0); Memo1->Lines->Add(utso);    //return;

somtavnorm();


// --------- initialisation of MDS coordinates -----------------
eta=.5;   elrajz=1;
fel=9.0/10.0; rn=1.0/10.0;

randomize();
if (utofeldolg==0) {
for (i=1;i<10;i++) {term[i]=1;}
for (i=1;i<=altdim;i++) {term[i]=terx;}
for (i=1;i<=utso;i++) {
  for (j=1;j<=4;j++) {vektkoord0[i][j]=0;}
  for (j=1;j<=altdim;j++) {vektkoord0[i][j]=(float)random(term[j]*100)*.005;}
}
Memo1->Lines->Add(utso);
}

if (altdim<=3) {feltolt3();} else {feltolt4();}


fel=9.0/10.0; rn=1.0/10.0;
la=lamb*10;
//float dla=(la-lamb)/((float)ciklusszam*.75);
tanvege=0;
kezdgrad=vektgrad3d(utso,dimenz,altdim,la,nagytav,kissuly); k=0;  hiba=0;
sulypont(utso,altdim);nyujt=1.0;nagyitas=1.0;forgat(5); PaintBox1Click(Sender);
for (cikl=1;cikl<=ciklusszam;cikl++) {
  //if (cikl>ciklusszam/4 && nagytav>.1) {nagytav+=dnagytav;kissuly=.01;}
  fl=vektgrad3d(utso,dimenz,altdim,la,nagytav,kissuly);  // adjusting MDS coordinates
  hiba=fel*hiba+rn*fl;
  //la-=dla; if (la<lamb) {la=lamb;}
  if (k==10) {sulypont(utso,altdim);nyujt=1.0;nagyitas=1.0;forgat(5); PaintBox1Click(Sender);Memo1->Lines->Add(hiba);k=0;Application->ProcessMessages();if (tanvege==1) {cikl=ciklusszam;}}
  k++;
}


FILE *out;
int terkki=1;
int m,indx,dim;
if (terkki==1) {

if (hahisuly<0.1) {npp = "c:/eurkat/mds-som-dv.dat"; indx=1; dim=dimenz;}
if (hahisuly>0.5) {npp = "c:/eurkat/mds-som-fet.dat"; indx=2; dim=dimenz2;}
out=fopen(npp, "w");
fclose(out);
out = fopen( npp, "a");

int mintalalat=-10;
for (i=1;i<=utso;i++) { notael[i]=1; //talalat[i]=1; notael[i]=1;
    if (talalat[i]>=mintalalat && notael[i]==1) {
      sprintf(s, "%4d %7.3f %7.3f %7.3f %7.3f  ",i,vektkoord0[i][1],vektkoord0[i][2],vektkoord0[i][3], talalat[i]); fwrite(s,strlen(s),1,out);
      for (m=1;m<=dim;m++) {sprintf(s, "%8.3f  ", w[i][indx][m]); fwrite(s,10,1,out);
      //for (m=1;m<=dimenz2;m++) {sprintf(s, "%8.3f  ", w[i][2][m]); fwrite(s,10,1,out);
      }
      sprintf(s, "%5.1f 1000 \n",0.0); fwrite(s,12,1,out);
    }
}
fclose(out);

if (hahisuly<0.1) {
npp = "c:/eurkat/mds-som-suly-dv.dat";
out=fopen(npp, "w");
fclose(out);
out = fopen( npp, "a");

for (i=1;i<=utso;i++) { notael[i]=1; //talalat[i]=1;
    if (talalat[i]>=mintalalat*0 && notael[i]==1) {
      sprintf(s, "%4d %7.3f %7.3f %7.3f %7.3f  ",i,vektkoord0[i][1],vektkoord0[i][2],vektkoord0[i][3], talalat[i]); fwrite(s,strlen(s),1,out);
      for (m=1;m<=dimenz;m++) {
        sprintf(s, "%8.3f  ", w[i][0][m]); fwrite(s,10,1,out);
      }
      sprintf(s, "%5.1f 1000 \n",0.0); fwrite(s,12,1,out);
    }
}
fclose(out);
}

Memo1->Lines->Add(dimenz);

}


}
//---------------------------------------------------------------------------
void __fastcall TForm1::Memo1Click(TObject *Sender) // not in use
{
/*
char ch[10];
int k;

Memo1->GetSelTextBuf(ch,10); k=atoi(ch);
Edit1->Text=k;
PaintBox3Click(Sender);
*/
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Edit3DblClick(TObject *Sender)    // not in use
{
return;
char *ch=new char[10];
int i;

for (i=1;i<=NPONT;i++) {rokon[i]=0;}

Edit3->GetTextBuf(ch,10);
valvekt=atoi(ch);
Memo1->Lines->Add(" ");Memo1->Lines->Add(valvekt);
//for (i=1;i<=2500;i++) {if (abs(csop[i])==abs(csop[valvekt])) {Memo1->Lines->Add(i);rokon[i]=1;}}

PaintBox1Click(Sender);
}
//---------------------------------------------------------------------------

//----------- Finish SOC learning ------------------------------------------
void __fastcall TForm1::Button3Click(TObject *Sender)
{
int i;
char s[200];
FILE *out;
//out=fopen("c:/eurkat/vektkoord.dat","w"); fclose(out);
out=fopen("c:/eurkat/vektkoord.dat","w");

for (i=0;i<100;i++) {s[i]=0;}
for (i=1;i<=utso;i++) {
  sprintf(s,"%3.3f %3.3f %3.3f \n",vektkoord0[i][1],vektkoord0[i][2],vektkoord0[i][3]);Memo1->Lines->Add(s);fwrite(s,1,strlen(s),out);
}
fclose(out);
sulypont(utso,4);

//wki_mds_som();

tanvege=1;
//Application->Terminate(); terminate();

}
//--------------------------------------------------------------------

//---------------rotations of the MDS map ------------------------
void __fastcall TForm1::Button4Click(TObject *Sender)
{
nagyitas=1.1; forgat(5); PaintBox1Click(Sender);
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Button5Click(TObject *Sender)
{
nagyitas=1.0/1.1; forgat(5); PaintBox1Click(Sender);
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Button6Click(TObject *Sender)
{
nagyitas=1.0; forgat(1); bazforg(1); PaintBox1Click(Sender);
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Button7Click(TObject *Sender)
{
nagyitas=1.0; forgat(2); bazforg(2); PaintBox1Click(Sender);
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Button8Click(TObject *Sender)
{
nagyitas=1.0; forgat(3); bazforg(3); PaintBox1Click(Sender);
}

//---------------------------------------------------------------------------
void __fastcall TForm1::Button11Click(TObject *Sender)
{
nagyitas=1.0; forgat(4); bazforg(4); PaintBox1Click(Sender);
}
//----------------------------------------------------------------------------


//---------------------------------------------------------------------------

// ------------------ Postprocessing and moment vector generation ---------------------
void __fastcall TForm1::Button9Click(TObject *Sender)
{
int i,j;
float fl;

//char *npp= new char[100], *npp2= new char[100], *npp3= new char[100],
char *s=new char[100], *nevs=new char[100];

tipabr=1;

Memo1->Clear();
dimenz=NDIM;
elso=1;
fogptr=&fogado[0];
for (i=1;i<NVEKT;i++) {cim[i]=i;notael[i]=0;}
for (i=0;i<100;i++) {nevs[i]=0;}
utofeldolg=1;

int elofhat, krtav;

Edit4->GetTextBuf(s,sizeof(s)+1);  krtav=atof(s);

dallamv=1;
// -------------------------------- Dallam vektorokb�l sz�m�tott t�vols�g m�trix oszt�lyoz�sa -----------------------------------------------

hahisuly=.3; //----- weight of degree distribution in musical distance calculation
haskusz=2.0;  //---- threshold of musical distance

/*
vektorszam=504;krittav=krtav;dimenz2=24;nsor=1; vektorszam=vektfelhobe("c:/eurkat/DegreeDist.dat",&fogado[0],vektorszam,1,' '); oszl=1.0; nevadas=0; szinrendszer=4; alfa=2.0*3.1415926535/4.0; Memo1->Lines->Add(vektorszam); //return;
for (i=1;i<=vektorszam;i++) {for (j=1;j<=dimenz2;j++) {hanghiszt[i][j]=vektorok[i][j];}}
vektorszam=504;krittav=krtav;dimenz=64;nsor=1;szinhat=2324; vektorszam=vektfelhobe("c:/eurkat/Contour.dat",&fogado[0],vektorszam,1,' '); Memo1->Lines->Add(vektorszam); //return;
*/

oszl=1.0; nevadas=0; szinrendszer=4; alfa=2.0*3.1415926535/4.0; //return;
dimenz=24;nsor=1; vektorszam=adatbe();
for (i=1;i<=vektorszam;i++) {for (j=1;j<=dimenz;j++) {hanghiszt[i][j]=vektorok[i][j];vektorok[i][j]=0;}}
dimenz=64; dimenz2=24; nsor=10; vektorszam=adatbe();
//krittav=krtav;nagytav=1.6;kissuly=.01;ciklusszam=2000000; lamb=.05; szorz=1.0; haskusz=.6; tavk1=0.5; szinhat=2324;oszl=100;nevadas=0; alfa=2.0*3.1415926535/4.0; oszl=.01; Memo1->Lines->Add(vektorszam); //return;
//vektnorm(vektorszam,dimenz);
//return;
for (i=1;i<=vektorszam;i++) {notael[i]=1;talalat[i]=0;}

for (i=1;i<=dimenz2;i++) {hangsuly[i]=0.2;}
hangsuly[4]=1.0; hangsuly[5]=1.0;
hangsuly[11]=1.0; hangsuly[12]=1.0;
hangsuly[16]=1.0; hangsuly[17]=1.0;
hangsuly[18]=1.0; hangsuly[19]=1.0;
fl=0; for (i=1;i<=dimenz2;i++) {fl+=hangsuly[i];} if (fl==0) {fl=1.0;}   hahinorm=fl;

krittav=krtav; //dimenz=84; //abrszov="c:/eurkat/nev-47k.dat"; nevadas=12;
terx=22;tery=22;terz=1; term[1]=terx;term[2]=tery;
//terx=8;tery=8;terz=8;terw=8;
npp="c:/eurkat/mds-som-dv.dat"; elofhat=0; utso=wbe_mds_som(npp,fogptr,dimenz,elofhat,1); Memo1->Lines->Add(utso);
npp="c:/eurkat/mds-som-fet.dat"; elofhat=0; utso=wbe_mds_som(npp,fogptr,dimenz2,elofhat,2); Memo1->Lines->Add(utso);
npp="c:/eurkat/mds-som-suly-dv.dat"; wbe_mds_som(npp,fogptr,dimenz,elofhat,0); Memo1->Lines->Add(utso);    //return;


//s[0]='f';
Edit2->GetTextBuf(s,sizeof(s)+1);
if (s[0]=='d') { hahisuly=.3;   haskusz=0.5;
   npp="c:/eurkat/mds-som-fet.dat"; elofhat=0; utso=wbe_mds_som(npp,fogptr,dimenz2,elofhat,2); Memo1->Lines->Add("FET");
}
for (i=1;i<=utso;i++) {cim[i]=i; notael[i]=1;}

//hahisuly=1.0; Button2Click(Sender);  hahisuly=0.0; Button2Click(Sender); return;

//Edit8->GetTextBuf(s,sizeof(s)+1);  k=atoi(s); felhobe2("c:/eurkat/felho.dat",fogptr,k,k,0,0); szinrendszer=4; for (i=1;i<=vektorszam;i++) {cim[i]=i;}   vektorszam=vektrend(vektorszam);   osszkult=1; //return;
//for (i=1;i<=utso;i++) {cim[i]=i; talalat[i]*=notael[i]; if (notael[i]==1) {Memo1->Lines->Add(i);}}


//for (i=1;i<=dimenz;i++) {Memo1->Lines->Add(vektorok[10][i]);} return;

wki0("c:/eurkat/tipvekt.dat",utso,0);  //return;


felhoki(vektorszam,utso,0); //for (i=1;i<=vektorszam;i++) {talalat[i]=notael[i]*100;}//return;
//gerjki(haskusz);

//------- significance test ------------------------------
/*
tipszam(utso,0.1);
tproba(vektorszam,utso,2);
FILE *out2=fopen("c:/eurkat/tipatl.dat","w"); for (i=1;i<=utso;i++) {tproba0(i,vektorszam);}  fclose(out2);
inference(vektorszam);   Memo1->Lines->Add(" ");
//for (i=1;i<=utso;i++) {szil(vektorszam,i);}
//return;
*/
//----------------------------------------------------------------


//-------- generating moment vectors ---------------------------------
for (i=1;i<=utso;i++) { talalat[i]=0;
  for (j=1;j<=osszkult;j++) { tipelterj[i][j]=0;}
}

float tures;
int kult, transzp=0;  dallamv=1;

tures=1.0; haskusz=1.7; // 1.2  2.0   penta: 1.5!! 0.7!!

for (i=1;i<=utso;i++) { talalat[i]=0;
  for (j=1;j<=osszkult;j++) { tipelterj[i][j]=0;}
}

for (i=elso;i<=vektorszam;i++) {

  kult=0;
  for (k=1;k<=osszkult;k++) {
    if (hatar[k-1]<i && i<=hatar[k]) {kult=k;}
  }
  if (kult==0) {kult=1;}
  //Memo1->Lines->Add(i);
  if (kult==24 || kult==25 || kult==30 || kult==35 || kult==36 || kult==49 || kult==50) {transzp=1;} else {transzp=0;}
  //if (notael[i]==1) {
    if (kult>0) {tiptavfh(i,haskusz,tures,kult,transzp);}
  //}

}
Memo1->Lines->Add("tal�latok:");
fl=(float)vektorszam/100;   fl=.001;  fl=1.0;
k=0;for (i=1;i<=utso;i++) {notael[i]=0; cim[i]=i; talalat[i]/=fl; Memo1->Lines->Add(talalat[i]); if (talalat[i]>=0.9) {k++;notael[i]=1;}}         // talalat=20.0, 1.0
Memo1->Lines->Add(k);

FILE *out;
out=fopen("c:/eurkat/tipelterj.dat","w");
for (i=1;i<=utso;i++) {
  for (j=1;j<=osszkult;j++) {
     for (k=0;k<100;k++) {s[k]=0;} sprintf(s,"%6.3f ", tipelterj[i][j]); fwrite(s,strlen(s),1,out); //fwrite(" \n",2,1,out);
  }
  for (k=0;k<100;k++) {s[k]=0;} sprintf(s," \n");fwrite(s,strlen(s),1,out);
}
fclose(out);

out=fopen("c:/eurkat/tipelterj-tr.dat","w");
for (i=1;i<=osszkult;i++) {
  for (j=1;j<=utso;j++) {
     for (k=0;k<100;k++) {s[k]=0;} sprintf(s,"%6.3f ", tipelterj[j][i]); fwrite(s,strlen(s),1,out); //fwrite(" \n",2,1,out);
  }
  for (k=0;k<100;k++) {s[k]=0;} sprintf(s," \n");fwrite(s,strlen(s),1,out);
}
fclose(out);

Memo1->Lines->Add(osszkult);
//------------------------------------------------------------------------------------

//----------- Map of central vectors ----------------------------------
feltolt3();  somtavnorm();
sulypont(utso,3);nyujt=1.0;nagyitas=1.0; forgat(5); szinhat=utso; PaintBox1Click(Sender);
//PaintBox2Click(Sender);


}
//---------------------------------------------------------------------------

//--------------- SOC algorithm -------------------------------------------------
void __fastcall TForm1::Button10Click(TObject *Sender)
{
char s[1000], *nevs = new char[100];
int i,j,k,m,cikl;
int hat1, hat2, maxtal, altdim, vegso;
float fl,hiba,krtav, hahisuly0;

tipabr=1; elrajz=1;

Memo1->Clear();
dimenz=NDIM;

float fel=999.0/1000.0; float rn=1.0/1000.0;

Edit4->GetTextBuf(s,sizeof(s)+1);  krtav=atof(s);  krittav=krtav;

for (i=1;i<=NVEKT;i++) { cim[i]=i; rokon[i]=0; notael[i]=0;
  for (j=0;j<=dimenz;j++) {vektorok[i][j]=0;}
}

for (i=0;i<1000000;i++) {fogado[i]=0;}
fogptr=&fogado[0];

//npp=&s[0];

float tavk,tavk1,szorz;
float fel3=999.0/1000.0, rn3=1.0/1000.0;
float lamb,la, dla, nagytav,kissuly;
elso=1;

//Edit4->GetTextBuf(s,sizeof(s)+1);  krtav=atof(s);

dallamv=1;    utofeldolg=0;  hahisuly=0.3;


// -------------------------------- Load Degree distribution and Contour vectors -----------------------------------------------
dimenz=24;nsor=1; vektorszam=adatbe();
for (i=1;i<=vektorszam;i++) {for (j=1;j<=dimenz;j++) {hanghiszt[i][j]=vektorok[i][j];vektorok[i][j]=0;}}
dimenz=64; dimenz2=24; nsor=10; vektorszam=adatbe();
krittav=krtav;nagytav=1.6;kissuly=.01;ciklusszam=2000000; lamb=.05; szorz=1.0; haskusz=.6; tavk1=0.5; szinhat=2324;oszl=100;nevadas=0; alfa=2.0*3.1415926535/4.0; oszl=.01; Memo1->Lines->Add(vektorszam); //return;
//vektnorm(vektorszam,dimenz);
//return;
for (i=1;i<=vektorszam;i++) {notael[i]=1;}
//return;


altdim=2; terx=25;tery=25;terz=1;terw=1; tavk=.5;
//altdim=3; terx=8;tery=8;terz=8;terw=1; tavk=1.02;
//altdim=4; terx=5;tery=5;terz=5;terw=4; tavk=.02;


for (i=1;i<10;i++) {term[i]=1;}
for (i=1;i<=altdim;i++) {term[i]=terx;}

if (utofeldolg==0) {Edit10->GetTextBuf(s,sizeof(s)+1);  utso=atoi(s); Edit11->GetTextBuf(s,sizeof(s)+1);  vegso=atoi(s);}

if (utofeldolg==0) {
  randomize();
  for (i=1;i<=utso;i++) {k=random(vektorszam-1)+1;   //if (i==1) {k=222;}
    for (j=1;j<=dimenz;j++) {w[i][1][j]=vektorok[k][j];w[i][0][j]=1.0;}
    for (j=1;j<=dimenz2;j++) {w[i][2][j]=hanghiszt[k][j];}
  }
  for (i=1;i<=dimenz2;i++) {hangsuly[i]=0.2;}
  hangsuly[4]=1.0; hangsuly[5]=1.0;
  hangsuly[11]=1.0; hangsuly[12]=1.0;
  hangsuly[16]=1.0; hangsuly[17]=1.0;
  hangsuly[18]=1.0; hangsuly[19]=1.0;
  fl=0; for (i=1;i<=dimenz2;i++) {fl+=hangsuly[i];} if (fl==0) {fl=1.0;}   hahinorm=fl;

  for (i=1;i<=utso;i++) {
    for (j=1;j<5;j++) {vektkoord0[i][j]=0;}
    for (j=1;j<=altdim;j++) {vektkoord0[i][j]=(float)random(term[j]*1)*.5;}
    //r1=random(terx*100); r2=random(tery*100); r3=random(terz*100); r4=random(terw*100);
    //vektkoord0[m][1]=(float)r1*0.005; vektkoord0[m][2]=(float)r2*0.005; vektkoord0[m][3]=r3*0.005;  vektkoord0[m][4]=r4*0.005;
    //vektkoord[m][1]=r1; vektkoord[m][2]=r2; vektkoord[m][3]=r3; vektkoord[m][4]=r4;
  }
  Memo1->Lines->Add(utso);

}

elrajz=1;

somtavnorm();
if (altdim<=3) {feltolt3();} else {feltolt4();}

Memo1->Lines->Add("init k�sz");  //return;

if (utofeldolg==0) {

// MDS mapping of initial learning vectors -----------
//float dnagytav=(.2-nagytav)/((float)ciklusszam*.75);   dnagytav=0;
//fel=9.0/10.0; rn=1.0/10.0;
la=.1; dla=(la-0.005)/((float)ciklusszam*.75);
tanvege=0;
kezdgrad=vektgrad3d(utso,dimenz,altdim,la,nagytav,kissuly); k=0;  hiba=0;
for (cikl=1;cikl<=4000;cikl++) {
    //if (cikl>ciklusszam/4 && nagytav>.1) {nagytav+=dnagytav;kissuly=.01;}
    fl=vektgrad3d(utso,dimenz,altdim,la,nagytav,kissuly); // adjusting MDS coordinates
    hiba=fel*hiba+rn*fl;
    la-=dla; if (la<lamb) {la=0.005;}   // adjusting step size
    if (k==100) {sulypont(utso,altdim);nyujt=1.0;nagyitas=1.0;forgat(5); PaintBox1Click(Sender);Memo1->Lines->Add(hiba);k=0;Application->ProcessMessages();if (tanvege==1) {cikl=15000;}}
    k++;
}
sulypont(utso,altdim);

//hat1=ciklusszam*1/2; hat2=ciklusszam*3/4;
//hat1=ciklusszam*3/5; hat2=ciklusszam*4/5;
//hat1=ciklusszam; hat2=ciklusszam;
hat1=ciklusszam*3/100; hat2=ciklusszam*20/100;  //ciklusszam*2/10;

float eta0; eta=0.01;
//float dtavk=(tavk-tavk1)/(float)hat1*10.0;
//dtavk1=(.501-tavk1)/(float)hat1*1.0;
la=lamb; dla=(lamb*szorz-la)/((float)hat1/200.0);  dmintav=1;  dtipsz=1;

// -------------- SOC learning ---------------------

randomize();  k=0; j=0; m=0; elrajz=1; hiba=0;  maxtal=0;   //dimenz=64;
for (cikl=1;cikl<=ciklusszam;cikl++) {    // ciklussz�m: cikle number
  i=random(vektorszam); if (i==0) {i=1;}   // random choice of trainig vectors  (Contor and Degree distribution
  if (notael[i]==1) {
    fl=keresfh(i); // finding the most similar learning vectors
    eta0=eta;
    //eta0=1.0/(exp(-0.1*talalat[minsorszam])+.1)*eta0;
    //eta0=10.0/(pow(talalat[minsorszam],.99)+1)*eta0;

    if (cikl<=hat1) {adaptfhtop(minsorszam,i,tavk,tavk1,eta0,altdim);}   // adjusting the learning vectors

    if (hat1<cikl && cikl<=hat2 && fl<300*haskusz) {adaptfhtop(minsorszam,i,tavk,tavk1,eta0*10,altdim);}
    if (hat2<cikl && fl<300.0*haskusz) {adaptfhtop(minsorszam,i,tavk,tavk1,eta0*10,altdim);}
    hiba=fel*hiba+rn*fl;  //if (hiba>5.0) {Memo1->Lines->Add(i);}
    talalat[minsorszam]=talalat[minsorszam]*fel3+10.0*rn3;
    eta=.001/(1.0+exp(-2.0*(hiba-.2)))+.0001;  // adjusting step size

    m++;
    if (m==100000 && utso<vegso) {
      if (cikl>hat1 && cikl<hat2) {utso=tipszam(utso,.3); feltolt3(); Memo1->Lines->Add(utso);}   // increasing the number of learning vectors if necessary
      if (cikl>=hat2) {utso=tipszam(utso,.3); feltolt3(); Memo1->Lines->Add(utso); Memo1->Lines->Add(" ");}   // increasing the number of learning vectors if necessary
      //if (utso>=80 && dmintav<-0.99) {cikl=ciklusszam-70000;}
      if (dtipsz<0.001 && hat2*2<cikl) {cikl=ciklusszam-70000;}
      Memo1->Lines->Add(" ");
      m=0;
    }

    j++;
    if (talalat[minsorszam]>maxtal) {maxtal=talalat[minsorszam];valvektor=minsorszam;}
    if (j==1000) {
      sulypont(utso,altdim);nyujt=1.0;nagyitas=1.0;forgat(5); PaintBox1Click(Sender);Application->ProcessMessages();if (tanvege==1) {cikl=ciklusszam;}
      //sprintf(s,"%.3f %.3f %.3f  %.3f",hiba,eta*100,tavk,tavk1); Memo1->Lines->Add(s);
      j=0;
      PaintBox3->Canvas->LineTo((int)(cikl*.0001+.5),(int)(hiba*40.0+.5));  // learning curve
      PaintBox2Click(Sender);  PaintBox4Click(Sender);
    }

    k++;
    if (k>=20) {  k=0;
      somtavnorm();
      la+=dla; if (la>lamb*szorz) {la=lamb*szorz;}  if (cikl>hat1) {la=lamb;}
      vektgrad3d(utso,dimenz,altdim,la,nagytav,kissuly);
      vektgrad3d(utso,dimenz,altdim,la,nagytav,kissuly);
    }

  }
}

} // if utofeldolg==0


somtavnorm();

for (i=1;i<=utso;i++) {talalat[i]=0;}

for (i=1;i<=vektorszam;i++) {fl=keresfh(i);talalat[minsorszam]+=1; hiba+=fl;}
//hiba/=(float)vektorszam;
sprintf(s,"atl. hiba: %.3f",hiba); Memo1->Lines->Add(hiba);


// ********** Final MDS mapping of learning vectors ***********

if (utofeldolg==1) {

ciklusszam=20000;
//float dnagytav=(.2-nagytav)/((float)ciklusszam*.75);   dnagytav=0;
lamb=.005;
fel=9.0/10.0; rn=1.0/10.0;
la=lamb*1; dla=(la-lamb)/((float)ciklusszam*.75);
tanvege=0;
kezdgrad=vektgrad3d(utso,dimenz,altdim,la,nagytav,kissuly); k=0;  hiba=0;
for (cikl=1;cikl<=ciklusszam;cikl++) {
  //if (cikl>ciklusszam/4 && nagytav>.1) {nagytav+=dnagytav;kissuly=.01;}
  fl=vektgrad3d(utso,dimenz,altdim,la,nagytav,kissuly);
  hiba=fel*hiba+rn*fl;
  la-=dla; if (la<lamb) {la=lamb;}
  if (k==10) {sulypont(utso,altdim);nagyitas=1.0;forgat(5); PaintBox1Click(Sender);Memo1->Lines->Add(hiba);k=0;Application->ProcessMessages();if (tanvege==1) {cikl=ciklusszam;}}
  k++;
}

for (cikl=1;cikl<=300;cikl++) {
  //if (cikl>ciklusszam/2 && nagytav>.01) {nagytav+=dnagytav;kissuly=.01;}
  fl=vektgrad3d(utso,dimenz,altdim,la,nagytav,kissuly);
  hiba=fel*hiba+rn*fl;
  //la-=dla; if (la<lamb) {la=lamb;}
  if (k==10) {sulypont(utso,altdim);nagyitas=1.0;forgat(5); PaintBox1Click(Sender);Memo1->Lines->Add(fl);k=0;Application->ProcessMessages();if (tanvege==1) {cikl=ciklusszam;}}
  k++;
}
sulypont(utso,altdim);

}

for (i=0;i<1000;i++) {s[i]=0;}

wki_mds_som();   //kategki_soc();
hahisuly=1.0; Button2Click(Sender);  hahisuly=0.0; Button2Click(Sender);

utofeldolg=0;

}
//---------------------------------------------------------------------------


void __fastcall TForm1::PaintBox1DblClick(TObject *Sender)
{
tisztazas(5);
nyujt=1.0;nagyitas=1.0;forgat(5);
PaintBox1Click(Sender);
}

//---------------------------------------------------------------------------
void __fastcall TForm1::PaintBox3DblClick(TObject *Sender)
{
return;

}
//---------------------------------------------------------------------------
//------------ minimal spanning tree ----------------------------
void __fastcall TForm1::FaClick(TObject *Sender)
{
int i,j;
char ch[20];
float tkusz;

Edit7->GetTextBuf(ch, sizeof(ch)+1); tkusz=atof(ch);

for (i=1;i<=utso;i++) {
  for (j=1;j<=utso;j++) {feltetel[i][j]=0;}
}

kruskal(utso,tkusz*nyujt);
PaintBox1Click(Sender);



/*
for (i=1;i<=utso;i++) {
  for (j=1;j<=utso;j++) {
    if (feltetel[i][j]==0) {vekttav[i][j]*=1.5; vekttav[j][i]=vekttav[i][j];}
    //else { Memo1->Lines->Add("szor");}
  }
}
//tavmatrmod(utso);
*/

}
//---------------------------------------------------------------------------

// ------------ Generation Contour and degree distribution vectors from notation codes --------------
void __fastcall TForm1::Button12Click(TObject *Sender)
{

int i,j;
float fl;

char *s=new char[100], *nevs=new char[100];

tipabr=1;

Memo1->Clear();
dimenz=NDIM;
elso=1;
fogptr=&fogado[0];
for (i=1;i<NVEKT;i++) {cim[i]=i;notael[i]=0;}
for (i=0;i<100;i++) {nevs[i]=0;}
utofeldolg=1;

int elofhat, krtav;

Edit4->GetTextBuf(s,sizeof(s)+1);  krtav=atof(s);

dallamv=1;
// -------------------------------- Input notation codes and generate contour and degree distribution vectors -----------------------------------------------

vektorszam=2527;krittav=krtav;dimenz=64;dimenz2=24;nsor=10;szinhat=2324;haskusz=2.0; hahisuly=.3; alfa=2.0*3.1415926535/4.0;oszl=1; szinrendszer=4; oszl=0.0051;  nevadas=0;
Edit9->GetTextBuf(nevs,100); Memo1->Lines->Add(nevs);  vnfnev0=nevs;
vektorszam=vektfeltoltvnf(nevs,dimenz,vektorszam);  //Memo1->Lines->Add(vektorszam);return;
for (i=1;i<=vektorszam;i++) {notael[i]=1;}

// output  Contour.dat and DegreDist.dat files in the c:/eurkat directory ------------------
vektki("c:/eurkat/Contour.dat", vektorszam); return;

}
//---------------------------------------------------------------------------
//-------- Represent degree distribution type vectors pointed by the serial number in Edit1 ------------
void __fastcall TForm1::PaintBox4Click(TObject *Sender)
{
int xmeret,ymeret;
int k, x1,y1,sorsz;
float fl1, fl2;


/*Edit3->GetTextBuf(ch, sizeof(ch)+1); sorsz=atoi(ch);*/

//if (x2==0) {x2=mx;y2=my;sorsz=1;}

ymeret=PaintBox4->Height-1;
xmeret=PaintBox4->Width-1;

fl1=(float)xmeret/(float)dimenz2; fl2=(float)ymeret/40.0;  fl2*=lept;

PaintBox4->Canvas->Brush->Color=clWhite;

PaintBox4->Canvas->Rectangle(0,0,xmeret,ymeret);




PaintBox4->Canvas->MoveTo(0,ymeret/2);
x1=(int)((float)dimenz2*fl1+.5);
PaintBox4->Canvas->LineTo(x1,ymeret/2);

PaintBox4->Canvas->Pen->Color=clBlack; PaintBox4->Canvas->Pen->Width=2;

tipabr=1;

if (tipabr==1) {
sorsz=2;
for (k=1;k<=dimenz2;k++) {
  x1=(int)((float)k*fl1+.5);
  y1=(int)((w[valvektor][sorsz][k])*fl2*0.5+.5);
  PaintBox4->Canvas->LineTo(x1,ymeret/2-y1);
}

PaintBox4->Canvas->Pen->Width=1;
}

PaintBox4->Canvas->Pen->Color=clRed;
PaintBox4->Canvas->MoveTo(0,ymeret/2);
sorsz=2;
for (k=1;k<=dimenz2;k++) {
  x1=(int)((float)k*fl1+.5);
  y1=(int)(hangsuly[k]*fl2*10.1+.5);
  PaintBox4->Canvas->MoveTo(x1,ymeret/2+y1);
  PaintBox4->Canvas->LineTo(x1,ymeret/2-y1);
}

PaintBox4->Canvas->Pen->Color=clGreen;
PaintBox4->Canvas->Pen->Width=3;
  x1=(int)((float)8*fl1+.5);
  y1=(int)(hangsuly[8]*fl2*10.1+.5);
  PaintBox4->Canvas->MoveTo(x1,ymeret/2+y1);
  PaintBox4->Canvas->LineTo(x1,ymeret/2-y1);

  x1=(int)((float)13*fl1+.5);
  y1=(int)(hangsuly[8]*fl2*10.1+.5);
  PaintBox4->Canvas->MoveTo(x1,ymeret/2+y1);
  PaintBox4->Canvas->LineTo(x1,ymeret/2-y1);

  x1=(int)((float)15*fl1+.5);
  y1=(int)(hangsuly[8]*fl2*10.1+.5);
  PaintBox4->Canvas->MoveTo(x1,ymeret/2+y1);
  PaintBox4->Canvas->LineTo(x1,ymeret/2-y1);

  x1=(int)((float)20*fl1+.5);
  y1=(int)(hangsuly[8]*fl2*10.1+.5);
  PaintBox4->Canvas->MoveTo(x1,ymeret/2+y1);
  PaintBox4->Canvas->LineTo(x1,ymeret/2-y1);
PaintBox4->Canvas->Pen->Width=1;
PaintBox2->Canvas->Pen->Color=clBlack;

PaintBox4->Canvas->Pen->Color=clGreen;
PaintBox2->Canvas->Pen->Color=clBlack; PaintBox2->Canvas->Pen->Width=1;
int cc;
for (i=1;i<=vektorszam;i++) {cc=cim[i]; //cc=i;
  if (rokon[cc]==1) {//j=szotag[cc];
    PaintBox4->Canvas->MoveTo(0,ymeret/2);
    for (k=1;k<=dimenz2;k++) {
      x1=(int)((float)k*fl1+.5);
      y1=(int)((hanghiszt[cc][k])*fl2*0.5+.5);
      PaintBox4->Canvas->LineTo(x1,ymeret/2-y1);  //Memo1->Lines->Add(vektorok[i][k]);
    }
  }
}


}
//---------------------------------------------------------------------------

void __fastcall TForm1::Edit1DblClick(TObject *Sender)     // nbot in use
{
return;
char s[10];
int k,i;
float fl;
float rtavkusz=haskusz; //srsz=1318;

Edit1->GetTextBuf(s,9); int srsz=atoi(s);
int sorsz[3]; sorsz[1]=srsz; sorsz[2]=0;

// int sorsz[]={48,69,99,120,125,151,213,233,270,317,357,363,375,398,425,450,517,522,528,529,533,569,574,597,614,0}; //1
//int sorsz[]={270,363,375,425,517,528,533,569,0}; //1

//int sorsz[]={16,43,78,97,107,121,184,324,335,362,432,487,0}; //2
//int sorsz[]={43,362,401,403,503,0};                          //3
//int sorsz[]={63,80,136,174,214,292,380,422,455,474,585,0}; // 4
//int sorsz[]={167,0};                                         //5
//int sorsz[]={126,249,277,282,416,440,448,467,608,0};      // 6
//int sorsz[]={87,115,133,208,284,442,489,539,549,0};       // 7

// int sorsz[]={3,48,83,101,118,131,136,146,153,162,166,174,196,206,211,214,216,218,229,233,234,242,249,280,282,310,314,343,353,422,432,448,467,474,516,519,610,0}; //8
//int sorsz[]={55,118,277,282,310,343,0};                     // 8

//int sorsz[]={10,61,68,125,185,257,421,450,465,469,526,533,539,569,576,587,595,0}; //9
//int sorsz[]={ 125,185,257,316,421,436,489,526,530,586,587,597,0}; // 9
//int sorsz[]={47,59,60,84,105,168,170,176,514,589,0};           //10


//int sorsz[]={103,295,406,500,507,529,547,561,607,615,0};  // 11
//int sorsz[]={40,101,140,146,196,211,218,239,392,423,0}; // 12

//int sorsz[]={10,199,209,233,251,262,389,436,440,464,513,0}; // 14
//int sorsz[]={104,180,259,388,0};                           // 15

//int sorsz[]={11,23,34,38,71,130,243,302,345,365,0};       // 17
//int sorsz[]={52,56,75,90,142,177,193,307,434,454,484,504,552,0};  // 18
//int sorsz[]={ 120,125,151,317,357,363,398,425,575,0};       // 19

//int sorsz[]={10,455,57,548,432,595,0};                      // 20
//int sorsz[]={10,57,548,595,0};                      // 20
//int sorsz[]={ 5,20,70,205,234,277,301,335,403,581,0};       //21
//int sorsz[]={20,301,335,581,0};                                 //21

//int sorsz[]={41,48,69,103,126,151,153,169,206,240,282,337,373,389,406,416,467,473,495,507,513,520,522,528,529,563,574,575,608,0}; //22
//int sorsz[]={199,240,337,473,495,513,563,0}; //22
//int sorsz[]={36,68,107,114,334,403,472,487,586,0};         // 23

//int sorsz[]={3,34,55,130,172,204,206,249,261,310,401,417,0}; // 24
//int sorsz[]={ 20,36,43,61,68,343,421,0};          // 25

//int sorsz[]={74,270,343,351,385,415,450,468,574,597,614,0};   // 27
//int sorsz[]={13,16,43,114,121,143,263,324,472,487,527,557,0}; // 28

//int sorsz[]={5,16,40,80,83,101,106,131,135,140,146,159,162,166,196,204,211,214,216,219,227,229,234,239,242,274,280,292,314,334,338,355,392,399,401,422,423,516,585,0}; // 29
//int sorsz[]={106,204,205,214,216,229,242,292,401,403,585,0};  // 29

//int sorsz[]={118,157,169,214,220,233,273,479,0};        //30
//int sorsz[]={235,474,542,575,199,233,0};                       // 32
//int sorsz[]={7,28,31,42,56,112,122,164,190,253,307,382,397,407,414,434,446,449,454,465,477,484,504,505,532,544,587,592,617,0}; //34
//int sorsz[]={28,31,112,164,190,253,307,407,434,446,449,454,465,477,484,505,532,544,592,617,0}; // 34




//int sorsz[]={8,9,13,16,23,26,28,57,0};   // regmag-68 1
//int sorsz[]={2,5,21,32,54,68,0};       // regmag-68  2
//int sorsz[]={7,10,12,24,46,52,58,61,0};       //regmag-68 3
//int sorsz[]={27,38,39,48,0};                  // regmag-68 4
//int sorsz[]={4,15,18,19,31,33,37,43,50,62,64,65,0};  // regmag-68 5
/*
  41
  55  
*/

//k=1;while(sorsz[k]!=0) {Memo1->Lines->Add(sorsz[k++]);} return;


for (k=1;k<=vektorszam;k++) {rokon[k]=0;talalat[k]=0;}
i=1;
while (sorsz[i]!=0) { srsz=sorsz[i++];   Memo1->Lines->Add(srsz);
  for (k=1;k<=vektorszam;k++) { rokon[k]=0;
    fl=tiptavmerfh(k,srsz,0);
    if (fl<rtavkusz && talalat[k]==0) {rokon[k]=1;talalat[k]=1;Memo1->Lines->Add(rokon[k]);}
  }

  Edit9->GetTextBuf(nevs,100); Memo1->Lines->Add(nevs);
  katalki(vnfnev0,vektorszam);
}
for (i=1;i<=vektorszam;i++) {rokon[i]=talalat[i];}
//katalki(vnfnev0,vektorszam);
valvektor=srsz; PaintBox2Click(Sender);  PaintBox4Click(Sender);

}
//---------------------------------------------------------------------------

void __fastcall TForm1::Edit6DblClick(TObject *Sender)    // not in use
{
return;
int i,sorsz, nevhossz,dirhossz;
char *nev=new char[100],*nev1=new char[100],*nev2=new char[100], *nev3=new char[100],*ptr;
char ch[20];

for (i=0;i<100;i++) {nev[i]=0;nev1[i]=0;nev2[i]=0;nev3[i]=0;}

sorsz=kottanota;

for (i=0;i<20;i++) {ch[i]=0;} itoa(sorsz,ch,10);

//if (sorsz==0) {sorsz=1;} kottanota=sorsz;
hatar1=100000; dimvet=dimenz;
char *vnfnev= new char[200]; vnfnev=vnfnev0;
hanysor=vnftransz(vnfnev,sorsz);


Edit6->GetTextBuf(nev,30);

i=49; while ((nev[i]!='/') && 0<=i) {i--;} i++;
ptr=&nev[i];
i=0; while((int)*ptr!=0) {nev1[i]=*ptr++;i++;} nevhossz=i;
nev2="c:/eurkat/kottagyujto/";
Memo1->Lines->Add(nev2);

ptr=&nev2[0]; i=0; while ((int)*ptr!=0 && i<50) {ptr++;i++;} dirhossz=i;

for (i=0;i<dirhossz;i++) {nev3[i]=nev2[i];}
for (i=0;i<nevhossz;i++) {nev3[i+dirhossz]=nev1[i];}

if (nev3[dirhossz+nevhossz-4]=='.') {
  nev3[dirhossz+nevhossz-3]='p';
  nev3[dirhossz+nevhossz-2]='s';
  nev3[dirhossz+nevhossz-1]=0;
}
else {
  nev3[dirhossz+nevhossz+0]='.';
  nev3[dirhossz+nevhossz+1]='p';
  nev3[dirhossz+nevhossz+2]='s';
  nev3[dirhossz+nevhossz+3]=0;
}
Memo1->Lines->Add(nev3);



//nev3="c:/eurkat/kottagyujto/proba.ps";
//if (i>=50) {pt2="c:/eurkat/kottagyujto/kotta.ps";Memo1->Lines->Add("hibas kottanev");}
//int X0=99, Y0=199, X1=400, Y1=400;
//postkerkot(X0,Y0,X1,Y1,.6,&ch[0],nev3);
//postkotta(X0,Y0,X1,Y1,.6,nev3,hanysor);

//Form1->Memo1->Lines->Add("hanysor:");
//Form1->Memo1->Lines->Add(hanysor);

delete nev1,nev2,nev;


}
//---------------------------------------------------------------------------

