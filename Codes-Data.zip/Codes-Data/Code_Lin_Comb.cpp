#include <time.h>
#include <io.h>
#include <stdio.h>
#include <alloc.h>
#include <fcntl.h>
#include <stdlib.h>
#include <math.h>
#include <float.h>
#include <conio.h>
#include <string.h>
#include <except.h>

#define NKOMP 900
#define NDIM  1000
//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "vektorkever.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"

float vektorok[NKOMP+1][NDIM+1], vektorok2[NKOMP+1][NDIM+1], vektorok0[NKOMP+1][NDIM+1], a[NKOMP+1];
char *fog =new char[10000000];
int dimenz, utso,utso2, nbaz, vektel[NKOMP+1], tipel[NKOMP+1], cim[NKOMP+1];


TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
        : TForm(Owner)
{
}

// file input function --------------------
int vektfelhobe(char *nevp, char *fogp, int vektszam, int kezdes, char szun)
{
int i,szaml, poz, dim,indx;
FILE *in;
char str[20], *ptr, *sptr, ch;
float fl;
int hossz;

in=fopen(nevp, "r");
indx=_fileno(in); hossz=filelength(indx);
fread(fogp, 1, hossz, in);
fclose(in);

//vektszam=hossz/296;
//vektszam=34;
//ptr=fogp; i=0; while (*ptr!=10) {ptr++;i++;} vektszam=hossz/i;


ptr=fogp; int valkar=0; szaml=0;
for (i=1;i<=hossz;i++) {
  if (*ptr!=' ' && *ptr!=10) {valkar++;}
  if (*ptr==10 && 0<valkar) {szaml++;valkar=0;}
  ptr++;
}
vektszam=szaml-0;


ptr=fogp;  sptr=&str[0]; szaml=kezdes-1; poz=1;

while (szaml!=vektszam+kezdes-1) { ch=0; //Form1->Memo1->Lines->Add(szaml);
	for (i=0; i<20; i++) { str[i]=0;}
    while (*ptr==szun) {ptr++;}
	i=0; while (ch!=szun && ch!=10 && i<20) {
      ch=*ptr++;
      str[i++]=ch;
    } //ptr++;
    fl=atof(sptr);  //fl=1000;
	if (fl!=1000) {vektorok[szaml+1][poz]=1.0*fl;poz++;}
	//else {szaml++; dim=poz-1; poz=1;}
    if (ch==10) {szaml++; dim=poz-1; poz=1;}
}

return(szaml);
}

//------- Linear combination iterative algorithm -----------------------
float amatr[1000][100];
float linkomb(int ksorsz)
{
int i,j,k,m,ciklusszam, cikl;
float fl,lamb, norm, sum, hiba, hiba0, y[NDIM+1], kim[NDIM+1];
FILE *out;
char *s=new char[20];

lamb=0.05; ciklusszam=50000;
randomize();
for (i=1;i<=utso2;i++) {fl=(float)random(1000)/10000.0; a[i]=0.0;}

for (cikl=1;cikl<=ciklusszam;cikl++) {   //Form1->Memo1->Lines->Add(cikl);

hiba=0; hiba0=0;
for (k=1;k<=dimenz;k++) {hiba0+=vektorok[ksorsz][k]*vektorok[ksorsz][k];}
for (k=1;k<=dimenz;k++) {
  fl=0; for (i=1;i<=utso2;i++) {fl+=a[i]*vektorok2[i][k];}
  y[k]=vektorok[ksorsz][k]-fl;  //Memo1->Lines->Add(y[k]);
  kim[k]=fl;
  hiba+=y[k]*y[k];
  //hiba0+=vektorok[ksorsz][k]*vektorok[ksorsz][k];
  //hiba0+=vektorok[ksorsz][k];
}
if (hiba0==0) {hiba0=1.0;}
hiba=sqrt(hiba/hiba0);


float maxa=0;
norm=0; sum=0; for (m=1;m<=utso2;m++) {norm+=a[m]*a[m];sum+=fabs(a[i]); if (maxa<a[m]) {maxa=a[m];}}

for (m=1;m<=utso2;m++) {
  fl=0; for (k=1;k<=dimenz;k++) {fl+=y[k]*vektorok2[m][k];}  fl*=-2.0;
  a[m]=a[m]-fl*lamb-(norm-1.0)*a[m]*0.0;  if (a[m]<0.0) {a[m]*=-1.0;}
  //if (ciklusszam/2<cikl && a[m]<maxa*0.2) {a[m]*=0.9;}
  //a[m]=a[m]-fl*lamb-(sum-1.0)*0.00;  if (a[m]<0.0) {a[m]*=-1.0;}
  //a[m]-=(norm-1.0)*a[m]*0.001;
   //Form1->Memo1->Lines->Add(a[10]);
}

} // cikl


a[0]=hiba;
out=fopen("c:/eurkat/linkomb.dat","a");
for (i=0;i<=utso2;i++) {amatr[ksorsz][i]=a[i]; sprintf(s,"  %-6.3f", a[i]); fwrite(s, strlen(s),1,out);}
//for (i=1;i<=dimenz;i++) {sprintf(s,"  %.3f", kim[i]); fwrite(s, strlen(s),1,out);}
sprintf(s," \n"); fwrite(s, strlen(s),1,out);
fclose(out);

out=fopen("c:/eurkat/linkomb-kim.dat","a");
for (i=1;i<=dimenz;i++) {sprintf(s,"  %-6.3f", kim[i]); fwrite(s, strlen(s),1,out);}
//for (i=1;i<=dimenz;i++) {sprintf(s,"  %.3f", kim[i]); fwrite(s, strlen(s),1,out);}
sprintf(s," \n"); fwrite(s, strlen(s),1,out);
fclose(out);

out=fopen("c:/eurkat/linkomb-hiba.dat","a");
for (i=1;i<=dimenz;i++) {sprintf(s,"  %-6.3f", vektorok[ksorsz][i]-kim[i]); fwrite(s, strlen(s),1,out);}
//for (i=1;i<=dimenz;i++) {sprintf(s,"  %.3f", kim[i]); fwrite(s, strlen(s),1,out);}
sprintf(s," \n"); fwrite(s, strlen(s),1,out);
fclose(out);

return(hiba);
}




//---------------------------------------------------------------------------

void __fastcall TForm1::Memo1Click(TObject *Sender)  // not used
{
return;
int i,j,k,m,cikl;
float fl,fl1;

/*
int i,j,k,m, cikl;
float fl,fl1,maxhib;
*/
dimenz=847; //847; 338;     202, 70

utso=0;

fog=&fog[0];
utso2=vektfelhobe("c:/eurkat/pca+sulyp.dat", fog, 100,1,' '); Memo1->Lines->Add(utso2); //return;  // korrbaz.dat;    pca+sulyp.dat;
for (i=1;i<=utso2;i++) {for (j=1;j<=dimenz;j++) {vektorok0[i][j]=fabs(vektorok[i][j])-vektorok[utso2][j]*0;}}
utso2--;
// ------------ norm�l�s -------------------------------------

for (i=1;i<=utso2;i++) {  fl=0;
  for (j=1;j<=dimenz;j++) {
    fl+=vektorok0[i][j];       // eloszl�s
  }
  if (fabs(fl)<0.0001) {fl=1.0;}
  for (j=1;j<=dimenz;j++) {vektorok0[i][j]/=fl;vektorok2[i][j]=vektorok0[i][j];}
}

for (i=1;i<=utso2;i++) {vektel[i]=1;}

//utso2=vektval(utso2,dimenz); Memo1->Lines->Add(utso2); //return;


//utso=teszt(6,utso2,dimenz);
/*
fog=&fog[0];
utso=vektfelhobe("c:/eurkat/hcs-eloszl.dat", fog, 100,1,' '); Memo1->Lines->Add(utso); //return;
*/

for (i=1;i<=utso;i++) {  fl=0; vektel[i]=1;
  for (j=1;j<=dimenz;j++) {
    fl+=vektorok[i][j];       // eloszl�s
  }
  if (fabs(fl)<0.0001) {fl=1.0;}
  for (j=1;j<=dimenz;j++) {vektorok[i][j]/=fl;}
}


//-----------------------------------------------------------------------------------------------------------------------


// linkomb. b�zis kiv�laszt�s ----------------------------------------------
/*
for (i=1;i<=utso2;i++) {vektel[i]=0;}
vektel[1]=1; vektel[4]=1; vektel[6]=1; vektel[8]=1; vektel[10]=1; vektel[17]=1; vektel[27]=1; vektel[34]=1; vektel[50]=1; vektel[54]=1;
utso2=vektrend(utso2,dimenz); Memo1->Lines->Add(utso2); //return;
*/
//-----------------------------------------------------------------------------------------------------------------





FILE *out;
out=fopen("c:/eurkat/linkomb.dat","w"); fclose(out);
out=fopen("c:/eurkat/linkomb-kim.dat","w"); fclose(out);
out=fopen("c:/eurkat/linkomb-hiba.dat","w"); fclose(out);

char *s=new char[50];  fl=0; //utso=30;
for (i=1;i<=utso;i++) {fl+=linkomb(i); Memo1->Lines->Add(i);}
fl/=(float)(utso);

for (i=1;i<=utso;i++) {  fl=0;
  for (j=1;j<=utso2;j++) {
    if (amatr[i][j]<0) {amatr[i][j]=0;}  fl+=amatr[i][j];
  }
  if (fl<0.00001) {fl=1.0;}
  for (j=1;j<=utso2;j++) {amatr[i][j]/=fl;}
}


out=fopen("c:/eurkat/linkomb-tr.dat","w");
char *str=new char[1000];
for (j=0;j<1000;j++) {str[j]=0;}
for (i=1;i<=utso2;i++) {
  for (j=0;j<1000;j++) {str[j]=0;}
  for (j=1;j<=utso;j++) {sprintf(str,"  %-6.3f",amatr[j][i]);  fwrite(str, strlen(str),1,out);} //Memo1->Lines->Add(str);
  sprintf(str," \n"); fwrite(str, strlen(str),1,out);
}
fclose(out);



Memo1->Lines->Add(fl); return;


return;


}
//---------------------------------------------------------------------------
void __fastcall TForm1::Button1Click(TObject *Sender)  // not used
{
return;
int i,j;
float fl,fl1;
FILE *out;

dimenz=49;

utso2=vektfelhobe("c:/eurkat/hcs-eloszl.dat", fog, 100,1,' '); Memo1->Lines->Add(utso2);
for (i=1;i<=utso2;i++) {for (j=1;j<=dimenz;j++) {vektorok2[i][j]=vektorok[i][j];}}

utso=vektfelhobe("c:/eurkat/eloszl-korr-hcs1.dat", fog, 1000,1,' '); Memo1->Lines->Add(utso); //return;

/*
for (i=1;i<=utso2;i++) {  fl=0;
  for (j=1;j<=dimenz;j++) {fl1=vektorok2[i][j]; fl+=fl1*fl1} fl=sqrt(fl); if (fl<0.0001) {fl=1.0;}
  for (j=1;j<=dimenz;j++) {vektorok2[i][j]/=dimenz;}
}
*/

//reszosszeg(int nvekt, int ntip, int tipsorsz)
/*
out=fopen("c:/eurkat/reszosszeg.dat","w"); fclose(out);
utso=1;
for (i=1;i<=utso2;i++) {reszosszeg(utso,dimenz,i);}

//for (i=1;i<=dimenz;i++) {Memo1->Lines->Add(vektorok[10][i]);}   return;
*/
}
//---------------------------------------------------------------------------




void __fastcall TForm1::Button2Click(TObject *Sender)
{
int i,j,k,m, cikl;
float fl,fl1,maxhib;

dimenz=847; //847; 338;

utso=0;

fog=&fog[0];

//------------ loading the PCA vectors ---------------------------------
/*
utso2=vektfelhobe("c:/eurkat/pca+sulyp.dat", fog, 100,1,' '); Memo1->Lines->Add(utso2); //return;  // korrbaz.dat;    pca+sulyp.dat;
for (i=1;i<=utso2-1;i++) {for (j=1;j<=dimenz;j++) {vektorok0[i][j]=fabs(vektorok[i][j])-vektorok[utso2][j]*0;}}
utso2--;
*/

utso2=vektfelhobe("c:/eurkat/pcakoord-tr.dat", fog, 100,1,' '); Memo1->Lines->Add(utso2); //return;  // korrbaz.dat;    pca+sulyp.dat;
utso2=7;   // PC vektorsz�m
for (i=1;i<=utso2;i++) {for (j=1;j<=dimenz;j++) {vektorok0[i][j]=vektorok[i][j]; if (vektorok0[i][j]<0) {vektorok0[i][j]=0;}}}


// ------------ normalisation -------------------------------------
for (i=1;i<=utso2;i++) {  fl=0;
  for (j=1;j<=dimenz;j++) {
    fl+=vektorok0[i][j];       // eloszl�s
  }
  if (fabs(fl)<0.0001) {fl=1.0;}
  for (j=1;j<=dimenz;j++) {vektorok0[i][j]/=fl;vektorok2[i][j]=vektorok0[i][j];}
}

for (i=1;i<=utso2;i++) {vektel[i]=1;}

//utso2=vektval(utso2,dimenz); Memo1->Lines->Add(utso2); //return;

//------------- Loading the moment vectors --------------------------

fog=&fog[0];
utso=vektfelhobe("c:/eurkat/tipelterj-tr.dat", fog, 100,1,' '); Memo1->Lines->Add(utso); //return;

for (i=1;i<=utso;i++) {  fl=0; vektel[i]=1;
  for (j=1;j<=dimenz;j++) {
    fl+=vektorok[i][j];       // eloszl�s
  }
  if (fabs(fl)<0.0001) {fl=1.0;}
  for (j=1;j<=dimenz;j++) {vektorok[i][j]/=fl;}
}

//-----------------------------------------------------------------------------------------------------------------


FILE *out;
out=fopen("c:/eurkat/linkomb.dat","w"); fclose(out);
out=fopen("c:/eurkat/linkomb-kim.dat","w"); fclose(out);
out=fopen("c:/eurkat/linkomb-hiba.dat","w"); fclose(out);

char *s=new char[50];  fl=0; //utso=30;
for (i=1;i<=utso;i++) {fl+=linkomb(i); Memo1->Lines->Add(i);}   // linear combination algorithm for the ith culture
fl/=(float)(utso);

for (i=1;i<=utso;i++) {  fl=0;
  for (j=1;j<=utso2;j++) {
    if (amatr[i][j]<0) {amatr[i][j]=0;}  fl+=amatr[i][j];
  }
  if (fl<0.00001) {fl=1.0;}
  for (j=1;j<=utso2;j++) {amatr[i][j]/=fl;}
}


out=fopen("c:/eurkat/linkomb-tr.dat","w");
char *str=new char[1000];
for (j=0;j<1000;j++) {str[j]=0;}
for (i=1;i<=utso2;i++) {
  for (j=0;j<1000;j++) {str[j]=0;}
  for (j=1;j<=utso;j++) {sprintf(str,"  %-6.3f",amatr[j][i]);  fwrite(str, strlen(str),1,out);} //Memo1->Lines->Add(str);
  sprintf(str," \n"); fwrite(str, strlen(str),1,out);
}
fclose(out);



Memo1->Lines->Add(fl); return;



}
//---------------------------------------------------------------------------

